﻿(function () {
    'use strict';
    angular
        .module('app')
        .controller('ChangePwdController', ChangePwdController);
    
    ChangePwdController.$inject = ['$scope', '$location', '$cookieStore', 'UserService', 'AuthenticationService', 'FlashService'];
    function ChangePwdController($rootScope, $location, $cookieStore, UserService, AuthenticationService, FlashService) {
    	var vm = this;
    	vm.userName = '';
    	vm.changePassword = changePassword;

        (function initController() {
           vm.userName = $rootScope.globals.currentUser.username;
           AuthenticationService.ClearCredentials();
        })();
        
    	function changePassword() {

			var changePwdInfo = {
				userName : vm.userName,
				oldPassword : vm.oldPassword,
				newPassword : vm.newPassword,
				reTypeNewPassword : vm.retypeNewPassword
			}
			var config = {
				headers : {
					'Content-Type' : 'application/json',
					'Accept' : 'application/json'
				}
			}
			var changePwdUrl = "/b2biportal/api/users/changepassword";
			UserService.updateChangePwdInformation(changePwdUrl, changePwdInfo, config,
					function(response) {
					$location.path('/login');
					});
		};
        
    
    }

})();
