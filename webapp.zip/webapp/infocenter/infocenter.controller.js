﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('InfoCenterController', InfoCenterController);

    InfoCenterController.$inject = ['$cookieStore', 'Constants', 'InfoCenterService'];
    function InfoCenterController($cookieStore, Constants, InfoCenterService) {
    	
        var vm = this;
        vm.userConfig = $cookieStore.get('userConfig');
        vm.userRole = vm.userConfig.role;
        vm.keyData = {};
        vm.enableMenu = true;
        vm.enableTable = false;
        vm.hasAccess = hasAccess;   
        vm.showCerts = showCerts;

        initController();
        function initController() {
        };
        
        function hasAccess(tabName) {
        	if(vm.userRole == Constants.Roles['sender']) {
        		if($.inArray(tabName, Constants.Sender_Tabs) > -1) {
        			return true;
        		}
        		return false;
        	}
        	else if(vm.userRole == Constants.Roles['receiver']) {
        		if($.inArray(tabName, Constants.Receiver_Tabs) > -1) {
        			return true;
        		}
        		return false;
        	}
        	else if(vm.userRole == Constants.Roles['admin']) {
        		if($.inArray(tabName, Constants.Admin_Tabs) > -1) {
        			return true;
        		}
        		return false;
        	}
        	else if(vm.userRole == Constants.Roles['readonly']) {
        		if($.inArray(tabName, Constants.ReadOnly_Tabs) > -1) {
        			return true;
        		}
        		return false;
        	}
        	else
        		return false;
        };
        
        function showCerts(requestedKey) {
 	 		var data = {
 					keyName: requestedKey
 				}
 			var config = {
 	            headers : {
 	            	'Content-Type' : 'application/json',
 	            	'Accept' : 'application/json'
 	            }
 	        }
 			var showCertsApiUrl = "/b2biportal/api/file/certslist";
 	 		InfoCenterService.getListOfCerts(showCertsApiUrl, JSON.stringify(data), config, function (response) {
 				vm.keyData = response;
 				vm.enableMenu = false;
				vm.enableTable = true;
            });
 		};
        

    };

})();