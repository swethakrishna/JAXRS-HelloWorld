﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('IssueController', IssueController);

    IssueController.$inject = ['SupportService', '$rootScope'];
    function IssueController(SupportService, $rootScope) {
        var vm = this;
        vm.ticketStatus = '';
        vm.issueTypes = ["Login issue", "Functional issue", "Data related issue"];
        vm.createIssue = createIssue;
        
        
        /*vm.user = null;
        vm.allUsers = [];
        vm.deleteUser = deleteUser;*/

        initController();

        function initController() {
           // loadCurrentUser();
            //loadAllUsers();
        }

    	function createIssue() {
    		var formData = new FormData();
    		var data = {
 	 				subject:vm.subject,
 	 				description:vm.description,
 	 				userId:$rootScope.globals.currentUser.username,
 	 				issueType:vm.selectedIssueType
 				}
 	 		var file = vm.attachment;
    		formData.append('file', file);
    		formData.append('data', JSON.stringify(data));
            
            console.log('file is ');
            console.dir(file);
 			var url = "/b2biportal/api/issues/create";
 	 		SupportService.createIssue(url, formData, function (response) {
 	 			vm.ticketStatus = 'Ticket '+response+' Created Successfully....';
 	 			vm.subject='';
 	 			vm.description='';
 	 			vm.selectedIssueType='';
 	 			vm.attachment = '';
            });
 		};

    }

})();