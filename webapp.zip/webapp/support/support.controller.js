﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('SupportController', SupportController);

    SupportController.$inject = ['$rootScope'];
    function SupportController($rootScope) {
        var vm = this;

        /*vm.user = null;
        vm.allUsers = [];
        vm.deleteUser = deleteUser;*/

        initController();

        function initController() {
           // loadCurrentUser();
            //loadAllUsers();
        }

        /*function loadCurrentUser() {
            UserService.GetByUsername($rootScope.globals.currentUser.username)
                .then(function (user) {
                    vm.user = user;
                });
        }*/

    }

})();