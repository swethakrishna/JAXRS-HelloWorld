(function () {
    'use strict';
   
    angular
    .module('app')
    .controller('FileUploadController', FileUploadController);
    
    FileUploadController.$inject = ['$location','$rootScope', '$scope', '$cookieStore', 'Constants', 'FileUploadService'];
    function FileUploadController($location, $rootScope, scope, $cookieStore, Constants, FileUploadService) {
    
    	var vm = this;
    	vm.authString = $rootScope.globals.currentUser.authdata;
    	vm.userConfig = $cookieStore.get('userConfig');
        vm.userRole = vm.userConfig.role;
    	vm.uploadStatus = '';
        vm.uploadFile = uploadFile;
        vm.showLoader = true;
        var vm = this;
    	vm.dirPath = '';
    	vm.dirData = {};
    	vm.hasAccess = hasAccess;
        vm.getDirectoryList = getDirectoryList;
        vm.updateDirPath = updateDirPath;
        
        initController();
        function initController() { 
        	getDirectoryList();
        };
        
        function hasAccess(tabName) {
        	if(vm.userRole == Constants.Roles['sender']) {
        		if($.inArray(tabName, Constants.Sender_Tabs) > -1) {
        			return true;
        		}
        		return false;
        	}
        	else if(vm.userRole == Constants.Roles['receiver']) {
        		if($.inArray(tabName, Constants.Receiver_Tabs) > -1) {
        			return true;
        		}
        		return false;
        	}
        	else if(vm.userRole == Constants.Roles['admin']) {
        		if($.inArray(tabName, Constants.Admin_Tabs) > -1) {
        			return true;
        		}
        		return false;
        	}
        	else if(vm.userRole == Constants.Roles['readonly']) {
        		if($.inArray(tabName, Constants.ReadOnly_Tabs) > -1) {
        			return true;
        		}
        		return false;
        	}
        	else
        		return false;
        };
        
        function getDirectoryList(){
    		var apiDirlistUrl = "/b2biportal/api/file/directories/incoming?authString="+vm.authString;
    		FileUploadService.getDirectoryList(apiDirlistUrl, function (response) {
    			vm.dirData = response;
    			vm.showLoader = false;
            });
    	};
    	
    	function updateDirPath(dirName) {
 	 		vm.dirPath = dirName;
 	 	};
    	
    	function uploadFile(){
               var file = scope.myFile;
               if (file == undefined) {
            	   return false;
               }
               console.log('file is ');
               console.dir(file);
               
               var uploadUrl = "/b2biportal/api/file/upload?dirName="+vm.dirPath+"&fileName="+vm.fileName+"&authString="+vm.authString;
               FileUploadService.uploadFileToUrl(file, uploadUrl, function (response) {
    				vm.uploadStatus = response;
    				$('#myFile').val('');
                });
               //$location.path('/');
        };
        
    };
         
})();