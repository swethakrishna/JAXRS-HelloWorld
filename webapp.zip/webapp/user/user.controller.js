﻿(function() {
	'use strict';

	angular.module('app').controller('UserController', UserController);

	UserController.$inject = [ '$scope', 'UserService', '$mdDialog' ];
	function UserController($rootScope, UserService, $mdDialog) {
		var vm = this;
		vm.user = null;
		vm.userClientId = null;
		vm.data = {};
		vm.status = '  ';
		vm.customFullscreen = false;
		vm.loadCurrentUser = loadCurrentUser;
		initController();
		vm.loadDropOffUser = loadDropOffUser;
		vm.updateUserInfo = updateUserInfo;
		vm.showAdvanced = showAdvanced;
		vm.changePassword = changePassword;
		vm.additionalUserInfo = additionalUserInfo;

		function initController() {
			loadCurrentUser();
			// loadAllUsers();
		}

		function DialogController($rootScope, $mdDialog, data) {
			$rootScope.data = data;
			$rootScope.hide = function() {
				$mdDialog.hide();
			};
			$rootScope.cancel = function() {
				$mdDialog.cancel();
			};
			$rootScope.answer = function(answer) {
				$mdDialog.hide(answer);
			};
		}

		function loadCurrentUser() {
			UserService.getUserInformation($rootScope.globals.currentUser.username)
					.then(function(response) {
						vm.user = response;
						vm.userClientId = response.clientId;
					});
		}
		function loadDropOffUser() {

		}

		function showAdvanced(data, ev) {
			
			$mdDialog.show({
				controller : DialogController,
				templateUrl: 'user/dropoffUserInfo.view.html',
				windowClass : 'modal-fit',
				parent : angular.element(document.body),
				targetEvent : ev,
				clickOutsideToClose : true,
				fullscreen : vm.customFullscreen,
				locals: { data: data },
				scope: $rootScope,
				preserveScope: true
				

			// Only for -xs, -sm breakpoints.
			});
		}

		//Update User Info here..
		function updateUserInfo() {
		
			var userInfoData = {
				name : vm.user.name,
				firstName : vm.user.firstName,
				lastName : vm.user.lastName,
				email : vm.user.email,
				phoneNumber : vm.user.phoneNumber,
				pager : vm.user.pager,
				aliasName : vm.user.aliasName
			}
			var config = {
				headers : {
					'Content-Type' : 'application/json',
					'Accept' : 'application/json'
				}
			}
			console.log("vm.userClientId: " + vm.userClientId);
			var updateUrl = "/b2biportal/api/users/updatetp";
			UserService.updateUserInformation(updateUrl, userInfoData, config,
					function(response) {
						vm.user = userInfoData;
						// vm.enableGo = false;
						// vm.mailCount = false;
						// vm.enableTable = true;
					});
		}
		
		//Change Password functionality here.
		function changePassword() {

			var changePwdInfo = {
				userName : vm.user.userName,
				oldPassword : vm.user.oldPassword,
				newPassword : vm.user.newPassword,
				reTypeNewPassword : vm.user.retypeNewPassword
			}
			var config = {
				headers : {
					'Content-Type' : 'application/json',
					'Accept' : 'application/json'
				}
			}
			console.log("userClientId: " + vm.userClientId);
			console.log("userName: " + vm.user.userName);
			console.log("oldPassword: " + vm.user.oldPassword);
			console.log("newPassword: " + vm.user.newPassword);
			var changePwdUrl = "/b2biportal/api/users/changepassword";
			UserService.updateChangePwdInformation(changePwdUrl, changePwdInfo, config,
					function(response) {
						vm.user = changePwdInfo;
					});
		}
		
		
		// additional drop-off user functionality 
		function additionalUserInfo() {

			var additionalUserInfo = {
				name : vm.user.name,
				aliasName : vm.user.aliasName,
				firstName : vm.user.duFirstname,
				lastName : vm.user.duLastName,
				email : vm.user.duEmail,
				userName : vm.user.gisUserName,
				gisUserPassword : vm.user.gisUserPassword
			}
			
			var config = {
				headers : {
					'Content-Type' : 'application/json',
					'Accept' : 'application/json'
				}
			}
			console.log("userClientId: " + vm.userClientId);
			console.log("AliasName: " + vm.user.duAliasName);
			console.log("FirstName: " + vm.user.duFirstname);
			console.log("LastName: " + vm.user.duLastName);
			var additionalUserInfoUrl = "/b2biportal/api/users/additionaluser";
			UserService.additionalUserInformation(additionalUserInfoUrl, additionalUserInfo, config,
					function(response) {
						vm.user = additionalUserInfo;
					});
		}
}


})();