(function () {
    'use strict';
    
    angular
    .module('app')
    .factory('ReportService', ReportService);
    
    ReportService.$inject = ['$http','$rootScope'];
    
    function ReportService($http, $rootScope) {
    	
    	var service = {};
        service.getIssues = getIssues;
        return service;

        function getIssues(url, callback) {        	
            $http.get(url)
                .success(function (response) {
                    callback(response);
                });            
        }
    	
       };
})();