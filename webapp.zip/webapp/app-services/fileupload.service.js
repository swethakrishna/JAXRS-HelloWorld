(function () {
    'use strict';
    
    angular
    .module('app')
    .factory('FileUploadService', FileUploadService);
    
    FileUploadService.$inject = ['$http','$rootScope'];
    
    function FileUploadService($http, $rootScope) {
    	
    	var service = {};
        service.uploadFileToUrl = uploadFileToUrl;
        service.getDirectoryList = getDirectoryList;
        return service;

        function getDirectoryList(url, callback) {        	
            $http.get(url)
                .success(function (response) {
                    callback(response);
                });            
        }
    	
    	function uploadFileToUrl (file, uploadUrl, callback){
            
    		var fd = new FormData();
            fd.append('file', file);
            $http.post(uploadUrl, fd, {
               transformRequest: angular.identity,
               headers: {'Content-Type': undefined}
            })            
            .success(function(response){
            	callback(response);
            })         
            .error(function(){
            });
         }
       };
})();