(function () {
    'use strict';
    
    angular
    .module('app')
    .factory('SupportService', SupportService);
    
    SupportService.$inject = ['$http','$rootScope'];
    
    function SupportService($http, $rootScope) {
    	
    	var service = {};
        service.createIssue = createIssue;
        service.getIssues = getIssues;
        return service;

        function getIssues(url, callback) {        	
            $http.get(url)
                .success(function (response) {
                    callback(response);
                });            
        }
    	
    	function createIssue (url, formData, callback){
            $http.post(url, formData, {
            	 transformRequest: angular.identity,
                 headers: {'Content-Type': undefined}
            })            
            .success(function(response){
            	callback(response);
            })         
            .error(function(){
            });
         }
       };
})();