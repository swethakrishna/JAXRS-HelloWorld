(function () {
    'use strict';
    angular
        .module('app')
        .factory('InfoCenterService', InfoCenterService);
    
    InfoCenterService.$inject = ['$http'];
    
    function InfoCenterService($http) {
        var service = {};        
        service.getListOfCerts = getListOfCerts;
        return service;

        function getListOfCerts(url, data, config, callback) {        	
        	$http.post(url, data, {
                transformRequest: angular.identity,
                headers: config
             })
             .success(function(response){
            	 callback(response);
             })          
             .error(function(){
             });
        };
    };

})();