﻿(function () {
    'use strict';

    angular
        .module('app')
        .factory('UserService', UserService);

    UserService.$inject = ['$http','FlashService'];
    function UserService($http, FlashService) {
        var service = {};

        // service.GetAll = GetAll;
        // service.GetById = GetById;
        service.getUserInformation = getUserInformation;
        // service.Create = Create;
        // service.Delete = Delete;
        service.updateUserInformation = updateUserInformation;
        service.updateChangePwdInformation  = updateChangePwdInformation;
        service.additionalUserInformation  = additionalUserInformation;
        
        return service;

        function GetAll() {
            return $http.get('/api/users').then(handleSuccess, handleError('Error getting all users'));
        }

        function GetById(id) {
            return $http.get('/api/users/' + id).then(handleSuccess, handleError('Error getting user by id'));
        }

        function getUserInformation(username) {
            return $http.get('/b2biportal/api/users/' + username).then(handleSuccess, handleError('Error in getting user information'));
        }

        function Create(user) {
            return $http.post('b2biportal/api/users', user).then(handleSuccess, handleError('Error creating user'));
        }

       
        
        function updateUserInformation(url, data, config, callback) {        	
        	$http.put(url, angular.toJson(data), {
                transformRequest: angular.identity,
                headers: config
             })
             .success(function(response){
            	 callback(response);
             })          
             .error(function(){ 
             });
        }

        function updateChangePwdInformation(url, data, config, callback) {        	
        	$http.post(url, angular.toJson(data), {
                transformRequest: angular.identity,
                headers: config
             })
             .success(function(response){
            	 callback(response);
             })          
             .error(function(response){ 
            	 if (response.errorDetails[0].code == '503') {
            		 FlashService.Error(response.errorDetails[0].description);
            	 } 
             });
        }
        
        function additionalUserInformation(url, data, config, callback) {        	
        	$http.post(url, angular.toJson(data), {
                transformRequest: angular.identity,
                headers: config
             })
             .success(function(response){
            	 callback(response);
             })          
             .error(function(){ 
             });
        }
        
               }

        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(error) {
            return function () {
                return { success: false, message: error };
            };
        }
    

})();
