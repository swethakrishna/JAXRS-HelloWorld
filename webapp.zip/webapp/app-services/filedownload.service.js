(function () {
    'use strict';
    angular
        .module('app')
        .factory('FileDownloadService', FileDownloadService);
    
    FileDownloadService.$inject = ['$http'];
    
    function FileDownloadService($http) {
        var service = {};
        
        service.getDirectoryList = getDirectoryList;
        service.getFileList = getFileList;
        
        return service;

        function getDirectoryList(url, callback) {        	
            $http.get(url)
                .success(function (response) {
                    callback(response);
                });            
        }
        
        function getFileList(url, data, config, callback) {        	
        	$http.post(url, data, {
                transformRequest: angular.identity,
                headers: config
             })
             .success(function(response){
            	 callback(response);
             })          
             .error(function(){
             });
        }
    }

})();