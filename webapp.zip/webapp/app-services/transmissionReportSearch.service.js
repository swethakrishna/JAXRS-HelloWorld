(function () {
    'use strict';

    angular
        .module('app')
        .factory('TransmissionReportSearchService', TransmissionReportSearchService);

    TransmissionReportSearchService.$inject = ['$http'];
    
    function TransmissionReportSearchService($http) {
    	var service = {};    	
        service.getTransmissionReportResponse = getTransmissionReportResponse;        
        return service;

        function getTransmissionReportResponse(url, data, config, callback) {        	
        	$http.post(url, data, {
                transformRequest: angular.identity,
                headers: config
             })
             .success(function(response){
            	 callback(response);
             })          
             .error(function(){
             });
        }
    }

})();