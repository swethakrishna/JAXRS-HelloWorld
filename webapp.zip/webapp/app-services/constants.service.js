(function () {
    'use strict';

    angular.module('app').constant('Constants', {
    	Roles: {
    		sender: 'SYS_DROPOFF',
    		receiver: 'SYS_PICKUP',
    		admin: 'SYS_ADMIN',
    		readonly: 'SYS_READ_ONLY'
    	},
    	Sender_Tabs: ['Home', 'Send', 'Reports', 'InfoCenter'],    		
    	Receiver_Tabs: ['Home', 'Receive', 'Reports', 'InfoCenter'],
    	Admin_Tabs: ['Home', 'Send', 'Receive', 'Reports', 'ControlCenter', 'InfoCenter'],
    	ReadOnly_Tabs:['Home', 'InfoCenter']
    });
    

})();