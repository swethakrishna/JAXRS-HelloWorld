﻿(function () {
    'use strict';
    angular
        .module('app')
        .controller('LoginController', LoginController);
    
    LoginController.$inject = ['$location', 'AuthenticationService', 'FlashService'];
    function LoginController($location, AuthenticationService, FlashService) {
    	var vm = this;
    	vm.username = '';
    	vm.password = '';
        vm.login = login;

        (function initController() {
            // reset login status
            AuthenticationService.ClearCredentials();
        })();
        
        function login() {
            vm.dataLoading = true;
            var data = {
 					username: vm.username,
 					password: vm.password
 				}
 			var config = {
 	            headers : {
 	            	'Content-Type' : 'application/json',
 	            	'Accept' : 'application/json'
 	            }
 	        }
            var loginUrl = "/b2biportal/api/authenticate";
            AuthenticationService.Login(vm);
        };
        
    }

})();
