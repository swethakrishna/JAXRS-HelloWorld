(function () {
    'use strict';
   
    angular
    .module('app')
    .controller('FileDownloadController', FileDownloadController);
    
    FileDownloadController.$inject = ['$location','$rootScope', '$filter', '$cookieStore', 'Constants', 'FileDownloadService'];
    function FileDownloadController($location, $rootScope, $filter, $cookieStore, Constants, FileDownloadService) {
    
    	var vm = this;
    	vm.authString = $rootScope.globals.currentUser.authdata;
    	vm.userConfig = $cookieStore.get('userConfig');
        vm.userRole = vm.userConfig.role;
    	vm.dirPath = '/';
    	vm.enableGo = true;
    	vm.mailCount = false;
    	vm.enableTable = false;
    	vm.showLoader = true;
    	vm.dirData = {};
    	vm.fileData = {};
    	vm.hasAccess = hasAccess;
        vm.getDirectoryList = getDirectoryList;
        vm.updateDirPath = updateDirPath;
        vm.getFileList = getFileList;
        
        var date = new Date();
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        var today = date.getDate();
        var yesterday = date.getDate() - 1;
        var timeInHrs = date.getHours();
        var timeInMins = date.getMinutes();
        var timeInMinsOld = timeInMins-1;
        var meridian = 'AM';

        if (today < 10) {
        	today = '0' + today;
        };
        if (yesterday < 10) {
        	yesterday = '0' + yesterday;
        };
        if (month < 10) {
        	month = '0' + month;
        };        
        if (timeInHrs > 12) {
        	timeInHrs = '0' + (timeInHrs - 12);
        	meridian = 'PM';
        };
        if (timeInMins < 10) {
        	timeInMins = '0' + timeInMins;
        };
        if (timeInMinsOld < 10) {
        	timeInMinsOld = '0' + timeInMinsOld;
        };
        
        vm.messageName = '';
        vm.StartDate = year + '-' + month + '-' + yesterday;
        vm.EndDate = year + '-' + month + '-' + today;
        vm.StartTime = timeInHrs + ':' + timeInMinsOld;
        vm.EndTime = timeInHrs + ':' + timeInMins;
        vm.StartAMPM = meridian;
        vm.EndAMPM = meridian;
        	
        initController();
        function initController() {
        	getDirectoryList();
        };
        
        function hasAccess(tabName) {
        	if(vm.userRole == Constants.Roles['sender']) {
        		if($.inArray(tabName, Constants.Sender_Tabs) > -1) {
        			return true;
        		}
        		return false;
        	}
        	else if(vm.userRole == Constants.Roles['receiver']) {
        		if($.inArray(tabName, Constants.Receiver_Tabs) > -1) {
        			return true;
        		}
        		return false;
        	}
        	else if(vm.userRole == Constants.Roles['admin']) {
        		if($.inArray(tabName, Constants.Admin_Tabs) > -1) {
        			return true;
        		}
        		return false;
        	}
        	else if(vm.userRole == Constants.Roles['readonly']) {
        		if($.inArray(tabName, Constants.ReadOnly_Tabs) > -1) {
        			return true;
        		}
        		return false;
        	}
        	else
        		return false;
        };
        
    	function getDirectoryList() {
    		var apiDirlistUrl = "/b2biportal/api/file/dirlist?authString="+vm.authString;
    		FileDownloadService.getDirectoryList(apiDirlistUrl, function (response) {
    			vm.dirData = response;
    			vm.enableGo = true;
    			vm.mailCount = true;
    			vm.enableTable = false;
    			vm.showLoader = false;
            });
    	};
    	
    	function updateDirPath(dirName) {
 	 		vm.dirPath = dirName;
 	 	};
 	 	
 	 	function getFileList() {
 	 		var data = {
 					dirLoc: vm.dirPath,
 					messageName: vm.messageName,
 					StartDate: vm.StartDate,
 					EndDate: vm.EndDate,
 					StartTime: vm.StartTime,
 					EndTime: vm.EndTime,
 					StartAMPM: vm.StartAMPM,
 					EndAMPM: vm.EndAMPM
 				}
 			var config = {
 	            headers : {
 	            	'Content-Type' : 'application/json',
 	            	'Accept' : 'application/json'
 	            }
 	        }
 			var apiFilelistUrl = "/b2biportal/api/file/list?authString="+vm.authString;
 			FileDownloadService.getFileList(apiFilelistUrl, JSON.stringify(data), config, function (response) {
 				vm.fileData = response;
 				vm.enableGo = false;
 				vm.mailCount = false;
				vm.enableTable = true;
            });
 		};
 		
      };
         
})();
