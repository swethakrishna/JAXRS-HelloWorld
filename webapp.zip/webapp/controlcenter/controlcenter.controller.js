﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('ControlCenterController', ControlCenterController);

    ControlCenterController.$inject = ['$cookieStore', 'Constants'];
    
    function ControlCenterController($cookieStore, Constants) {
        var vm = this;
        vm.userConfig = $cookieStore.get('userConfig');
        vm.userRole = vm.userConfig.role;
        vm.changeSSHKey = vm.userConfig.sshkeyConf;
        vm.changePGPKey = vm.userConfig.pgpkeyConf;
        vm.changeCDConf = vm.userConfig.cdconf;
        vm.changeAS2Conf = vm.userConfig.as2Conf;
        vm.customChangeReq = vm.userConfig.changeReqConf;
        vm.manage3SKey = vm.userConfig._3SKeyConf; 
        vm.hasAccess = hasAccess;
        
        initController();
        function initController() {
        };
        
        function hasAccess(tabName) {
        	if(vm.userRole == Constants.Roles['sender']) {
        		if($.inArray(tabName, Constants.Sender_Tabs) > -1) {
        			return true;
        		}
        		return false;
        	}
        	else if(vm.userRole == Constants.Roles['receiver']) {
        		if($.inArray(tabName, Constants.Receiver_Tabs) > -1) {
        			return true;
        		}
        		return false;
        	}
        	else if(vm.userRole == Constants.Roles['admin']) {
        		if($.inArray(tabName, Constants.Admin_Tabs) > -1) {
        			return true;
        		}
        		return false;
        	}
        	else if(vm.userRole == Constants.Roles['readonly']) {
        		if($.inArray(tabName, Constants.ReadOnly_Tabs) > -1) {
        			return true;
        		}
        		return false;
        	}
        	else
        		return false;
        };

    };

})();