﻿(function () {
    'use strict';

    angular
        .module('app', ['ngRoute', 'ngCookies', 'ngMaterial',
            'ngAnimate',
            'ngAria',
            'ngMessages',
            'ngMaterial', 
            'ngSanitize', 
            'ngCsv',
            'ngTable'])
        .config(config)
        .run(run);

    config.$inject = ['$routeProvider', '$locationProvider'];
    function config($routeProvider, $locationProvider) {
        $routeProvider
           .when('/', {
            	controller: 'HomeController',
                templateUrl: 'home/home.view.html',
                controllerAs: 'vm'
            })
            .when('/login', {
                controller: 'LoginController',
                templateUrl: 'login/login.view.html',
                controllerAs: 'vm'
            })
            .when('/register', {
                controller: 'RegisterController',
                templateUrl: 'register/register.view.html',
                controllerAs: 'vm'
            })
            .when('/fileupload', {
            	controller: 'FileUploadController',
                templateUrl: 'fileupload/fileupload.view.html',
                controllerAs: 'vm'
            })
            .when('/filedownload', {
            	controller: 'FileDownloadController',
                templateUrl: 'filedownload/filedownload.view.html',
                controllerAs: 'vm'
            })
            .when('/useraccount', {
            	controller: 'UserController',
                templateUrl: 'user/user.view.html',
                controllerAs: 'vm'
            })
            .when('/controlcenter', {
            	controller: 'ControlCenterController',
                templateUrl: 'controlcenter/controlcenter.view.html',
                controllerAs: 'vm'
            })
            .when('/infocenter', {
            	controller: 'InfoCenterController',
                templateUrl: 'infocenter/infocenter.view.html',
                controllerAs: 'vm'
            })
            .when('/suppport', {
            	controller: 'SupportController',
                templateUrl: 'support/support.view.html',
                controllerAs: 'vm'
            })         
            .when('/support/issue', {
            	controller: 'IssueController',
                templateUrl: 'support/issue/issue.view.html',
                controllerAs: 'vm'
            })
            .when('/reports', {
            	controller: 'ReportsController',
                templateUrl: 'reports/reports.view.html',
                controllerAs: 'vm'
            })
            .when('/reports/transmissionsearch', {
                controller: 'TransmissionReportSearchController',
                templateUrl: 'reports/transmission/transmissionReportSearch.view.html',
                controllerAs: 'vm'
            })
            .when('/reports/serviceticket', {
            	controller: 'ServiceTicketController',
                templateUrl: 'reports/serviceticket/serviceticket.view.html',
                controllerAs: 'vm'
            })
            .when('/changepwd', {
            	controller: 'ChangePwdController',
                templateUrl: 'changepwd/changepwd.view.html',
                controllerAs: 'vm'
            })

            .otherwise({ redirectTo: '/login' });
    }

    run.$inject = ['$rootScope', '$location', '$cookieStore', '$http'];
    function run($rootScope, $location, $cookieStore, $http) {
        // keep user logged in after page refresh
        $rootScope.globals = $cookieStore.get('globals') || {};
        if ($rootScope.globals.currentUser) {
            $http.defaults.headers.common['Authorization'] = 'Basic ' + $rootScope.globals.currentUser.authdata; // jshint ignore:line
        }

        $rootScope.$on('$locationChangeStart', function (event, next, current) {
            // redirect to login page if not logged in and trying to access a restricted page
            var restrictedPage = $.inArray($location.path(), ['/login', '/register']) === -1;
            var loggedIn = $rootScope.globals.currentUser;
            if (restrictedPage && !loggedIn) {
                $location.path('/login');
            }
        });
    }

})();