(function () {
    'use strict';
   
    angular
    .module('app')
    .controller('TransmissionReportSearchController', TransmissionReportSearchController);
    
    TransmissionReportSearchController.$inject = ['$location', '$rootScope', 'TransmissionReportSearchService','NgTableParams'];
    function TransmissionReportSearchController($location, $rootScope, TransmissionReportSearchService, NgTableParams) {
    
    	 var vm = this;
    	 vm.authString = $rootScope.globals.currentUser.authdata;
    	 vm.transmissionData = {};
    	 vm.enableGo = true;
    	 vm.enableTable = false;
    	 vm.getTransmissionReport = getTransmissionReport;
    	 var data = {};

         var date = new Date();
         var year = date.getFullYear();
         var month = date.getMonth() + 1;
         var today = date.getDate();
         var yesterday = date.getDate() - 1;
         var timeInHrs = date.getHours();
         var timeInMins = date.getMinutes();
         var timeInMinsOld = timeInMins-1;
         var meridian = 'AM';

         if (today < 10) {
               today = '0' + today;
         };
         if (yesterday < 10) {
               yesterday = '0' + yesterday;
         };
         if (month < 10) {
               month = '0' + month;
         };        
         if (timeInHrs > 12) {
               timeInHrs = '0' + (timeInHrs - 12);
               meridian = 'PM';
         };
         if (timeInMins < 10) {
               timeInMins = '0' + timeInMins;
         };
         if (timeInMinsOld < 10) {
               timeInMinsOld = '0' + timeInMinsOld;
         };
         
         vm.fileName = '';
         vm.direction = 'BOTH';
         vm.status = 'SELECT ONE';
         vm.StartDate = year + '-' + month + '-' + yesterday;
         vm.EndDate = year + '-' + month + '-' + today;
         vm.StartTime = timeInHrs + ':' + timeInMinsOld;
         vm.EndTime = timeInHrs + ':' + timeInMins;
         vm.StartAMPM = meridian;
         vm.EndAMPM = meridian;
               
         initController();
         function initController() {             
         };        
    	
 	 	function getTransmissionReport() {
 	 		var data = {
 	 				fileName: vm.fileName,
 	 				direction: vm.direction,
 	 				status: vm.status,
 	 				StartDate: vm.StartDate,
					EndDate: vm.EndDate,
					StartTime: vm.StartTime,
					EndTime: vm.EndTime,
					StartAMPM: vm.StartAMPM,
					EndAMPM: vm.EndAMPM	
 				}
 			var config = {
 	            headers : {
 	            	'Content-Type' : 'application/json',
 	            	'Accept' : 'application/json'
 	            }
 	        }
 	 		var apiFilelistUrl = "/b2biportal/api/transmission/list?authString="+vm.authString;
 	 		TransmissionReportSearchService.getTransmissionReportResponse(apiFilelistUrl, JSON.stringify(data), config, function (response) {
 				vm.transmissionData = response;
 				data = response;
 				vm.tableParams = new NgTableParams({}, { dataset: data});
 				vm.enableGo = false;
				vm.enableTable = true;
            });
 		};
      };
         
})();
