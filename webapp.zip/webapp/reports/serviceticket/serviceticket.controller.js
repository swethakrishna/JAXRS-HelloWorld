﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('ServiceTicketController', ServiceTicketController);

    ServiceTicketController.$inject = ['$rootScope', 'ReportService','NgTableParams'];
    function ServiceTicketController($rootScope, ReportService, NgTableParams) {
        var vm = this;
       
        vm.issuesData = {};
        vm.showLoader = true;
        var data = {};
        
        initController();

        function initController() {
        	getIssues();
        }

        function getIssues() {
 	 		
 			var url = "/b2biportal/api/issues/get/"+$rootScope.globals.currentUser.username;
 			ReportService.getIssues(url, function (response) {
 				vm.issuesData = response;
 				data = response;
 				vm.tableParams = new NgTableParams({}, { dataset: data});
 				vm.showLoader = false;
            });
 		};

    }

})();