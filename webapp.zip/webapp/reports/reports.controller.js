﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('ReportsController', ReportsController);

    ReportsController.$inject = ['$rootScope', '$cookieStore', 'Constants'];
    function ReportsController($rootScope, $cookieStore, Constants) {
    	
        var vm = this;
        vm.userConfig = $cookieStore.get('userConfig');
        vm.userRole = vm.userConfig.role;
        vm.hasAccess = hasAccess;  
        
        
        initController();
        function initController() {
        };

        function hasAccess(tabName) {
        	if(vm.userRole == Constants.Roles['sender']) {
        		if($.inArray(tabName, Constants.Sender_Tabs) > -1) {
        			return true;
        		}
        		return false;
        	}
        	else if(vm.userRole == Constants.Roles['receiver']) {
        		if($.inArray(tabName, Constants.Receiver_Tabs) > -1) {
        			return true;
        		}
        		return false;
        	}
        	else if(vm.userRole == Constants.Roles['admin']) {
        		if($.inArray(tabName, Constants.Admin_Tabs) > -1) {
        			return true;
        		}
        		return false;
        	}
        	else if(vm.userRole == Constants.Roles['readonly']) {
        		if($.inArray(tabName, Constants.ReadOnly_Tabs) > -1) {
        			return true;
        		}
        		return false;
        	}
        	else
        		return false;
        };

    };

})();