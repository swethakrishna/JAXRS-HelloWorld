package com.bofa.b2bi.api;

import java.io.InputStream;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.springframework.beans.factory.annotation.Autowired;

import com.bofa.b2bi.api.dto.IssueDto;
import com.bofa.b2bi.api.response.IssueResponseDto;
import com.bofa.b2bi.api.service.IssueService;
import com.bofa.b2bi.core.exception.PlatformException;

@Path("/issues")
public class IssueResourceService {
	
	@Autowired
	IssueService issueService;
	
	@POST
    @Path("/create")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Long createIssue(@FormDataParam("data") FormDataBodyPart jsonPart, @FormDataParam("file") InputStream fis) throws PlatformException {
		jsonPart.setMediaType(MediaType.APPLICATION_JSON_TYPE);
		IssueDto issueDto = jsonPart.getValueAs(IssueDto.class);
		return issueService.createIssue(issueDto, fis);
	}
	
	@GET
    @Path("/get/{userName}")
    @Produces(MediaType.APPLICATION_JSON)
	public List<IssueResponseDto> getIssues(@PathParam("userName") String userName) throws PlatformException {
		return issueService.getIssues(userName);
	}

}
