
package com.bofa.b2bi.api.common;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

public class OracleReplicatingConnection extends ReplicatingConnection {
    /**
     * Query to return unique transaction id
     */
    private final String TRANSACTION_ID_QUERY = "select ML_REPLICATION_TRANSACTION_ID.nextval from dual";
    
    /**
     * Query to return unique transaction id
     */
    private final String CD_TRANSACTION_ID_QUERY = "select ML_CD_REP_TRANSACTION_ID.nextval from dual";

    /**
     * SQL statement to insert single statement transaction into replication queue
     */
    protected String duplicateInsert = "INSERT INTO ML_REPLICATION_QUEUE (OPERATION_DATA, OPERATION_ID, SUB_OPERATION_ID, OPERATION_TYPE, TIME_ADDED, COMMIT, USERNAME) VALUES (?, ?, ?, ?, SYSDATE, 0, ?)";

    /**
     * SQL statement to insert single statement transaction into replication queue
     * adding remaining DESCRIPTION column.
     */
    protected String duplicateInsertWithDescription = "INSERT INTO ML_REPLICATION_QUEUE (OPERATION_DATA, OPERATION_ID, SUB_OPERATION_ID, OPERATION_TYPE, TIME_ADDED, COMMIT, USERNAME, DESCRIPTION) VALUES (?, ?, ?, ?, SYSDATE, 0, ?, ?)";

    /**
     * SQL statement to insert statement into replication queue with specific operation id
     */
    protected String duplicateInsertAutoCommit = "INSERT INTO ML_REPLICATION_QUEUE (OPERATION_DATA, OPERATION_ID, SUB_OPERATION_ID, OPERATION_TYPE, TIME_ADDED, COMMIT, USERNAME) VALUES (?, ML_REPLICATION_TRANSACTION_ID.nextval, ?, ?, SYSDATE, 1, ?)";

    /**
     * SQL statement to insert statement into replication queue with specific operation id
     * adding remaining DESCRIPTION column.
     */
    protected String duplicateInsertWithDescriptionAutoCommit = "INSERT INTO ML_REPLICATION_QUEUE (OPERATION_DATA, OPERATION_ID, SUB_OPERATION_ID, OPERATION_TYPE, TIME_ADDED, COMMIT, USERNAME, DESCRIPTION) VALUES (?, ML_REPLICATION_TRANSACTION_ID.nextval, ?, ?, SYSDATE, 1, ?, ?)";
    
    
    /**
     * SQL statement to insert statement into CD replication queue with specific operation id
     * adding DESCRIPTION, METHOD, URI and API column.
     */
    protected String duplicateCDInsertWithDescriptionAutoCommit = "INSERT INTO ML_CD_REPLICATION_QUEUE (OPERATION_DATA, OPERATION_ID, SUB_OPERATION_ID, OPERATION_TYPE, TIME_ADDED, COMMIT, USERNAME, DESCRIPTION, METHOD, URI, API) VALUES (?, ML_CD_REP_TRANSACTION_ID.nextval, 1, ?, SYSDATE, 1, ?, ?, ?, ?,?)";

    /**
     * Constructor
     *
     * @param conn The 'real' Connection object
     * @param userName The UI user performing DB operations
     */
    public OracleReplicatingConnection(Connection conn, String userName) {
        super(conn, userName);

        // TODO Auto-generated constructor stub
    }

    /**
     * Constructor
     *
     * @param conn The 'real' Connection object
     */
    public OracleReplicatingConnection(Connection conn) {
        super(conn);

        // TODO Auto-generated constructor stub
    }

    /**
     * Returns a unique transaction ID
     *
     * @return unique numeric value
     *
     * @throws SQLException
     */
    protected long obtainTransactionID() throws SQLException {
        long transID;
        Statement st = null;
        ResultSet nextVal = null;
        try{
        	st = wrappedConnection.createStatement();
        	nextVal = st.executeQuery(TRANSACTION_ID_QUERY);

        	if (nextVal.next())
        		transID = nextVal.getLong(1);
        	else
        		throw new SQLException("Failed to get Transaction ID for replication");
        }finally{
        	close(nextVal);
        	close(st);
        }
        return transID;
    }
    
    /**
     * Closes a ResultSet object
     *
     * @param result ResultSet to be closed
     */
    public void close(ResultSet result) {
        try {
            if (result != null) {
                result.close();
            }
        } catch (SQLException sqle) {
            System.err.println("Failed to close resultSet");
        }
    }

    /**
     * Closes a Statement object
     *
     * @param stmt Statement to be closed
     */
    public void close(Statement stmt) {
        try {
            if (stmt != null) {
                stmt.close();
            }
        } catch (SQLException sqle) {
            System.err.println("Failed to close (prepared)Statement");
        }
    }

    /**
     * Getter
     *
     * @return duplicateInsert String
     */
    public String getDuplicateInsertStatement() {
        return duplicateInsert;
    }

    /**
     * Getter
     *
     * @return duplicateInsertWithDescription String
     */
    public String getDuplicateInsertWithDescriptionStatement() {
        return duplicateInsertWithDescription;
    }

    /**
     * Getter
     *
     * @return returns duplicateInsertAutoCommit String
     */
    public String getDuplicateInsertAutoCommitStatement() {
        return duplicateInsertAutoCommit;
    }

    /**
     * Getter
     *
     * @return duplicateInsertWithDescriptionAutoCommit String
     */
    public String getDuplicateInsertWithDescriptionAutoCommitStatement() {
        return duplicateInsertWithDescriptionAutoCommit;
    }

    public String getDuplicateCDInsertWithDescriptionAutoCommit() {
		return duplicateCDInsertWithDescriptionAutoCommit;
	}

	/**
     * Format a java.sql.Date object for insertion into Oracle
     *
     * @param theDate java.sql.Data
     *
     * @return String formated for inclusion in SQL statement
     */
    public String formatDate(Date theDate) {
        return "TO_DATE('" + theDate + "', 'YYYY-MM-DD')";
    }


    /**
     * Format a java.sql.Timestamp object for insertion into Oracle
     *
     * @param theTimestamp java.sql.Timestamp
     *
     * @return String formated for inclusion in SQL statement
     *
     */
    public String formatTimestamp(Timestamp theTimestamp) {
        //Need to strip fractional seconds from default string format of Timestamp
        String tsString = theTimestamp.toString();
        int dotIndex = tsString.lastIndexOf(".");
        tsString = tsString.substring(0, dotIndex);

        return "TO_DATE('" + tsString + "', 'YYYY-MM-DD HH24:MI:SS')";
    }
}
