
package com.bofa.b2bi.api.common;

import java.io.ByteArrayInputStream;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;
import java.util.Iterator;


public class ReplicatingStatement implements Statement {
    /** The ReplicatedConnection object that handed out this object */
    protected ReplicatingConnection replicatedConnection;

    /** Array of batched statements */
    protected ArrayList batchedSQL;

    /** the query string */
    protected String sqlTemplate;

    /** a statement created from a real database connection */
    protected Statement wrappedStatement;

    /**
     * Statement to insert a single statement transaction to replication queue
     */
    protected PreparedStatement duplicateStatement = null;

    /**
     * Statement to insert a single statement transaction to replication queue
     * using remaining DESCRIPTION column.
     */
    protected PreparedStatement duplicateStatementWithDescription = null;

    /**
     * Statement to insert a statement into to replication queue with specific
     * transaction id
     */
    protected PreparedStatement duplicateStatementAutoCommit = null;

    /**
     * Statement to insert a statement into to replication queue with specific
     * transaction id using remaining DESCRIPTION column.
     */
    protected PreparedStatement duplicateStatementWithDescriptionAutoCommit = null;
    
    
    /**
     * Statement to insert a statement into to ssp cm replication queue with specific
     * transaction id using METHOD, URI and DESCRIPTION column.
     */
    protected PreparedStatement duplicateCDInsertWithDescriptionAutoCommit = null;

    /**
     * Constructor
     *
     * @param statement The 'real' Statement object
     * @param theConn The 'real' Connection object
     */
    protected ReplicatingStatement(Statement statement,
        ReplicatingConnection theConn) {
        wrappedStatement = statement;
        replicatedConnection = theConn;
    }

    /**
     * Getter
     *
     * @return duplicateStatement member, used to replicate a single statement
     */
    protected PreparedStatement getDuplicateStatement() {
        if (duplicateStatement == null) {
            try {
                duplicateStatement = getConnection().prepareStatement(replicatedConnection.getDuplicateInsertStatement());
            } catch (SQLException e) {
                try {
                    if (duplicateStatement != null) {
                        duplicateStatement.close();
                    }
                } catch (SQLException sqle) {
                    System.err.println("Failed to close duplicateStatement");
                }

                System.err.println("Failed to prepare statements");
                e.printStackTrace();
            }
        }

        return duplicateStatement;
    }

    /**
     * Getter
     *
     * @return duplicateStatementWithDescription member, used to replicate a single statement
     */
    protected PreparedStatement getDuplicateStatementWithDescription() {
        if (duplicateStatementWithDescription == null) {
            try {
                duplicateStatementWithDescription = getConnection().prepareStatement(replicatedConnection.getDuplicateInsertWithDescriptionStatement());
            } catch (SQLException e) {
                try {
                    if (duplicateStatementWithDescription != null) {
                        duplicateStatementWithDescription.close();
                    }
                } catch (SQLException sqle) {
                    System.err.println("Failed to close duplicateStatement");
                }

                System.err.println("Failed to prepare statements");
                e.printStackTrace();
            }
        }

        return duplicateStatementWithDescription;
    }

    /**
     * Getter
     *
     * @return duplicateStatementAutoCommit member, used to replicate
     *         statements in  multi-statement transactions
     */
    protected PreparedStatement getDuplicateStatementAutoCommit() {
        if (duplicateStatementAutoCommit == null) {
            try {
                duplicateStatementAutoCommit = getConnection().prepareStatement(replicatedConnection.getDuplicateInsertAutoCommitStatement());
            } catch (SQLException e) {
                try {
                    if (duplicateStatementAutoCommit != null) {
                        duplicateStatementAutoCommit.close();
                    }
                } catch (SQLException sqle) {
                    System.err.println(
                        "Failed to close duplicateStatementAutoCommit");
                }

                System.err.println("Failed to prepare statements");
                e.printStackTrace();
            }
        }

        return duplicateStatementAutoCommit;
    }

    /**
     * Getter
     *
     * @return duplicateStatementWithDescriptionAutoCommit member, used to replicate
     *         statements in  multi-statement transactions
     */
    protected PreparedStatement getDuplicateStatementWithDescriptionAutoCommit() {
        if (duplicateStatementWithDescriptionAutoCommit == null) {
            try {
                duplicateStatementWithDescriptionAutoCommit = getConnection().prepareStatement(replicatedConnection.getDuplicateInsertWithDescriptionAutoCommitStatement());
            } catch (SQLException e) {
                try {
                    if (duplicateStatementWithDescriptionAutoCommit != null) {
                        duplicateStatementWithDescriptionAutoCommit.close();
                    }
                } catch (SQLException sqle) {
                    System.err.println(
                        "Failed to close duplicateStatementAutoCommit");
                }

                System.err.println("Failed to prepare statements");
                e.printStackTrace();
            }
        }

        return duplicateStatementWithDescriptionAutoCommit;
    }
    
    /**
     * Getter
     *
     * @return duplicateStatementWithDescriptionAutoCommit member, used to replicate
     *         statements in  multi-statement transactions
     */
    protected PreparedStatement getDuplicateCDStatementWithDescriptionAutoCommit() {
        if (duplicateCDInsertWithDescriptionAutoCommit == null) {
            try {
            	duplicateCDInsertWithDescriptionAutoCommit = getConnection().prepareStatement(replicatedConnection.getDuplicateCDInsertWithDescriptionAutoCommit());
            } catch (SQLException e) {
                try {
                    if (duplicateCDInsertWithDescriptionAutoCommit != null) {
                    	duplicateCDInsertWithDescriptionAutoCommit.close();
                    }
                } catch (SQLException sqle) {
                    System.err.println(
                        "Failed to close duplicateStatementAutoCommit");
                }

                System.err.println("Failed to prepare statements");
                e.printStackTrace();
            }
        }

        return duplicateCDInsertWithDescriptionAutoCommit;
    }

    /**
     * JDBC 2.0 Adds a SQL command to the current batch of commmands for the
     * statement. This method is optional.
     *
     * @param sql typically this is a static SQL INSERT or UPDATE statement
     *
     * @exception SQLException if a database access error occurs, or the driver
     *            does not support batch statements
     */
    public void addBatch(String sql) throws java.sql.SQLException {
        if (batchedSQL == null) {
            batchedSQL = new ArrayList();
        }

        batchedSQL.add(sql);
        wrappedStatement.addBatch(sql);
    }

    /**
     * JDBC 2.0 Makes the set of commands in the current batch empty. This
     * method is optional.
     *
     * @exception SQLException if a database access error occurs or the driver
     *            does not support batch statements
     */
    public void clearBatch() throws java.sql.SQLException {
        resetBatch();
        wrappedStatement.clearBatch();
    }

    /**
     * JDBC 2.0 Submits a batch of commands to the database for execution. This
     * method is optional.
     *
     * @return an array of update counts containing one element for each
     *         command in the batch.  The array is ordered according to the
     *         order in which commands were inserted into the batch.
     *
     * @exception SQLException if a database access error occurs or the driver
     *            does not support batch statements
     */
    public int[] executeBatch() throws java.sql.SQLException {
       	// If no statements have been batched, pass call directly to
    	// wrappedStatement and let it determine behavior.  No replication
    	if (batchedSQL == null) {
    		return wrappedStatement.executeBatch();
    	}

        if (replicatedConnection.getAutoCommit() == false) {
            duplicateBatch();
            resetBatch();

            return wrappedStatement.executeBatch();
        } else {
            replicatedConnection.setAutoCommit(false);
            duplicateBatch();
            resetBatch();

            int[] retValue = wrappedStatement.executeBatch();
            replicatedConnection.commit();
            replicatedConnection.setAutoCommit(true);

            return retValue;
        }
    }

    /**
     * Cancels this <code>Statement</code> object if both the DBMS and driver
     * support aborting an SQL statement. This method can be used by one
     * thread to cancel a statement that is being executed by another thread.
     *
     * @exception SQLException if a database access error occurs
     */
    public void cancel() throws SQLException {
        wrappedStatement.cancel();
    }

    /**
     * Clears all the warnings reported on this <code>Statement</code> object.
     * After a call to this method, the method <code>getWarnings</code> will
     * return null until a new warning is reported for this Statement.
     *
     * @exception SQLException if a database access error occurs
     */
    public void clearWarnings() throws java.sql.SQLException {
        wrappedStatement.clearWarnings();
    }

    /**
     * Releases this <code>Statement</code> object's database and JDBC
     * resources immediately instead of waiting for this to happen when it is
     * automatically closed. It is generally good practice to release
     * resources as soon as you are finished with them to avoid tying up
     * database resources.
     *
     * <P>
     * <B>Note:</B> A Statement is automatically closed when it is garbage
     * collected. When a Statement is closed, its current ResultSet, if one
     * exists, is also closed.
     * </p>
     *
     * @exception SQLException if a database access error occurs
     */
    public void close() throws java.sql.SQLException {
        wrappedStatement.close();

        if (duplicateStatement != null) {
            duplicateStatement.close();
        }

        if (duplicateStatementAutoCommit != null) {
            duplicateStatementAutoCommit.close();
        }

        if (duplicateStatementWithDescription != null) {
            duplicateStatementWithDescription.close();
        }

        if (duplicateStatementWithDescriptionAutoCommit != null) {
            duplicateStatementWithDescriptionAutoCommit.close();
        }
    }

    /**
     * Executes a SQL statement that may return multiple results. Under some
     * (uncommon) situations a single SQL statement may return multiple result
     * sets and/or update counts.  Normally you can ignore this unless you are
     * (1) executing a stored procedure that you know may return multiple
     * results or (2) you are dynamically executing an unknown SQL string.
     * The  methods <code>execute</code>, <code>getMoreResults</code>,
     * <code>getResultSet</code>, and <code>getUpdateCount</code> let you
     * navigate through multiple results. The <code>execute</code> method
     * executes a SQL statement and indicates the form of the first result.
     * You can then use getResultSet or getUpdateCount to retrieve the result,
     * and getMoreResults to move to any subsequent result(s).
     *
     * @param sql any SQL statement
     *
     * @return true if the next result is a ResultSet; false if it is an update
     *         count or there are no more results
     *
     * @exception SQLException if a database access error occurs
     *
     * @see #getResultSet
     * @see #getUpdateCount
     * @see #getMoreResults
     */
    public boolean execute(String sql) throws java.sql.SQLException {
        if (replicatedConnection.getAutoCommit() == false) {
            replicateStatement(false, sql);

            return wrappedStatement.execute(sql);
        } else {
            replicatedConnection.setAutoCommit(false);
            replicateStatement(true, sql);

            boolean retValue = wrappedStatement.execute(sql);
            replicatedConnection.commit();
            replicatedConnection.setAutoCommit(true);

            return retValue;
        }
    }

    /**
     * Executes a SQL statement that returns a single ResultSet.
     *
     * @param sql typically this is a static SQL SELECT statement
     *
     * @return a ResultSet that contains the data produced by the query; never
     *         null
     *
     * @exception SQLException if a database access error occurs
     */
    public java.sql.ResultSet executeQuery(String sql)
        throws java.sql.SQLException {
        if (replicatedConnection.getAutoCommit() == false) {
            replicateStatement(false, sql);

            return wrappedStatement.executeQuery(sql);
        } else {
            replicatedConnection.setAutoCommit(false);
            replicateStatement(true, sql);

            ResultSet retValue = wrappedStatement.executeQuery(sql);
            replicatedConnection.commit();
            replicatedConnection.setAutoCommit(true);

            return retValue;
        }
    }

    /**
     * Executes an SQL INSERT, UPDATE or DELETE statement. In addition, SQL
     * statements that return nothing, such as SQL DDL statements, can be
     * executed.
     *
     * @param sql a SQL INSERT, UPDATE or DELETE statement or a SQL statement
     *        that returns nothing
     *
     * @return either the row count for INSERT, UPDATE or DELETE or 0 for SQL
     *         statements that return nothing
     *
     * @exception SQLException if a database access error occurs
     */
    public int executeUpdate(String sql) throws java.sql.SQLException {
        if (replicatedConnection.getAutoCommit() == false) {
            replicateStatement(false, sql);

            return wrappedStatement.executeUpdate(sql);
        } else {
            replicatedConnection.setAutoCommit(false);
            replicateStatement(true, sql);

            int retValue = wrappedStatement.executeUpdate(sql);
            replicatedConnection.commit();
            replicatedConnection.setAutoCommit(true);

            return retValue;
        }
    }

    /**
     * JDBC 2.0 Returns the <code>Connection</code> object that produced this
     * <code>Statement</code> object.
     *
     * @return the connection that produced this statement
     *
     * @exception SQLException if a database access error occurs
     */
    public java.sql.Connection getConnection() throws java.sql.SQLException {
        return wrappedStatement.getConnection();
    }

    /**
     * JDBC 2.0 Retrieves the direction for fetching rows from database tables
     * that is the default for result sets generated from this
     * <code>Statement</code> object. If this <code>Statement</code> object
     * has not set a fetch direction by calling the method
     * <code>setFetchDirection</code>, the return value is
     * implementation-specific.
     *
     * @return the default fetch direction for result sets generated from this
     *         <code>Statement</code> object
     *
     * @exception SQLException if a database access error occurs
     */
    public int getFetchDirection() throws java.sql.SQLException {
        return wrappedStatement.getFetchDirection();
    }

    /**
     * JDBC 2.0 Retrieves the number of result set rows that is the default
     * fetch size for result sets generated from this <code>Statement</code>
     * object. If this <code>Statement</code> object has not set a fetch size
     * by calling the method <code>setFetchSize</code>, the return value is
     * implementation-specific.
     *
     * @return the default fetch size for result sets generated from this
     *         <code>Statement</code> object
     *
     * @exception SQLException if a database access error occurs
     */
    public int getFetchSize() throws java.sql.SQLException {
        return wrappedStatement.getFetchSize();
    }

    /**
     * Returns the maximum number of bytes allowed for any column value. This
     * limit is the maximum number of bytes that can be returned for any
     * column value. The limit applies only to BINARY, VARBINARY,
     * LONGVARBINARY, CHAR, VARCHAR, and LONGVARCHAR columns.  If the limit is
     * exceeded, the excess data is silently discarded.
     *
     * @return the current max column size limit; zero means unlimited
     *
     * @exception SQLException if a database access error occurs
     */
    public int getMaxFieldSize() throws java.sql.SQLException {
        return wrappedStatement.getMaxFieldSize();
    }

    /**
     * Retrieves the maximum number of rows that a ResultSet can contain.  If
     * the limit is exceeded, the excess rows are silently dropped.
     *
     * @return the current max row limit; zero means unlimited
     *
     * @exception SQLException if a database access error occurs
     */
    public int getMaxRows() throws java.sql.SQLException {
        return wrappedStatement.getMaxRows();
    }

    /**
     * Moves to a Statement's next result.  It returns true if this result is a
     * ResultSet.  This method also implicitly closes any current ResultSet
     * obtained with getResultSet. There are no more results when
     * (!getMoreResults() && (getUpdateCount() == -1)
     *
     * @return true if the next result is a ResultSet; false if it is an update
     *         count or there are no more results
     *
     * @exception SQLException if a database access error occurs
     *
     * @see #execute
     */
    public boolean getMoreResults() throws java.sql.SQLException {
        return wrappedStatement.getMoreResults();
    }

    /**
     * Retrieves the number of seconds the driver will wait for a Statement to
     * execute. If the limit is exceeded, a SQLException is thrown.
     *
     * @return the current query timeout limit in seconds; zero means unlimited
     *
     * @exception SQLException if a database access error occurs
     */
    public int getQueryTimeout() throws java.sql.SQLException {
        return wrappedStatement.getQueryTimeout();
    }

    /**
     * Returns the current result as a <code>ResultSet</code> object. This
     * method should be called only once per result.
     *
     * @return the current result as a ResultSet; null if the result is an
     *         update count or there are no more results
     *
     * @exception SQLException if a database access error occurs
     *
     * @see #execute
     */
    public java.sql.ResultSet getResultSet() throws java.sql.SQLException {
        return wrappedStatement.getResultSet();
    }

    /**
     * JDBC 2.0 Retrieves the result set concurrency.
     */
    public int getResultSetConcurrency() throws java.sql.SQLException {
        return wrappedStatement.getResultSetConcurrency();
    }

    /**
     * JDBC 2.0 Determine the result set type.
     */
    public int getResultSetType() throws java.sql.SQLException {
        return wrappedStatement.getResultSetType();
    }

    /**
     * Returns the current result as an update count; if the result is a
     * ResultSet or there are no more results, -1 is returned. This method
     * should be called only once per result.
     *
     * @return the current result as an update count; -1 if it is a ResultSet
     *         or there are no more results
     *
     * @exception SQLException if a database access error occurs
     *
     * @see #execute
     */
    public int getUpdateCount() throws java.sql.SQLException {
        return wrappedStatement.getUpdateCount();
    }

    /**
     * Retrieves the first warning reported by calls on this Statement.
     * Subsequent Statement warnings will be chained to this SQLWarning.
     *
     * <p>
     * The warning chain is automatically cleared each time a statement is
     * (re)executed.
     * </p>
     *
     * <P>
     * <B>Note:</B> If you are processing a ResultSet, any warnings associated
     * with ResultSet reads will be chained on the ResultSet object.
     * </p>
     *
     * @return the first SQLWarning or null
     *
     * @exception SQLException if a database access error occurs
     */
    public java.sql.SQLWarning getWarnings() throws java.sql.SQLException {
        return wrappedStatement.getWarnings();
    }

    /**
     * Defines the SQL cursor name that will be used by subsequent Statement
     * <code>execute</code> methods. This name can then be used in SQL
     * positioned update/delete statements to identify the current row in the
     * ResultSet generated by this statement.  If the database doesn't support
     * positioned update/delete, this method is a noop.  To insure that a
     * cursor has the proper isolation level to support updates, the cursor's
     * SELECT statement should be of the form 'select for update ...'. If the
     * 'for update' phrase is omitted, positioned updates may fail.
     *
     * <P>
     * <B>Note:</B> By definition, positioned update/delete execution must be
     * done by a different Statement than the one which generated the
     * ResultSet being used for positioning. Also, cursor names must be unique
     * within a connection.
     * </p>
     *
     * @param name the new cursor name, which must be unique within a
     *        connection
     *
     * @exception SQLException if a database access error occurs
     */
    public void setCursorName(String name) throws java.sql.SQLException {
        wrappedStatement.setCursorName(name);
    }

    /**
     * Sets escape processing on or off. If escape scanning is on (the
     * default), the driver will do escape substitution before sending the SQL
     * to the database. Note: Since prepared statements have usually been
     * parsed prior to making this call, disabling escape processing for
     * prepared statements will have no effect.
     *
     * @param enable true to enable; false to disable
     *
     * @exception SQLException if a database access error occurs
     */
    public void setEscapeProcessing(boolean enable)
        throws java.sql.SQLException {
        wrappedStatement.setEscapeProcessing(enable);
    }

    /**
     * JDBC 2.0 Gives the driver a hint as to the direction in which the rows
     * in a result set will be processed. The hint applies only to result sets
     * created using this Statement object.  The default value is
     * ResultSet.FETCH_FORWARD.
     *
     * <p>
     * Note that this method sets the default fetch direction for result sets
     * generated by this <code>Statement</code> object. Each result set has
     * its own methods for getting and setting its own fetch direction.
     * </p>
     *
     * @param direction the initial direction for processing rows
     *
     * @exception SQLException if a database access error occurs or the given
     *            direction is not one of ResultSet.FETCH_FORWARD,
     *            ResultSet.FETCH_REVERSE, or ResultSet.FETCH_UNKNOWN
     */
    public void setFetchDirection(int direction) throws java.sql.SQLException {
        wrappedStatement.setFetchDirection(direction);
    }

    /**
     * JDBC 2.0 Gives the JDBC driver a hint as to the number of rows that
     * should be fetched from the database when more rows are needed.  The
     * number of rows specified affects only result sets created using this
     * statement. If the value specified is zero, then the hint is ignored.
     * The default value is zero.
     *
     * @param rows the number of rows to fetch
     *
     * @exception SQLException if a database access error occurs, or the
     *            condition 0 'less than or equal' rows 'less than or equal'
     *            this.getMaxRows() is not satisfied.
     */
    public void setFetchSize(int rows) throws java.sql.SQLException {
        wrappedStatement.setFetchSize(rows);
    }

    /**
     * Sets the limit for the maximum number of bytes in a column to the given
     * number of bytes.  This is the maximum number of bytes that can be
     * returned for any column value.  This limit applies only to BINARY,
     * VARBINARY, LONGVARBINARY, CHAR, VARCHAR, and LONGVARCHAR fields.  If
     * the limit is exceeded, the excess data is silently discarded. For
     * maximum portability, use values greater than 256.
     *
     * @param max the new max column size limit; zero means unlimited
     *
     * @exception SQLException if a database access error occurs
     */
    public void setMaxFieldSize(int max) throws java.sql.SQLException {
        wrappedStatement.setMaxFieldSize(max);
    }

    /**
     * Sets the limit for the maximum number of rows that any ResultSet can
     * contain to the given number. If the limit is exceeded, the excess rows
     * are silently dropped.
     *
     * @param max the new max rows limit; zero means unlimited
     *
     * @exception SQLException if a database access error occurs
     */
    public void setMaxRows(int max) throws java.sql.SQLException {
        wrappedStatement.setMaxRows(max);
    }

    /**
     * (non-Javadoc)
     *
     * @see java.sql.Statement#setQueryTimeout(int)
     */
    public void setQueryTimeout(int seconds) throws java.sql.SQLException {
        wrappedStatement.setQueryTimeout(seconds);
    }

    /**
     * (non-Javadoc)
     *
     * @see java.sql.Statement#getResultSetHoldability()
     */
    public int getResultSetHoldability() throws SQLException {
        return wrappedStatement.getResultSetHoldability();
    }

    /**
     * (non-Javadoc)
     *
     * @see java.sql.Statement#getMoreResults(int)
     */
    public boolean getMoreResults(int current) throws SQLException {
        return wrappedStatement.getMoreResults(current);
    }

    /**
     * (non-Javadoc)
     *
     * @see java.sql.Statement#executeUpdate(java.lang.String, int)
     */
    public int executeUpdate(String sql, int autoGeneratedKeys)
        throws SQLException {
        if (replicatedConnection.getAutoCommit() == false) {
            replicateStatement(false, sql);

            return wrappedStatement.executeUpdate(sql, autoGeneratedKeys);
        } else {
            replicatedConnection.setAutoCommit(false);
            replicateStatement(true, sql);

            int retValue = wrappedStatement.executeUpdate(sql, autoGeneratedKeys);
            replicatedConnection.commit();
            replicatedConnection.setAutoCommit(true);

            return retValue;
        }
    }

    /**
     * (non-Javadoc)
     *
     * @see java.sql.Statement#execute(java.lang.String, int)
     */
    public boolean execute(String sql, int autoGeneratedKeys)
        throws SQLException {
        if (replicatedConnection.getAutoCommit() == false) {
            replicateStatement(false, sql);

            return wrappedStatement.execute(sql, autoGeneratedKeys);
        } else {
            replicatedConnection.setAutoCommit(false);
            replicateStatement(true, sql);

            boolean retValue = wrappedStatement.execute(sql, autoGeneratedKeys);
            replicatedConnection.commit();
            replicatedConnection.setAutoCommit(true);

            return retValue;
        }
    }

    /**
     * (non-Javadoc)
     *
     * @see java.sql.Statement#executeUpdate(java.lang.String, int[])
     */
    public int executeUpdate(String sql, int[] columnIndexes)
        throws SQLException {
        if (replicatedConnection.getAutoCommit() == false) {
            replicateStatement(false, sql);

            return wrappedStatement.executeUpdate(sql, columnIndexes);
        } else {
            replicatedConnection.setAutoCommit(false);
            replicateStatement(true, sql);

            int retValue = wrappedStatement.executeUpdate(sql, columnIndexes);
            replicatedConnection.commit();
            replicatedConnection.setAutoCommit(true);

            return retValue;
        }
    }

    /**
     * (non-Javadoc)
     *
     * @see java.sql.Statement#execute(java.lang.String, int[])
     */
    public boolean execute(String sql, int[] columnIndexes)
        throws SQLException {
        if (replicatedConnection.getAutoCommit() == false) {
            replicateStatement(false, sql);

            return wrappedStatement.execute(sql, columnIndexes);
        } else {
            replicatedConnection.setAutoCommit(false);
            replicateStatement(true, sql);

            boolean retValue = wrappedStatement.execute(sql, columnIndexes);
            replicatedConnection.commit();
            replicatedConnection.setAutoCommit(true);

            return retValue;
        }
    }

    /**
     * (non-Javadoc)
     *
     * @see java.sql.Statement#getGeneratedKeys()
     */
    public ResultSet getGeneratedKeys() throws SQLException {
        return wrappedStatement.getGeneratedKeys();
    }

    /**
     * (non-Javadoc)
     *
     * @see java.sql.Statement#executeUpdate(java.lang.String,
     *      java.lang.String[])
     */
    public int executeUpdate(String sql, String[] columnNames)
        throws SQLException {
        if (replicatedConnection.getAutoCommit() == false) {
            replicateStatement(false, sql);

            return wrappedStatement.executeUpdate(sql, columnNames);
        } else {
            replicatedConnection.setAutoCommit(false);
            replicateStatement(true, sql);

            int retValue = wrappedStatement.executeUpdate(sql, columnNames);
            replicatedConnection.commit();
            replicatedConnection.setAutoCommit(true);

            return retValue;
        }
    }

    /**
     * (non-Javadoc)
     *
     * @see java.sql.Statement#execute(java.lang.String, java.lang.String[])
     */
    public boolean execute(String sql, String[] columnNames)
        throws SQLException {
        if (replicatedConnection.getAutoCommit() == false) {
            replicateStatement(false, sql);

            return wrappedStatement.execute(sql, columnNames);
        } else {
            replicatedConnection.setAutoCommit(false);
            replicateStatement(true, sql);

            boolean retValue = wrappedStatement.execute(sql, columnNames);
            replicatedConnection.commit();
            replicatedConnection.setAutoCommit(true);

            return retValue;
        }
    }

    /**
     * Returns the sql statement string (question marks replaced with set
     * parameter values) that will be (or has been) executed by the {@link
     * java.sql.PreparedStatement PreparedStatement} that this
     * <code>LoggableStatement</code> is a wrapper for.
     *
     * <p></p>
     *
     * @return java.lang.String the statemant represented by this
     *         <code>LoggableStatement</code>
     */
    public String getQueryString() {
        return sqlTemplate;
    }

    /**
     * Dumps the ordered list of batch statements
     */
    private void duplicateBatch() throws SQLException {
        Iterator batch = batchedSQL.iterator();

        while (batch.hasNext()) {
            PreparedStatement stmt = getDuplicateStatement();
            String data = (String)batch.next();
            stmt.setBinaryStream(1, new ByteArrayInputStream(data.getBytes()),
                    data.length());
            stmt.setLong(2, replicatedConnection.getTransactionID());
            stmt.setLong(3, replicatedConnection.getNextStatementID());
            stmt.setString(4, "SQL");
            stmt.setString(5, replicatedConnection.getUserName());
            stmt.executeUpdate();
        }
    }

    /**
     * Resets batched statements
     */
    protected void resetBatch() {
        batchedSQL = null;
    }

    /**
     * Inserts literal SQLtext into replication queue
     *
     * @param autoCommit autocommit setting
     * @param data SQL string to insert into replication queue
     *
     * @throws SQLException
     */
    public void replicateStatement(boolean autoCommit, String data)
        throws SQLException {
        replicateStatement(autoCommit, data, "SQL", null);
    }

    /**
     * Inserts data into replication queue, type indicates if data is SQL, XML,
     * BPML or API.
     *
     * @param autoCommit autocommit setting
     * @param data data to replicate
     * @param type type of data being inserted (SQL, XML, BPML, API)
     * @param description optional description for data being inserted
     * @throws SQLException
     */
    public void replicateStatement(boolean autoCommit, String data, String type, String description)
            throws SQLException {
        //System.err.println("replicating [" + data + "]");

        if (autoCommit) {
            PreparedStatement stmt = null;
            if (description != null && description.length() > 0) {
                stmt = getDuplicateStatementWithDescriptionAutoCommit();
                stmt.setString(5, description);
            } else {
                stmt = getDuplicateStatementAutoCommit();
            }
            //System.err.println("Setting stream in PreparedStatement");
            stmt.setBinaryStream(1, new ByteArrayInputStream(data.getBytes()), data.length());
            stmt.setLong(2, replicatedConnection.getNextStatementID());
            stmt.setString(3, type);
            stmt.setString(4, replicatedConnection.getUserName());
            //System.err.println("Executing update");
            stmt.executeUpdate();
        } else {
            PreparedStatement stmt = null;
            if (description != null && description.length() > 0) {
                stmt = getDuplicateStatementWithDescription();
                stmt.setString(6, description);
            } else {
                stmt = getDuplicateStatement();
            }
            //System.err.println("Setting stream in PreparedStatement");
            stmt.setBinaryStream(1, new ByteArrayInputStream(data.getBytes()), data.length());
            stmt.setLong(2, replicatedConnection.getTransactionID());
            stmt.setLong(3, replicatedConnection.getNextStatementID());
            stmt.setString(4, type);
            stmt.setString(5, replicatedConnection.getUserName());
            //System.err.println("Executing update");
            stmt.executeUpdate();
        }

        //System.err.println("Finished replication... returning");
    }
    
    /**
     * Inserts data into cd replication queue, type is BPML
     *
     * @param data data to replicate
     * @param type type of data being inserted (BPML)
     * @param description optional description for data being inserted
     * @param method type of http call(POST,DELETE,PUT)
     * @param uri ssp cm rest service uri
     * @throws SQLException
     */
    public void replicateStatement(String data, String type, String description, String method, String uri, String api)
            throws SQLException {
    	//System.out.println("replicating [" + data + "]");

    	PreparedStatement stmt = null;
    	
    	stmt = getDuplicateCDStatementWithDescriptionAutoCommit();
    	
    	//System.err.println("Setting stream in PreparedStatement");
    	stmt.setBinaryStream(1, new ByteArrayInputStream(data.getBytes()), data.length());
    	//stmt.setLong(2, replicatedConnection.getTransactionID());
    	stmt.setString(2, type);
    	stmt.setString(3, replicatedConnection.getUserName());
    	if(description != null) {
    		stmt.setString(4, description);
    	} else {
    		stmt.setString(4, "");
    	}
    	if(method != null) {
    		stmt.setString(5, method);
    	} else {
    		stmt.setString(5, "");
    	}
    	if(uri != null) {
    		stmt.setString(6, uri);
    	} else {
    		stmt.setString(6, "");
    	}
    	if(api != null) {
    		stmt.setString(7, api);
    	} else {
    		stmt.setString(7, "");
    	}
    	
    	stmt.executeUpdate();

    	//System.err.println("Finished replication... returning");
    }


    /**
     * Getter
     *
     * @return wrappedStatement member
     */
    public Statement getWrappedStatement() {
        return (Statement) wrappedStatement;
    }

	public boolean isClosed() throws SQLException {
		return wrappedStatement.isClosed();
	}

	public void closeOnCompletion() throws SQLException {
		wrappedStatement.closeOnCompletion();
	}
	
	public boolean isCloseOnCompletion() throws SQLException {
		return wrappedStatement.isCloseOnCompletion();
	}
	
	public boolean isPoolable() throws SQLException {
		return wrappedStatement.isPoolable();
	}

	public void setPoolable(boolean pArg0) throws SQLException {
		wrappedStatement.setPoolable(pArg0);
	}

	public boolean isWrapperFor(Class<?> pArg0) throws SQLException {
		return wrappedStatement.isWrapperFor(pArg0);
	}

	public <T> T unwrap(Class<T> pArg0) throws SQLException {
		return wrappedStatement.unwrap(pArg0);
	}
}
