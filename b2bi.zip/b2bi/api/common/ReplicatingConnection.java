
package com.bofa.b2bi.api.common;

import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Date;
import java.sql.NClob;
import java.sql.PreparedStatement;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Savepoint;
import java.sql.Statement;
import java.sql.Struct;
import java.sql.Timestamp;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Executor;

public abstract class ReplicatingConnection implements Connection {
    /**
     * PreparedStatement used to update replication queue table commit column
     */
    private PreparedStatement updateCommitStatement = null;

    /**
     * SQL String used for updateCommitStatement
     */
    private final String UPDATE_COMMIT_FLAG = "update ML_REPLICATION_QUEUE SET COMMIT = 1 WHERE OPERATION_ID = ? and SUB_OPERATION_ID = ?";

    /**
     * UI user's username, stored in replication queue entries
     */
    private String userName = null;



    /**
     * Autocommit status
     */
    private boolean autoCommit = false;

    /**
     * The 'real' Connection object
     */
    protected Connection wrappedConnection = null;

    /**
     * current transaction ID
     */
    protected long transactionID = -1;

    /**
     * current statement id
     */
    protected long statementID = 0;

    /**
     * Constructor takes existing Connection and userName Window - Preferences
     * - Java - Code Style - Code Templates
     *
     * @param conn 'Real' Connection object
     * @param userName username logged with statement
     */
    public ReplicatingConnection(Connection conn, String userName) {
        wrappedConnection = conn;
        this.userName = userName;
    }

    /**
     * Creates a new ReplicatingConnection object.
     *
     * @param conn The 'real' Connection object
     */
    public ReplicatingConnection(Connection conn) {
        wrappedConnection = conn;
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#getHoldability()
     */
    public int getHoldability() throws SQLException {
        
        return wrappedConnection.getHoldability();
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#getTransactionIsolation()
     */
    public int getTransactionIsolation() throws SQLException {
        
        return wrappedConnection.getTransactionIsolation();
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#clearWarnings()
     */
    public void clearWarnings() throws SQLException {
        
        wrappedConnection.clearWarnings();
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#close()
     */
    public void close() throws SQLException {
        
        wrappedConnection.close();
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#commit()
     */
    public void commit() throws SQLException {
        
        if (transactionID != 0) {
            updateCommitFlag();
        }

        wrappedConnection.commit();
        reset();
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#rollback()
     */
    public void rollback() throws SQLException {
        
        wrappedConnection.rollback();
        reset();
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#getAutoCommit()
     */
    public boolean getAutoCommit() throws SQLException {
        
        return wrappedConnection.getAutoCommit();
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#isClosed()
     */
    public boolean isClosed() throws SQLException {
        
        return wrappedConnection.isClosed();
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#isReadOnly()
     */
    public boolean isReadOnly() throws SQLException {
        
        return wrappedConnection.isReadOnly();
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#setHoldability(int)
     */
    public void setHoldability(int holdability) throws SQLException {
        
        wrappedConnection.setHoldability(holdability);
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#setTransactionIsolation(int)
     */
    public void setTransactionIsolation(int level) throws SQLException {
        
        wrappedConnection.setTransactionIsolation(level);
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#setAutoCommit(boolean)
     */
    public void setAutoCommit(boolean autoCommit) throws SQLException {
        
        wrappedConnection.setAutoCommit(autoCommit);
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#setReadOnly(boolean)
     */
    public void setReadOnly(boolean readOnly) throws SQLException {
        
        wrappedConnection.setReadOnly(readOnly);
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#getCatalog()
     */
    public String getCatalog() throws SQLException {
        
        return wrappedConnection.getCatalog();
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#setCatalog(java.lang.String)
     */
    public void setCatalog(String catalog) throws SQLException {
        
        wrappedConnection.setCatalog(catalog);
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#getMetaData()
     */
    public DatabaseMetaData getMetaData() throws SQLException {
        
        return wrappedConnection.getMetaData();
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#getWarnings()
     */
    public SQLWarning getWarnings() throws SQLException {
        
        return wrappedConnection.getWarnings();
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#setSavepoint()
     */
    public Savepoint setSavepoint() throws SQLException {
        
        return wrappedConnection.setSavepoint();
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#releaseSavepoint(java.sql.Savepoint)
     */
    public void releaseSavepoint(Savepoint savepoint) throws SQLException {
        
        wrappedConnection.releaseSavepoint(savepoint);
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#rollback(java.sql.Savepoint)
     */
    public void rollback(Savepoint savepoint) throws SQLException {
        
        wrappedConnection.rollback(savepoint);
        reset();
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#createStatement()
     */
    public Statement createStatement() throws SQLException {
        Statement st = wrappedConnection.createStatement();

        return new ReplicatingStatement(st, this);
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#createStatement(int, int)
     */
    public Statement createStatement(int resultSetType, int resultSetConcurrency)
        throws SQLException {
        Statement st = wrappedConnection.createStatement(resultSetType,
                resultSetConcurrency);

        return new ReplicatingStatement(st, this);
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#createStatement(int, int, int)
     */
    public Statement createStatement(int resultSetType,
        int resultSetConcurrency, int resultSetHoldability)
        throws SQLException {
        
        Statement st = wrappedConnection.createStatement(resultSetType,
                resultSetConcurrency, resultSetHoldability);

        return new ReplicatingStatement(st, this);
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#getTypeMap()
     */
    public Map getTypeMap() throws SQLException {
        
        return wrappedConnection.getTypeMap();
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#setTypeMap(java.util.Map)
     */
    public void setTypeMap(Map map) throws SQLException {
        
        wrappedConnection.setTypeMap(map);
    }

    public int getNetworkTimeout() throws SQLException {
        
        return wrappedConnection.getNetworkTimeout();
    }

    public void setNetworkTimeout(Executor e, int i) throws SQLException {
        
        wrappedConnection.setNetworkTimeout(e,i);
    }
    
    public String getSchema() throws SQLException {
        return wrappedConnection.getSchema();
       
    }

    public void setSchema(String schemaName) throws SQLException {
        
        wrappedConnection.setSchema(schemaName);
    }
 
    public void abort(Executor executor) throws SQLException {};
    
     /* (non-Javadoc)
     * @see java.sql.Connection#nativeSQL(java.lang.String)
     */
    public String nativeSQL(String sql) throws SQLException {
        
        return wrappedConnection.nativeSQL(sql);
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#prepareCall(java.lang.String)
     */
    public CallableStatement prepareCall(String sql) throws SQLException {
        
        return wrappedConnection.prepareCall(sql);
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#prepareCall(java.lang.String, int, int)
     */
    public CallableStatement prepareCall(String sql, int resultSetType,
        int resultSetConcurrency) throws SQLException {
        
        return wrappedConnection.prepareCall(sql, resultSetType,
            resultSetConcurrency);
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#prepareCall(java.lang.String, int, int, int)
     */
    public CallableStatement prepareCall(String sql, int resultSetType,
        int resultSetConcurrency, int resultSetHoldability)
        throws SQLException {
        
        return wrappedConnection.prepareCall(sql, resultSetType,
            resultSetConcurrency, resultSetHoldability);
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#prepareStatement(java.lang.String)
     */
    public PreparedStatement prepareStatement(String sql)
        throws SQLException {
        PreparedStatement ps = wrappedConnection.prepareStatement(sql);

        if (statementIsSelect(sql)) {
            return ps;
        } else {
            return new ReplicatingPreparedStatement(ps, this, sql);
        }
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#prepareStatement(java.lang.String, int)
     */
    public PreparedStatement prepareStatement(String sql, int autoGeneratedKeys)
        throws SQLException {
        PreparedStatement ps = wrappedConnection.prepareStatement(sql,
                autoGeneratedKeys);

        if (statementIsSelect(sql)) {
            return ps;
        } else {
            return new ReplicatingPreparedStatement(ps, this, sql);
        }
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#prepareStatement(java.lang.String, int, int)
     */
    public PreparedStatement prepareStatement(String sql, int resultSetType,
        int resultSetConcurrency) throws SQLException {
        PreparedStatement ps = wrappedConnection.prepareStatement(sql,
                resultSetType, resultSetConcurrency);

        if (statementIsSelect(sql)) {
            return ps;
        } else {
            return new ReplicatingPreparedStatement(ps, this, sql);
        }
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#prepareStatement(java.lang.String, int, int, int)
     */
    public PreparedStatement prepareStatement(String sql, int resultSetType,
        int resultSetConcurrency, int resultSetHoldability)
        throws SQLException {
        PreparedStatement ps = wrappedConnection.prepareStatement(sql,
                resultSetType, resultSetConcurrency, resultSetHoldability);

        if (statementIsSelect(sql)) {
            return ps;
        } else {
            return new ReplicatingPreparedStatement(ps, this, sql);
        }
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#prepareStatement(java.lang.String, int[])
     */
    public PreparedStatement prepareStatement(String sql, int[] columnIndexes)
        throws SQLException {
        PreparedStatement ps = wrappedConnection.prepareStatement(sql,
                columnIndexes);

        if (statementIsSelect(sql)) {
            return ps;
        } else {
            return new ReplicatingPreparedStatement(ps, this, sql);
        }
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#setSavepoint(java.lang.String)
     */
    public Savepoint setSavepoint(String name) throws SQLException {
        
        return wrappedConnection.setSavepoint(name);
    }

    /* (non-Javadoc)
     * @see java.sql.Connection#prepareStatement(java.lang.String, java.lang.String[])
     */
    public PreparedStatement prepareStatement(String sql, String[] columnNames)
        throws SQLException {
        PreparedStatement ps = wrappedConnection.prepareStatement(sql,
                columnNames);

        if (statementIsSelect(sql)) {
            return ps;
        } else {
            return new ReplicatingPreparedStatement(ps, this, sql);
        }
    }

    /**
     * Getter
     *
     * @return userName member
     */
    public String getUserName() {
        return userName;
    }
    
    public Struct createStruct(String pArg0, Object[] pArg1)
			throws SQLException {
		return wrappedConnection.createStruct(pArg0, pArg1);
	}

	public Clob createClob() throws SQLException {
		return wrappedConnection.createClob();
	}

	public Blob createBlob() throws SQLException {
		return wrappedConnection.createBlob();
	}

	public SQLXML createSQLXML() throws SQLException {
		return wrappedConnection.createSQLXML();
	}

	public boolean isWrapperFor(Class<?> pArg0) throws SQLException {
		return wrappedConnection.isWrapperFor(pArg0);
	}

	public <T> T unwrap(Class<T> pArg0) throws SQLException {
		return wrappedConnection.unwrap(pArg0);
	}

	public Array createArrayOf(String pArg0, Object[] pArg1)
			throws SQLException {
		return wrappedConnection.createArrayOf(pArg0, pArg1);
	}

	public NClob createNClob() throws SQLException {
		return wrappedConnection.createNClob();
	}

	public Properties getClientInfo() throws SQLException {
		return wrappedConnection.getClientInfo();
	}

	public String getClientInfo(String pArg0) throws SQLException {
		return wrappedConnection.getClientInfo(pArg0);
	}

	public void setClientInfo(Properties pArg0) throws SQLClientInfoException {
		wrappedConnection.setClientInfo(pArg0);
	}

	public void setClientInfo(String pArg0, String pArg1)
			throws SQLClientInfoException {
		wrappedConnection.setClientInfo(pArg0, pArg1);
	}

	public boolean isValid(int pArg0) throws SQLException {
		return wrappedConnection.isValid(pArg0);
	}

	/**
     * Determines if statement is a 'select' statement and thus does not need to be replicated
     *
     * @param sql SQL statement to check
     *
     * @return true if statement starts with "select" (case insensitive), false otherwise
     */
    private boolean statementIsSelect(String sql) {
        if ((sql.trim().toUpperCase()).startsWith("SELECT")) {
            return true;
        }

        return false;
    }

    /**
     * Getter
     *
     * @return wrappedConnection memeber
     */
    public Connection getWrappedConnection() {
        return wrappedConnection;
    }

    /**
     * Closes this object's Statements
     */
    public void discard() {
        try {
            if (updateCommitStatement != null) {
                updateCommitStatement.close();
            }
        } catch (SQLException sqle) {
        }

        updateCommitStatement = null;
    }

    /**
     * Getter
     *
     * @return duplicateInsertStatement member
     */
    public abstract String getDuplicateInsertStatement();

    /**
     * Getter
     *
     * @return duplicateInsertWithDescriptionStatement member
     */
    public abstract String getDuplicateInsertWithDescriptionStatement();

    /**
     * Getter
     *
     * @return duplicateInsertAutoCommitStatement
     */
    public abstract String getDuplicateInsertAutoCommitStatement();

    /**
     * Getter
     *
     * @return duplicateInsertWithDescriptionAutoCommitStatement
     */
    public abstract String getDuplicateInsertWithDescriptionAutoCommitStatement();
    
    
    /**
     * Getter
     *
     * @return duplicateCDInsertWithDescriptionAutoCommit
     */
    public abstract String getDuplicateCDInsertWithDescriptionAutoCommit();

    /**
     * Formats a Date object into a string for inclusion in SQL insert
     *
     * @param theDate 
     *
     * @return a String representation of the Date
     */
    public abstract String formatDate(Date theDate);

    /**
     * Formats a Timestamp object into a string for inclusion in SQL insert
     *
     * @param theTimestamp 
     *
     * @return a String representation of the Timestamp
     */
    public abstract String formatTimestamp(Timestamp theTimestamp);

    /**
     * Returns unique transaction id
     *
     * @return unique long
     *
     * @throws SQLException 
     */
    protected abstract long obtainTransactionID() throws SQLException;

    /**
     * Updates the commit flag on the current transaction id
     *
     * @throws SQLException 
     */
    private void updateCommitFlag() throws SQLException {
        if (updateCommitStatement == null) {
            updateCommitStatement = wrappedConnection.prepareStatement(UPDATE_COMMIT_FLAG);
        }

        updateCommitStatement.setLong(1, transactionID);
        updateCommitStatement.setLong(2, statementID);
        updateCommitStatement.execute();
    }

    /**
     * Returns current transaction id, creating a new ID if no active transaction
     *
     * @return transaction id
     *
     * @throws SQLException DOCUMENT ME!
     */
    protected long getTransactionID() throws SQLException {
        if (transactionID == -1) {
            transactionID = obtainTransactionID();
        }

        return transactionID;
    }

    /**
     * Returns next statement ID
     *
     * @return next statement ID
     */
    protected long getNextStatementID() {
        return ++statementID;
    }

    /**
     * Resets transaction ID and statement ID.  Must be called after commit or rollback to reset state
     */
    private void reset() {
        transactionID = -1;
        statementID = 0;
    }
}
