package com.bofa.b2bi.api.dao.impl;

import java.io.StringWriter;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.springframework.stereotype.Repository;

import com.bofa.b2bi.api.dao.ChangePasswordDao;
import com.bofa.b2bi.api.error.B2BIError;
import com.bofa.b2bi.api.exception.B2BIException;
import com.bofa.b2bi.api.exception.BusinessValidationException;
import com.bofa.b2bi.api.model.ChangePasswordRequest;
import com.bofa.b2bi.api.model.User;

@Repository
public class ChangePasswordDaoImpl implements ChangePasswordDao {

	@Override
	public void changePassword(ChangePasswordRequest changePasswordRequest) {

		// Set details to User object to pass back-end.
		User user = new User();

		user.setLoginid(changePasswordRequest.getUserName());
		user.setExistingPassword(changePasswordRequest.getOldPassword());
		user.setPassword(changePasswordRequest.getNewPassword());
		user.setUserKey("");

		Client client = ClientBuilder.newClient();
		WebTarget target = client
				.target(UriBuilder.fromUri("http://clear-as-1-3-s.bankofamerica.com:9443/ChangePassword"));

		try {

			final StringWriter writer = new StringWriter();

			JAXBContext context = JAXBContext.newInstance(User.class);
			Marshaller m = context.createMarshaller();
			m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			m.marshal(user, writer);
			System.out.println("xml :" + writer.toString());

			// <User ExistingPassword="test@3_12" Loginid="swetha123"
			// Password="test@4_12" UserKey=""></User>
			Response response = target.request().post(Entity.entity(writer.toString(), MediaType.APPLICATION_XML),
					Response.class);
			if (response.getStatus() == 400) {
				throw new BusinessValidationException(B2BIError.INVALID_PASSWORD, "We have issues in updating user password, Please try again.");
			}
			
		} catch (JAXBException ex) {
			throw new B2BIException("Internal server error occured while updating user password. Please contact administrator");
		}

	}

}
