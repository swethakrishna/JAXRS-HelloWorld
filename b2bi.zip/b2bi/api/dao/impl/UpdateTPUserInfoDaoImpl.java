/**
 * 
 */
package com.bofa.b2bi.api.dao.impl;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.bofa.b2bi.api.dao.UpdateTPUserInfoDao;
import com.bofa.b2bi.api.model.ClassTP;
import com.bofa.b2bi.api.model.TPUserInfo;
import com.bofa.b2bi.api.model.UserInfo;

/**
 * @author zkf2bey
 *
 */
@Repository
public class UpdateTPUserInfoDaoImpl implements UpdateTPUserInfoDao {

	// private WebTarget webTarget;
	//
	// @Inject
	// public UpdateTPUserInfoDaoImpl(final Client client) {
	// final UriBuilder uri =
	// UriBuilder.fromUri("http://localhost:8282/clear/updatetp");
	// this.webTarget = client.target(uri);
	// }

	/**
	 * This method updates given TP user information.
	 * 
	 * @param userInfo
	 * 
	 * 
	 */
	@Override
	public void updateTPUserInfo(UserInfo userInfo) {
		// 1. connect to RestAPI2 to update UserInfo.
		// 2. it needs URL, Headers, UpdateBody.

		ClassTP classTP = new ClassTP();

		if (StringUtils.isNotBlank(userInfo.getAliasName())) {
			classTP.setAlias(userInfo.getAliasName());
		}
		if (StringUtils.isNotBlank(userInfo.getName())) {
			classTP.setName(userInfo.getName());
		}
		if (StringUtils.isNotBlank(userInfo.getFirstName())) {
			classTP.setFname(userInfo.getFirstName());
		}
		if (StringUtils.isNotBlank(userInfo.getLastName())) {
			classTP.setLname(userInfo.getLastName());
		}
		if (StringUtils.isNotBlank(userInfo.getEmail())) {
			classTP.setEmail(userInfo.getEmail());
		}
		if (StringUtils.isNotBlank(userInfo.getPager())) {
			classTP.setPager(userInfo.getPager());
		}
		if (StringUtils.isNotBlank(userInfo.getPhoneNumber())) {
			classTP.setPhonenumber(userInfo.getPhoneNumber());
		}
		if (StringUtils.isNotBlank(userInfo.getAddress1())) {
			classTP.setAddress1(userInfo.getAddress1());
		}
		if (StringUtils.isNotBlank(userInfo.getAddress2())) {
			classTP.setAddress2(userInfo.getAddress2());
		}
		if (StringUtils.isNotBlank(userInfo.getCity())) {
			classTP.setCity(userInfo.getCity());
		}
		if (StringUtils.isNotBlank(userInfo.getState())) {
			classTP.setState(userInfo.getState());
		}
		if (StringUtils.isNotBlank(userInfo.getZipCode())) {
			classTP.setZipcode(userInfo.getZipCode());
		}
		// classTP.setPgpkey(dont have this as of now);

		TPUserInfo updateTPUserInfo = new TPUserInfo();
		updateTPUserInfo.setClassTP(classTP);
		// update fields using Token.
		updateTPUserInfo.setToken("RFRTLVBQLVNUQUdFMQo=");
		updateTPUserInfo.setPlatform("B2BISIT");

		// Create client connection using webtarget
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target(UriBuilder.fromUri("http://localhost:8282/clear/updatetp"));

		try {
			Response response = target.request().header("Accept", "application/json")
					.header("Content-Type", "application/json").post(Entity.json(updateTPUserInfo), Response.class);
			System.out.println(response);
		} catch (Exception ex) {
			throw ex;
		}

	}

}
