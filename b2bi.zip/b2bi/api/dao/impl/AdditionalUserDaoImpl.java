/**
 * 
 */
package com.bofa.b2bi.api.dao.impl;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.springframework.stereotype.Repository;

import com.bofa.b2bi.api.dao.AdditionalUserDao;
import com.bofa.b2bi.api.model.ClassADU;
import com.bofa.b2bi.api.model.TPUserInfo;
import com.bofa.b2bi.api.model.UserInfo;
import com.bofa.dts.transact.crypt.Encrypt;

/**
 * @author zkf2bey
 *
 */

@Repository
public class AdditionalUserDaoImpl implements AdditionalUserDao {

	@Override
	public void createAdditionalUserInfo(UserInfo userInfo) {

		ClassADU classADU = new ClassADU();

		classADU.setClientAlias(userInfo.getAliasName());
		classADU.setFname(userInfo.getFirstName());
		classADU.setLname(userInfo.getLastName());
		classADU.setEmail(userInfo.getEmail());
		classADU.setGisUser(userInfo.getUserName());
		classADU.setGisUserPassword(Encrypt.encrypt(userInfo.getGisUserPassword()));
		System.out.println("encrypted GisUserPassword for: " + userInfo.getGisUserPassword() + " is: "
				+ classADU.getGisUserPassword());

		TPUserInfo updateTPUserInfo = new TPUserInfo();

		updateTPUserInfo.setClassADU(classADU);
		// update fields using Token.
		updateTPUserInfo.setToken("RFRTLVBQLVNUQUdFMQo=");
		updateTPUserInfo.setPlatform("B2BISIT");

		// Create client connection using webtarget
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target(UriBuilder.fromUri("http://localhost:8282/clear/adu"));

		try {
			// ObjectMapper mapper = new ObjectMapper();
			// System.out.println(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(updateTPUserInfo));
			Response response = target.request().header("Accept", "application/json")
					.header("Content-Type", "application/json").post(Entity.json(updateTPUserInfo), Response.class);
			System.out.println(response);
		} catch (Exception ex) {
			try {
				throw ex;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
