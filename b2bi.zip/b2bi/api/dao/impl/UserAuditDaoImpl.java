package com.bofa.b2bi.api.dao.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bofa.b2bi.api.dao.UserAuditDao;
import com.bofa.b2bi.api.exception.B2BIException;
import com.bofa.b2bi.api.model.UserAudit;
import com.bofa.b2bi.api.util.DBUtil;

@Repository
public class UserAuditDaoImpl implements UserAuditDao {

	@Autowired
	DataSource ds;

	@Override
	public UserAudit createUserAudit(UserAudit userAudit) {

		String sql = "insert into B2BI_USER_AUDIT (ID, USER_NAME, SESSION_ID, LOGIN_TIME, LOGOUT_TIME, ERROR_MESSAGE, BROWSER_TYPE, CLIENT_IP_ADDRESS) VALUES (B2BI_USER_AUDIT_ID_SEQ.nextval, ?, ?, ?, ?, ?, ?, ?)";
		Connection conn = null;
		PreparedStatement ps = null;

		try {
			conn = DBUtil.getConnection(userAudit.getUserName());
			conn.setAutoCommit(false);
			ps = conn.prepareStatement(sql);
			ps.setString(1, userAudit.getUserName());
			ps.setString(2, userAudit.getSessionId());
			ps.setDate(3, Date.valueOf(LocalDate.now()));
			ps.setDate(4, null);// Needs to be implemented
			ps.setString(5, userAudit.getErrorMessage());
			ps.setString(6, userAudit.getBrowserType().name());
			ps.setString(7, userAudit.getClientIPAddress());
			ps.executeQuery();
			conn.commit();
			userAudit.setId(getSequenceId(conn));
			ps.close();

		} catch (SQLException e) {
			DBUtil.rollback(conn);
			throw new RuntimeException(e);

		} catch (B2BIException ex) {
			DBUtil.rollback(conn);
			ex.printStackTrace();

		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return userAudit;

	}

	@Override
	public void updateUserAudit(UserAudit userAudit) {
		String sql = "update B2BI_USER_AUDIT set ERROR_MESSAGE = ? where ID = ?";
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = ds.getConnection();
			ps = conn.prepareStatement(sql);
			ps.setString(1, userAudit.getErrorMessage());
			ps.setLong(2, userAudit.getId());
			ps.executeUpdate();

		} catch (SQLException e) {
			throw new RuntimeException(e);

		} catch (B2BIException ex) {
			throw ex;

		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}

	}

	private long getSequenceId(Connection conn) throws SQLException {
		String sqlIdentifier = "select B2BI_USER_AUDIT_ID_SEQ.CURRVAL from dual";
		PreparedStatement ps = conn.prepareStatement(sqlIdentifier);
		long myId = -1L;
		synchronized (this) {
			ResultSet rs = ps.executeQuery();
			if (rs.next())
				myId = rs.getLong(1);
		}
		ps.close();
		return myId;
	}

}
