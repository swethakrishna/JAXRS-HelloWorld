package com.bofa.b2bi.api.dao.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.stereotype.Repository;

import com.bofa.b2bi.api.dao.CertificateDao;
import com.bofa.b2bi.api.model.CertificateDetails;

@Repository
public class CertificateDaoImpl implements CertificateDao {

	@Autowired
	private JdbcOperations jdbcOperations;
	
	@Override
	public List<CertificateDetails> loadUserCertificates(String typeOfCert) 
	{
		String sqlQuery = null;
		
		if(typeOfCert.equals("SSHKey")) {
		} else if(typeOfCert.equals("FTPSSLCert")) {
		} else if(typeOfCert.equals("CDSSLCert")) {
		} else if(typeOfCert.equals("AS2Cert")) {
		} else if(typeOfCert.equals("PGPKey")) {
			sqlQuery = "SELECT KEY_ID, KEYMAP_NAME, EXPIRATION_DATE, FINGER_PRINT, PGP_ID FROM ML_PGP_KEYS WHERE EXPIRATION_DATE > SYSDATE ORDER BY EXPIRATION_DATE DESC";
		} else {
		}
		
		Object params[] = new Object[]{ };
		DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
		
		List<CertificateDetails> certificateList = new ArrayList<>(); 
		if(sqlQuery != null) {
			certificateList = jdbcOperations.query(sqlQuery, params, (resultSet, rowNum) -> {
				CertificateDetails keyDetails = new CertificateDetails();
				keyDetails.setKeyId(resultSet.getString("KEY_ID"));
				keyDetails.setKeyName(resultSet.getString("KEYMAP_NAME"));
				keyDetails.setExpDate(dateFormat.format(resultSet.getTimestamp("EXPIRATION_DATE")));
				keyDetails.setFingerPrint(resultSet.getString("FINGER_PRINT"));
				keyDetails.setPgpId(resultSet.getString("PGP_ID"));
			    return keyDetails;
			});
		}

		return certificateList;
	}

	@Override
	public String loadUserCertificateById(String certId) 
	{
		String sqlQuery = "SELECT PUBLIC_KEY FROM ML_PGP_KEYS where KEY_ID = ?";
		Object params[] = new Object[]{ certId };
		
		String certPubKey = jdbcOperations.query(sqlQuery, params, (resultSet, rowNum) -> {
			return resultSet.getString("PUBLIC_KEY");
		}).get(0);
		return certPubKey;
	}

}
