package com.bofa.b2bi.api.dao.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.bofa.b2bi.api.dao.UserInfoDao;
import com.bofa.b2bi.api.exception.B2BIException;
import com.bofa.b2bi.api.model.UserConfig;
import com.bofa.b2bi.api.model.UserInfo;
import com.bofa.b2bi.api.util.Constants;

@Repository
public class UserInfoDaoImpl implements UserInfoDao {

	@Autowired
	private JdbcOperations jdbcOperations;
	
	@Autowired 
	private DataSource ds;

	private static final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
	private static final String DB_CONNECTION = "jdbc:oracle:thin:@//lcdra0fzc01-scan:49125/B2BI1S";
	private static final String DB_USER = "CLEAR_ADMIN_TEST";
	private static final String DB_PASSWORD = "B2BI_SIT_ADMIN";

	@Override
	public UserInfo getUser(String userName) {
		String query = "SELECT * FROM ML_CLIENT WHERE GIS_USER = ?";
		Connection conn = null;
		UserInfo user = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = ds.getConnection();
			ps = conn.prepareStatement(query);
			ps.setString(1, userName);
			rs = ps.executeQuery();

			while (rs.next()) {
				user = new UserInfo();
				user.setUserName(rs.getString("GIS_USER"));
				user.setClientId(rs.getString("CLIENT_ID"));
				user.setUserType(rs.getString("TYPE"));
				user.setName(rs.getString("NAME"));
				user.setAliasName(rs.getString("ALIAS"));
				user.setFirstName(rs.getString("FNAME"));
				user.setLastName(rs.getString("LNAME"));
				user.setEmail(rs.getString("EMAIL"));
				user.setPhoneNumber(rs.getString("PHONE_NUMBER"));
				user.setPager(rs.getString("PAGER"));
				user.setAddress1(rs.getString("ADDRESS_1"));
				user.setAddress2(rs.getString("ADDRESS_2"));
				user.setCity(rs.getString("CITY"));
				user.setState(rs.getString("STATE"));
				user.setZipCode(rs.getString("ZIP_CODE"));

			}
			rs.close();
			ps.close();
			return user;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (conn != null) {
				try {
				conn.close();
				} catch (SQLException e) {}
			}
		}
	}

	public List<String> getAdditionalDropOffUsers(String clientId) {
		String query = "SELECT * FROM ML_USER WHERE CLIENT_ID = ?";
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<String> users = null;
		try {
			conn = ds.getConnection();
			ps = conn.prepareStatement(query);
			ps.setString(1, clientId);
			rs = ps.executeQuery();
			users = new ArrayList<>();
			while (rs.next()) {
				users.add(rs.getString("GIS_USER"));
			}
			rs.close();
			ps.close();
			return users;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (conn != null) {
				try {
				conn.close();
				} catch (SQLException e) {}
			}
		}
	}

	@Override
	public UserInfo updateUserInfo(String userClientId, UserInfo userInfo) throws Exception {

		PreparedStatement preparedStatement = null;

		String sqlQueryforUpdate = "update ML_CLIENT set  NAME = ?, FNAME = ?, LNAME = ?, PAGER = ?, PHONE_NUMBER = ?, EMAIL = ? where CLIENT_ID = ?";

		// Prepare DB Connection.
		Connection conn = getDBConnection();

		try {
			preparedStatement = conn.prepareStatement(sqlQueryforUpdate, ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);

			preparedStatement.setString(1, userInfo.getName());
			preparedStatement.setString(2, userInfo.getFirstName());
			preparedStatement.setString(3, userInfo.getLastName());
			preparedStatement.setString(4, userInfo.getPager());
			preparedStatement.setString(5, userInfo.getPhoneNumber());
			preparedStatement.setString(6, userInfo.getEmail());
			preparedStatement.setString(7, userClientId);

			System.out.println("preparedStatement:: " + preparedStatement);

			preparedStatement.executeUpdate();

		} catch (SQLException ex) {
			// logger.error("failed to update userInformation SQLException: " +
			// ex);
			throw new Exception("We have issues in updating user information.");
		} catch (Exception ex) {
			// logger.error("failed to update userInformation Exception: " +
			// ex);
			throw new Exception("We have issues in updating user information.");
		} finally {
			// logger.info("closing DB connections.");
			preparedStatementClose(preparedStatement);
			// logger.info("closed DB connections.");
		}

		return userInfo;

	}

	/**
	 * Method to get user Last Login time From ---- Table.
	 * 
	 * @param userName
	 * @param conn
	 * 
	 * @return String - Last login Time
	 * 
	 * @throws Exception
	 */
	// Displaying last logged in time.
	private String getUserLastLoginTime(String userName, Connection connForLastLogin) {
		PreparedStatement preparedStatement = null;
		ResultSet result = null;
		String lastLogin = null;
		try {
			// Prepare SQL Query for DB.
			String sqlQuery = "SELECT * FROM YFS_USER_ACT_AUDIT WHERE USER_ID = 'rptp_baclrt'";
			System.out.println("sqlQueryForML_USER:: " + sqlQuery);
			preparedStatement = connForLastLogin.prepareStatement(sqlQuery, ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);

			userName = "rptp_baclrt";
			// preparedStatement.setString(1, userName);
			System.out.println("preparedStatement:: " + preparedStatement);
			result = preparedStatement.executeQuery();
			System.out.println("userName: " + userName);
			System.out.println("preparedStatement:: " + preparedStatement);

			while (result.next()) {
				System.out.println("DB call Success.");
				String userName1 = result.getString("USER_ID");
				System.out.println("username1:" + userName1);
				Date lastAccessDate = result.getDate("LAST_ACTIVE_TIME");
				System.out.println("lastAccessDate: " + lastAccessDate);
				lastLogin = new SimpleDateFormat(Constants.LAST_LOGIN_TIME_FORMAT).format(lastAccessDate);
				System.out.println("User : " + userName + " Last Login Date and Time : " + lastLogin);
			}
		} catch (SQLException ex) {
			// logger.error("failed to get last logged in time Exception: " +
			// ex);
			throw new B2BIException("We have issues getting in lastloggedin time.");
		} catch (Exception ex) {
			// logger.error("failed to get last logged in time Exception: " +
			// ex);
			throw new B2BIException("We have issues getting in lastloggedin time.");
		} finally {
			// logger.info("closing DB connections.");
			resultSetClose(result);
			preparedStatementClose(preparedStatement);
			// logger.info("closed DB connections.");
		}
		return lastLogin;
	}

	/**
	 * Get DB connetion.
	 *
	 */
	private static Connection getDBConnection() {

		Connection dbConnection = null;

		try {
			Class.forName(DB_DRIVER);
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}

		try {
			dbConnection = DriverManager.getConnection(DB_CONNECTION, DB_USER, DB_PASSWORD);
			return dbConnection;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		return dbConnection;

	}

	/**
	 * Get DB connetion.
	 *
	 */
	private static Connection getDBConnectionForLoginTime() {

		Connection dbConnection = null;

		try {
			Class.forName(DB_DRIVER);
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}

		try {
			// "jdbc:oracle:thin:@//TXB2BIDDB01-scan:49125/B2BI1D";
			String DB_Connection_Last_Login = "jdbc:oracle:thin:@//LRDNA0XLC01-scan:49125/B2BI1U";
			String DB_User_Last_Login = "GIS_ADMIN_TEST";
			String DB_Password_Last_Login = "B2BI_UAT_ADMIN";

			dbConnection = DriverManager.getConnection(DB_Connection_Last_Login, DB_User_Last_Login,
					DB_Password_Last_Login);

			return dbConnection;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		return dbConnection;

	}

	/**
	 * Closes a ResultSet object
	 *
	 * @param result
	 *            ResultSet to be closed
	 */
	public static void resultSetClose(ResultSet result) {
		try {
			if (result != null) {
				result.close();
			}
		} catch (SQLException sqle) {
			System.err.println("Failed to close resultSet");
		}
	}

	/**
	 * Closes a Statement object
	 *
	 * @param stmt
	 *            Statement to be closed
	 */
	public static void preparedStatementClose(Statement stmt) {
		try {
			if (stmt != null) {
				stmt.close();
			}
		} catch (SQLException sqle) {
			System.err.println("Failed to close (prepared)Statement");
		}
	}

	private class UserConfigRowMapper implements RowMapper<UserConfig> {
		public UserConfig mapRow(ResultSet rs, int rowNum) throws SQLException {
			UserConfig userConfig = new UserConfig();
			userConfig.setId(rs.getInt("ID"));
			userConfig.setSshkeyConf(rs.getInt("CHANGE_SSH_KEY") == 0 ? false : true);
			userConfig.setPgpkeyConf(rs.getInt("CHANGE_PGP_KEY") == 0 ? false : true);
			userConfig.setCdconf(rs.getInt("CHANGE_CD_CONFIG") == 0 ? false : true);
			userConfig.setAs2Conf(rs.getInt("CHANGE_AS2_CONFIG") == 0 ? false : true);
			userConfig.setChangeReqConf(rs.getInt("CHANGE_REQUEST") == 0 ? false : true);
			userConfig.set_3SKeyConf(rs.getInt("MANAGE_3S_KEY") == 0 ? false : true);
			return userConfig;
		}
	}

	@Override
	public String findUserRole(String userName) {
		String userRole = jdbcOperations.queryForObject(
				"SELECT ROLE_NAME FROM ROLES WHERE ID IN(SELECT ROLE_ID FROM USER_ROLE WHERE USER_ID IN(SELECT ID FROM USERS WHERE USER_NAME = ?))",
				new String[] { userName }, String.class);
		return userRole;
	}

	@Override
	public UserConfig loadUserConfig(String userName) {
		UserConfig userConfig = jdbcOperations
				.query("SELECT * FROM USERS WHERE USER_NAME = ?", new String[] { userName }, new UserConfigRowMapper())
				.get(0);
		if (userConfig != null) {
			String userRole = jdbcOperations.queryForObject(
					"SELECT ROLE_NAME FROM ROLES WHERE ID IN(SELECT ROLE_ID FROM USER_ROLE WHERE USER_ID = ?)",
					new Integer[] { userConfig.getId() }, String.class);
			userConfig.setRole(userRole);
		}
		return userConfig;
	}
}
