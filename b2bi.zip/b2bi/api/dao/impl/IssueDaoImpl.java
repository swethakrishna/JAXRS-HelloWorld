package com.bofa.b2bi.api.dao.impl;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bofa.b2bi.api.dao.IssueDao;
import com.bofa.b2bi.api.dto.IssueDto;
import com.bofa.b2bi.api.exception.B2BIException;
import com.bofa.b2bi.api.model.Issue;
import com.bofa.b2bi.api.util.CommonUtility;
import com.bofa.b2bi.api.util.DBUtil;

@Component
public class IssueDaoImpl implements IssueDao {

	@Autowired
	DataSource ds;
	
	@Override
	public Long create(IssueDto iRequest, InputStream is) {
		String sql = "INSERT INTO b2bi_issues " +
				"(issue_id, identified_by_person_id, issue_subject, issue_description, identified_date, status, created_on, issue_type, attachment) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		Connection conn = null;
		Long ticketId = null;
		try {
			conn = DBUtil.getConnection(iRequest.getUserId());
			ticketId = getIssueId(conn);
			conn.setAutoCommit(false);
			byte[] noOfbytes = CommonUtility.getBytes(is);
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setLong(1, ticketId);
			ps.setString(2, iRequest.getUserId());
			ps.setString(3, iRequest.getSubject());
			ps.setString(4, iRequest.getDescription());
			ps.setDate(5, Date.valueOf(LocalDate.now()));
			ps.setString(6, "OPEN");
			ps.setDate(7, Date.valueOf(LocalDate.now()));
			ps.setString(8, iRequest.getIssueType());
			ps.setBinaryStream(9, new ByteArrayInputStream(noOfbytes ), noOfbytes.length);
			ps.executeUpdate();
			conn.commit();
			ps.close();
			
		} catch (SQLException e) {
			DBUtil.rollback(conn);
			throw new RuntimeException(e);

		} catch (B2BIException ex) {
			DBUtil.rollback(conn);
			ex.printStackTrace();

		} catch (IOException io) {
			// TODO Auto-generated catch block
			io.printStackTrace();
		}finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {}
			}
		}
		return ticketId;
	}

	@Override
	public List<Issue> getAll(String userName) {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM b2bi_issues WHERE identified_by_person_id = ?";
		List<Issue> issues = null;
		Connection conn = null;

		try {
			conn = ds.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, userName);
			ResultSet rs = ps.executeQuery();
			issues = new ArrayList<>();
			while (rs.next()) {
				Issue issue = new Issue();
				issue.setIssueId(rs.getInt("issue_id"));
				issue.setSubject(rs.getString("issue_subject"));
				issue.setDescription(rs.getString("issue_description"));
				issue.setStatus(rs.getString("status"));
				issue.setIdentifiedDate(rs.getDate("identified_date").toLocalDate());
				issue.setIssueType(rs.getString("issue_type"));
				issues.add(issue);
			}
			rs.close();
			ps.close();
			return issues;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (conn != null) {
				try {
				conn.close();
				} catch (SQLException e) {}
			}
		}
	}
	
	private long getIssueId(Connection conn) throws SQLException{
		String sqlIdentifier = "select issue_id_seq.nextval from dual";
		PreparedStatement ps = conn.prepareStatement(sqlIdentifier);
		long myId = -1L;
		synchronized( this ) {
		   ResultSet rs = ps.executeQuery();
		   if(rs.next())
		     myId = rs.getLong(1);	
		}
		ps.close();
		return myId;
	}

}
