package com.bofa.b2bi.api.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.bofa.b2bi.api.dao.TransmissionReportDao;
import com.bofa.b2bi.api.model.TransmissionDTO;
import com.bofa.b2bi.api.util.DaoUtility;

@Repository
public class TransmissionReportDaoImpl implements TransmissionReportDao {
	
	 @Autowired 
	 private Properties configProps;
	 
	 @Autowired
	 private JdbcOperations jdbcOperations;
	
	 String EMPTY = "";
     String PERCENTAGE = "%";
     int DEFAULT_NUM_ROWS = 10;
     
     public List<TransmissionDTO> getTrasmissionReport(String userName, String jsonString) 
     {		 
	     JSONObject jsonObj = new JSONObject(jsonString);	     
	     String fileName = formatSearchString(jsonObj.getString("fileName"));	     
	     String direction = jsonObj.getString("direction").trim();
	     if(direction.equals("TO_BANK")) {
	    	 direction = "INBOUND";
	     } else if(direction.equals("FROM_BANK")) {
	    	 direction = "OUTBOUND";
	     } else {
	    	 direction = "BOUND";
	     }
	     direction = PERCENTAGE + direction + PERCENTAGE;
	     
	     String status = jsonObj.getString("status").trim();
	     Timestamp startDate = getTimeStamp(jsonObj, "startDate");
	     Timestamp endDate = getTimeStamp(jsonObj, "endDate");     
	     
	     StringBuffer sql = new StringBuffer();
	     sql.append(configProps.getProperty("selectFileInfo"));
	     
	     if ((fileName != null) && (fileName.trim().length() > 0)) {
	         sql.append(" ").append(configProps.getProperty("selectFileInfoWhereFileName"));
	     }
	     
	     if ((status != null) && !(status.trim().equals("SELECT ONE"))) {
	         sql.append(" ").append(configProps.getProperty("selectFileInfoWhereStatus"));
	     }
	
	     sql.append(" ").append(configProps.getProperty("selectFileInfoOrderBy"));
	     String sqlQuery = sql.toString();
	     System.out.println("SQL==> " + sqlQuery);
	
	     Object params[] = new Object[]{userName, userName, direction, startDate, endDate};
	 	
         if (fileName != null && fileName.trim().length() > 0) {
        	 params = new Object[]{userName, userName, direction, startDate, endDate, fileName};
         }
         
         if (status != null && !status.trim().equals("SELECT ONE")) {
        	 params = new Object[]{userName, userName, direction, startDate, endDate, status};
         }
         
         if ((fileName != null && fileName.trim().length() > 0) && (status != null && !status.trim().equals("SELECT ONE"))) {
        	 params = new Object[]{userName, userName, direction, startDate, endDate, fileName, status};
         }
         
         List<TransmissionDTO> transmissions = jdbcOperations.query(sqlQuery, params, new TransmissionReportRowMapper());
	     return transmissions;
     }
     
     private class TransmissionReportRowMapper implements RowMapper<TransmissionDTO> {
    	DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
 		public TransmissionDTO mapRow(ResultSet resultSet, int rowNum) throws SQLException {
 			TransmissionDTO transmissionDTO = new TransmissionDTO();
 			String dir = resultSet.getString("DIRECTION");
 			if (null != dir && "INBOUND".equals(dir)) {
 				transmissionDTO.setDirection("TO_BANK");
 				transmissionDTO.setBusinessUnit(resultSet.getString("RECIPIENT"));
            } else {
            	transmissionDTO.setDirection("FROM_BANK");
            	transmissionDTO.setBusinessUnit(resultSet.getString("SENDER"));
            }
 			transmissionDTO.setFileName(resultSet.getString("FILE_NAME"));
 			transmissionDTO.setFileSize(resultSet.getDouble("MSG_SIZE"));
 			transmissionDTO.setReceiptTimestamp(dateFormat.format(resultSet.getTimestamp("RECEIVED")));
 			transmissionDTO.setSendTimestamp(dateFormat.format(resultSet.getTimestamp("SENT")));
 			transmissionDTO.setStatus(resultSet.getString("STATUS"));
 			transmissionDTO.setMessageId(resultSet.getString("MSG_ID"));
 			return transmissionDTO;
 		}
 	}
    
	 public List<TransmissionDTO> getTrasmissionReportOld(String userName, String jsonString) 
	 {
		 
	     JSONObject jsonObj = new JSONObject(jsonString);	     
	     String fileName = formatSearchString(jsonObj.getString("fileName"));	     
	     String direction = jsonObj.getString("direction").trim();
	     if(direction.equals("TO_BANK")) {
	    	 direction = "INBOUND";
	     } else if(direction.equals("FROM_BANK")) {
	    	 direction = "OUTBOUND";
	     } else {
	    	 direction = "BOUND";
	     }
	     direction = PERCENTAGE + direction + PERCENTAGE;
	     
	     String status = jsonObj.getString("status").trim();
	     Timestamp startDate = getTimeStamp(jsonObj, "startDate");
	     Timestamp endDate = getTimeStamp(jsonObj, "endDate");     
	     
	     StringBuffer sql = new StringBuffer();
	     sql.append(configProps.getProperty("selectFileInfo"));
	     
	     if ((fileName != null) && (fileName.trim().length() > 0)) {
	         sql.append(" ").append(configProps.getProperty("selectFileInfoWhereFileName"));
	     }
	     
	     if ((status != null) && !(status.trim().equals("SELECT ONE"))) {
	         sql.append(" ").append(configProps.getProperty("selectFileInfoWhereStatus"));
	     }
	
	     sql.append(" ").append(configProps.getProperty("selectFileInfoOrderBy"));
	     System.out.println("SQL==> " + sql.toString());
	
	     List<TransmissionDTO> transmissions = new ArrayList<TransmissionDTO>();
	     PreparedStatement prepStmt = null;
	     ResultSet resultSet = null;
	     int paramIndex = 1;
	     try 
	     {
	    	 Connection conn = DaoUtility.getDBConnection();
	         prepStmt = conn.prepareStatement(sql.toString());
	         
	         prepStmt.setString(paramIndex++, userName);
	         
	         prepStmt.setString(paramIndex++, userName);
	
	         prepStmt.setString(paramIndex++, direction);
	
	         prepStmt.setTimestamp(paramIndex++, startDate);
	
	         prepStmt.setTimestamp(paramIndex++, endDate);
	
	         if ((fileName != null) && (fileName.trim().length() > 0)) {
	             prepStmt.setString(paramIndex++, fileName);
	         }
	         
	         if ((status != null) && !(status.trim().equals("SELECT ONE"))) {
	             prepStmt.setString(paramIndex++, status);
	         }
	
	         resultSet = prepStmt.executeQuery();
	         DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
	         while (resultSet.next()) 
	         {
	             final TransmissionDTO dto = new TransmissionDTO();
	             String dir = resultSet.getString("DIRECTION");
	             if (null != dir && "INBOUND".equals(dir)) {
	                 dto.setDirection("TO_BANK");
	                 dto.setBusinessUnit(resultSet.getString("RECIPIENT"));
	             } else {
	                 dto.setDirection("FROM_BANK");
	                 dto.setBusinessUnit(resultSet.getString("SENDER"));
	             }
	
	             dto.setFileName(resultSet.getString("FILE_NAME"));
	             dto.setFileSize(resultSet.getDouble("MSG_SIZE"));
	             dto.setReceiptTimestamp(dateFormat.format(resultSet.getTimestamp("RECEIVED")));
	             dto.setSendTimestamp(dateFormat.format(resultSet.getTimestamp("SENT")));
	             dto.setStatus(resultSet.getString("STATUS"));
	             dto.setMessageId(resultSet.getString("MSG_ID"));
	             transmissions.add(dto);
	         }
	         return transmissions;
	     } catch (SQLException e) {
	         e.printStackTrace();
	     } finally {
	         if (resultSet != null) {
	             try {
	                 resultSet.close();
	             } catch (SQLException e) {
	            	 e.printStackTrace();
	             }
	         }
	
	         if (prepStmt != null) {
	             try {
	                 prepStmt.close();
	             } catch (SQLException ee) {
	            	 ee.printStackTrace();
	             }
	         }
	     }
	     return transmissions;
      }
	 
	    
	    /**
	     * Replaces * with % for searching in database
	     *
	     * @param searchString
	     * @return String
	     */
	    private String formatSearchString(String searchString) {
	        if (searchString != null && searchString.trim().length() > 0) {
	            return searchString.replace('*', '%');
	        } else {
	            return null;
	        }
	    }
	    
	    /**
	     * Returns the timestamp from the date values of request
	     *
	     * @param request
	     * @param string
	     * @return Timestamp
	     */
	    static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm aa");
	    private Timestamp getTimeStamp(JSONObject jsonObj, String string) 
	    {
	        String dateStr = "";
	        String startDate = jsonObj.getString("StartDate");
	  		
	  		if(startDate == null || "".equals(startDate.trim())){
	  			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	  			sdf.setTimeZone(TimeZone.getDefault());
	    		Long sevenDaysBack = System.currentTimeMillis()-(7*24*60*60*1000);
				Date modifiedDate = new Date(sevenDaysBack);
				startDate = sdf.format(modifiedDate);
	  		}
		
	  		String startTime = jsonObj.getString("StartTime");
	  		
	  		if(startTime == null || "".equals(startTime.trim())){
	  			SimpleDateFormat date = new SimpleDateFormat("hh:mm");
				date.setTimeZone(TimeZone.getDefault());
				Long hourBack = System.currentTimeMillis()-(60*60*1000);
				Date modifiedDate = new Date(hourBack);
				startTime = date.format(modifiedDate);
	  		}
	  		
	  		String endDate = jsonObj.getString("EndDate");
	  		
	  		if(endDate == null || "".equals(endDate.trim())){
	  			SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd");
				date.setTimeZone(TimeZone.getDefault());
				Date modifiedDate = new Date(System.currentTimeMillis());
				endDate = date.format(modifiedDate);
	  		}
	  		
	  		String endTime = jsonObj.getString("EndTime");
	  		
	  		if(endTime == null || "".equals(endTime.trim())){
	  			SimpleDateFormat date = new SimpleDateFormat("hh:mm");
				date.setTimeZone(TimeZone.getDefault());
				Date modifiedDate = new Date(System.currentTimeMillis()+1);
				endTime = date.format(modifiedDate);
	  		}
	  		
	  		System.out.println("startDate : "+startDate+" startTime : "+startTime+" endDate : "+endDate+" endTime : "+endTime);
	        if ("endDate".equalsIgnoreCase(string)) {
	            dateStr = endDate + " " + endTime + " " + jsonObj.getString("EndAMPM");
	        } else {
	            dateStr = startDate + " " + startTime + " " + jsonObj.getString("StartAMPM");
	        }
	        System.out.println("Date--> " + dateStr);
	        
	        Date dateObj = null;
	        try {
	        	dateObj = dateFormat.parse(dateStr);
	        } catch (ParseException e) {
	            System.out.println("Error parsing date" + dateStr + " " + e.getMessage());
	        }
	        return new Timestamp(dateObj.getTime());
	    }
	    
	    /**
	     * Returns empty string if
	     *
	     * @param string
	     * @return String
	     */
	    private String nvl(String string) {
	        if (null == string) {
	            return "";
	        }
	        return string;
	    }
	    
}
