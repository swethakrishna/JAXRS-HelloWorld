package com.bofa.b2bi.api.dao;

import com.bofa.b2bi.api.model.UserAudit;

public interface UserAuditDao {

	public UserAudit createUserAudit(UserAudit userAudit);

	public void updateUserAudit(UserAudit userAudit);
}
