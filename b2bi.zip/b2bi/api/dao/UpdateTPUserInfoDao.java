package com.bofa.b2bi.api.dao;

import com.bofa.b2bi.api.model.UserInfo;

public interface UpdateTPUserInfoDao {
	
	/**
	 * This method updates given TP user information.
	 * 
	 * @param userInfo
	 */
	public void updateTPUserInfo(UserInfo userInfo);

}
