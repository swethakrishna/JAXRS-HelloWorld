package com.bofa.b2bi.api.dao;

import java.util.List;

import com.bofa.b2bi.api.model.CertificateDetails;

public interface CertificateDao {
	
	List<CertificateDetails> loadUserCertificates(String typeOfCert);
	
	String loadUserCertificateById(String certId);
	
}
