package com.bofa.b2bi.api.dao;

import com.bofa.b2bi.api.model.ChangePasswordRequest;

public interface ChangePasswordDao {

	public void changePassword(ChangePasswordRequest changePwdInfo);

}
