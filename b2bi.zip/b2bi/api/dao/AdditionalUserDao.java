package com.bofa.b2bi.api.dao;

import com.bofa.b2bi.api.model.UserInfo;

public interface AdditionalUserDao {

	public void createAdditionalUserInfo(UserInfo userInfo);

}
