package com.bofa.b2bi.api.dao;

import java.util.List;

import com.bofa.b2bi.api.model.UserConfig;
import com.bofa.b2bi.api.model.UserInfo;

public interface UserInfoDao {

	UserInfo getUser(String userName);
	
	List<String> getAdditionalDropOffUsers(String clientId);

	UserInfo updateUserInfo(String userName, UserInfo userInfo) throws Exception;

	String findUserRole(String userName);

	UserConfig loadUserConfig(String userName);
}
