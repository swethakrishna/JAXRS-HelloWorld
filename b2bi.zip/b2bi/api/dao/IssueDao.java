package com.bofa.b2bi.api.dao;

import java.io.InputStream;
import java.util.List;

import com.bofa.b2bi.api.dto.IssueDto;
import com.bofa.b2bi.api.model.Issue;


public interface IssueDao {

	public Long create(IssueDto iRequest, InputStream is);
	public List<Issue> getAll(String userName);
}
