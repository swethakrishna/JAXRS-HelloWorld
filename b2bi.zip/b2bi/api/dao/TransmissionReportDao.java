package com.bofa.b2bi.api.dao;

import java.util.List;

import com.bofa.b2bi.api.model.TransmissionDTO;

public interface TransmissionReportDao {
	
	List<TransmissionDTO> getTrasmissionReport(String userName, String jsonString);
	
}