package com.bofa.b2bi.api.model;

import java.io.Serializable;

/**
 * DTO used to hold the data that has to be displayed to trading partner
 * 
 * 
 */
public class TransmissionDTO implements Serializable {

	private static final long serialVersionUID = 2770068310315176143L;

	/** Business Unit */
	private String businessUnit;
	/** Direction */
	private String direction;
	
	/** date/time payload was received */
	private String receiptTimestamp;
	
	/** date/time payload was sent */
	private String sendTimestamp;
	
	/** name of payload file */
	private String fileName;
	
	/** size of the file in bytes */
	private double fileSize;

	/** status of transmission */
	private String status;		
	
	/** Message Id */
	private String messageId;


	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSendTimestamp() {
		return sendTimestamp;
	}

	public void setSendTimestamp(String sendTimestamp) {
		this.sendTimestamp = sendTimestamp;
	}

	public String getReceiptTimestamp() {
		return receiptTimestamp;
	}

	public void setReceiptTimestamp(String receiptTimestamp) {
		this.receiptTimestamp = receiptTimestamp;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public double getFileSize() {
		return fileSize;
	}

	public void setFileSize(double fileSize) {
		this.fileSize = fileSize;
	}
	public String getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}	

}
