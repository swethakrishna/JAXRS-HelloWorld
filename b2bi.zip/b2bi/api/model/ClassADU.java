package com.bofa.b2bi.api.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ClassADU implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -276288944831289120L;

	@JsonProperty(value = "ClientAlias")
	private String clientAlias;

	@JsonProperty(value = "Fname")
	private String fname;

	@JsonProperty(value = "Lname")
	private String lname;

	@JsonProperty(value = "Email")
	private String email;

	@JsonProperty(value = "Gisuser")
	private String gisUser;

	@JsonProperty(value = "Gisuserpassword")
	private String gisUserPassword;

	public String getClientAlias() {
		return clientAlias;
	}

	public void setClientAlias(String clientAlias) {
		this.clientAlias = clientAlias;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getGisUser() {
		return gisUser;
	}

	public void setGisUser(String gisUser) {
		this.gisUser = gisUser;
	}

	public String getGisUserPassword() {
		return gisUserPassword;
	}

	public void setGisUserPassword(String gisUserPassword) {
		this.gisUserPassword = gisUserPassword;
	}

}
