package com.bofa.b2bi.api.model;

import java.io.Serializable;

public class ChangePasswordRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7102462554907877182L;

	private String userClientId;
	private String userName;
	private String oldPassword;
	private String newPassword;
	private String reTypeNewPassword;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getOldPassword() {
		return oldPassword;
	}

	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public String getReTypeNewPassword() {
		return reTypeNewPassword;
	}

	public void setReTypeNewPassword(String reTypeNewPassword) {
		this.reTypeNewPassword = reTypeNewPassword;
	}

	public String getUserClientId() {
		return userClientId;
	}

	public void setUserClientId(String userClientId) {
		this.userClientId = userClientId;
	}

}
