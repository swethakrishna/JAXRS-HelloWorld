package com.bofa.b2bi.api.model;

import java.time.LocalDate;

import com.bofa.b2bi.api.util.BrowserUtil.BrowserType;

public class UserAudit {
	
	private Long id;
	private String userName;
	private String sessionId;
	private LocalDate loginTime;
	private LocalDate logoutTime;
	private String errorMessage;
	private BrowserType browserType;
	private String clientIPAddress;

	public Long getId() {
		return id;
	}

	public void setId(Long long1) {
		this.id = long1;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public LocalDate getLoginTime() {
		return loginTime;
	}

	public void setLoginTime(LocalDate loginTime) {
		this.loginTime = loginTime;
	}

	public LocalDate getLogoutTime() {
		return logoutTime;
	}

	public void setLogoutTime(LocalDate logoutTime) {
		this.logoutTime = logoutTime;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public BrowserType getBrowserType() {
		return browserType;
	}

	public void setBrowserType(BrowserType browserType) {
		this.browserType = browserType;
	}

	public String getClientIPAddress() {
		return clientIPAddress;
	}

	public void setClientIPAddress(String clientIPAddress) {
		this.clientIPAddress = clientIPAddress;
	}

}
