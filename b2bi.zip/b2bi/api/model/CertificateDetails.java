package com.bofa.b2bi.api.model;

public class CertificateDetails {

	private String keyId;
	private String keyName;
	private String expDate;
	private String fingerPrint;
	private String pgpId;
	
	public String getKeyId() {
		return keyId;
	}
	public void setKeyId(String keyId) {
		this.keyId = keyId;
	}
	public String getKeyName() {
		return keyName;
	}
	public void setKeyName(String keyName) {
		this.keyName = keyName;
	}
	public String getExpDate() {
		return expDate;
	}
	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}
	public String getFingerPrint() {
		return fingerPrint;
	}
	public void setFingerPrint(String fingerPrint) {
		this.fingerPrint = fingerPrint;
	}
	public String getPgpId() {
		return pgpId;
	}
	public void setPgpId(String pgpId) {
		this.pgpId = pgpId;
	}
	
}
