package com.bofa.b2bi.api.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Used as a Wrapper for Transmission report for pagination
 * @author NBKFUP6
 *
 */
public class TransmissionReport implements Serializable {

	private static final long serialVersionUID = 1L;
	private List<TransmissionDTO> transmissions = new ArrayList<TransmissionDTO>();
	private int pageNum = 0;
	private int totalPages = 0;
	
	public List<TransmissionDTO> getTransmissions() {
		return transmissions;
	}
	public void setTransmissions(List<TransmissionDTO> transmissions) {
		this.transmissions = transmissions;
	}
	public int getPageNum() {
		return pageNum;
	}
	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}
	public int getTotalPages() {
		return totalPages;
	}
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}
	
	
	
	

}
