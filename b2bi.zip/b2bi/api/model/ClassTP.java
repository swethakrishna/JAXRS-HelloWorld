package com.bofa.b2bi.api.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ClassTP implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8283254502630953653L;

	@JsonProperty(value = "Alias")
	private String alias;

	@JsonProperty(value = "Name")
	private String name;

	@JsonProperty(value = "Fname")
	private String fname;

	@JsonProperty(value = "Lname")
	private String lname;

	@JsonProperty(value = "Email")
	private String email;

	@JsonProperty(value = "Pager")
	private String pager;

	@JsonProperty(value = "Phonenumber")
	private String phonenumber;

	@JsonProperty(value = "Address1")
	private String address1;

	@JsonProperty(value = "Address2")
	private String address2;

	@JsonProperty(value = "City")
	private String city;

	@JsonProperty(value = "State")
	private String state;

	@JsonProperty(value = "Zipcode")
	private String zipcode;

	@JsonProperty(value = "Pgpkey")
	private String pgpkey;

	/**
	 * @return the alias
	 */
	public String getAlias() {
		return alias;
	}

	/**
	 * @param alias
	 *            the alias to set
	 */
	public void setAlias(String alias) {
		this.alias = alias;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the fname
	 */
	public String getFname() {
		return fname;
	}

	/**
	 * @param fname
	 *            the fname to set
	 */
	public void setFname(String fname) {
		this.fname = fname;
	}

	/**
	 * @return the lname
	 */
	public String getLname() {
		return lname;
	}

	/**
	 * @param lname
	 *            the lname to set
	 */
	public void setLname(String lname) {
		this.lname = lname;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email
	 *            the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the pager
	 */
	public String getPager() {
		return pager;
	}

	/**
	 * @param pager
	 *            the pager to set
	 */
	public void setPager(String pager) {
		this.pager = pager;
	}

	/**
	 * @return the phonenumber
	 */
	public String getPhonenumber() {
		return phonenumber;
	}

	/**
	 * @param phonenumber
	 *            the phonenumber to set
	 */
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	/**
	 * @return the address1
	 */
	public String getAddress1() {
		return address1;
	}

	/**
	 * @param address1
	 *            the address1 to set
	 */
	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	/**
	 * @return the address2
	 */
	public String getAddress2() {
		return address2;
	}

	/**
	 * @param address2
	 *            the address2 to set
	 */
	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city
	 *            the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state
	 *            the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the zipcode
	 */
	public String getZipcode() {
		return zipcode;
	}

	/**
	 * @param zipcode
	 *            the zipcode to set
	 */
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	/**
	 * @return the pgpkey
	 */
	public String getPgpkey() {
		return pgpkey;
	}

	/**
	 * @param pgpkey
	 *            the pgpkey to set
	 */
	public void setPgpkey(String pgpkey) {
		this.pgpkey = pgpkey;
	}

}
