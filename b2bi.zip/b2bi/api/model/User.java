package com.bofa.b2bi.api.model;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "User")
public class User {
	private String Loginid;

	private String ExistingPassword;

	private String Password;

	private String UserKey;

	@XmlAttribute(name = "Loginid")
	public String getLoginid() {
		return Loginid;
	}

	public void setLoginid(String loginid) {
		Loginid = loginid;
	}

	@XmlAttribute(name = "ExistingPassword")
	public String getExistingPassword() {
		return ExistingPassword;
	}

	public void setExistingPassword(String existingPassword) {
		ExistingPassword = existingPassword;
	}

	@XmlAttribute(name = "Password")
	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	@XmlAttribute(name = "Userkey")
	public String getUserKey() {
		return UserKey;
	}

	public void setUserKey(String userKey) {
		UserKey = userKey;
	}

}
