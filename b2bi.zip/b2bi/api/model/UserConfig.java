package com.bofa.b2bi.api.model;

public class UserConfig {

	private int id;
	private String role;
	private boolean sshkeyConf;
	private boolean pgpkeyConf;
	private boolean cdconf;
	private boolean as2Conf;
	private boolean changeReqConf;
	private boolean _3SKeyConf;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}	
	public boolean getSshkeyConf() {
		return sshkeyConf;
	}
	public void setSshkeyConf(boolean sshkeyConf) {
		this.sshkeyConf = sshkeyConf;
	}
	public boolean getPgpkeyConf() {
		return pgpkeyConf;
	}
	public void setPgpkeyConf(boolean pgpkeyConf) {
		this.pgpkeyConf = pgpkeyConf;
	}
	public boolean getCdconf() {
		return cdconf;
	}
	public void setCdconf(boolean cdconf) {
		this.cdconf = cdconf;
	}
	public boolean getAs2Conf() {
		return as2Conf;
	}
	public void setAs2Conf(boolean as2Conf) {
		this.as2Conf = as2Conf;
	}
	public boolean getChangeReqConf() {
		return changeReqConf;
	}
	public void setChangeReqConf(boolean changeReqConf) {
		this.changeReqConf = changeReqConf;
	}
	public boolean get_3SKeyConf() {
		return _3SKeyConf;
	}
	public void set_3SKeyConf(boolean _3sKeyConf) {
		_3SKeyConf = _3sKeyConf;
	}
	
}
