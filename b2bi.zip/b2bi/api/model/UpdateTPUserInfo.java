package com.bofa.b2bi.api.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author zkf2bey
 *
 */
public class UpdateTPUserInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6613710215712945613L;

	private String token;

	private String platform;

	@JsonProperty(value = "ClassTP")
	private ClassTP classTP;

	@JsonProperty(value = "ClassADU")
	private ClassADU classADU;

	public ClassADU getClassADU() {
		return classADU;
	}

	public void setClassADU(ClassADU classADU) {
		this.classADU = classADU;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String abc) {
		this.token = abc;
	}

	public String getPlatform() {
		return platform;
	}

	public void setPlatform(String platform) {
		this.platform = platform;
	}

	/**
	 * @return the classTP
	 */
	public ClassTP getClassTP() {
		return classTP;
	}

	/**
	 * @param classTP
	 *            the classTP to set
	 */
	public void setClassTP(ClassTP classTP) {
		this.classTP = classTP;
	}

}
