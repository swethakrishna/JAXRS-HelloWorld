package com.bofa.b2bi.api.model;

import java.util.ArrayList;
import java.util.List;

/**
 * @author ZKF2BEY
 *
 */
public class UserInfo {

	private String clientId;
	private String userName;
	private String name;
	private String aliasName;
	private String firstName;
	private String lastName;
	private String email;
	private String pager;
	private String phoneNumber;
	private String address1;
	private String address2;
	private String city;
	private String state;
	private String zipCode;
	private String userType;
	private List<UserInfo> dropOffUsersInfo = new ArrayList<>();
	private String lastLogin;
	private String gisUserPassword;
	private UserConfig userConfig;

	public UserConfig getUserConfig() {
		return userConfig;
	}

	public void setUserConfig(UserConfig userConfig) {
		this.userConfig = userConfig;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAliasName() {
		return aliasName;
	}

	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPager() {
		return pager;
	}

	public void setPager(String pager) {
		this.pager = pager;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(String lastLogin) {
		this.lastLogin = lastLogin;
	}

	public List<UserInfo> getDropOffUsersInfo() {
		return dropOffUsersInfo;
	}

	public void setDropOffUsersInfo(List<UserInfo> dropOffUsersInfo) {
		this.dropOffUsersInfo = dropOffUsersInfo;
	}

	public String getGisUserPassword() {
		return gisUserPassword;
	}

	public void setGisUserPassword(String gisUserPassword) {
		this.gisUserPassword = gisUserPassword;
	}
	
	public String getType() {
		if (this.userType.equals("TP")) {
			return "B2biExternal";
		}
		return "BofaInternal";
	}
}
