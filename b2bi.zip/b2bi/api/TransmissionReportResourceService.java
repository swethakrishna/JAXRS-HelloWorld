package com.bofa.b2bi.api;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;

import com.bofa.b2bi.api.model.TransmissionDTO;
import com.bofa.b2bi.api.service.TranmissionReportSearchService;
import com.bofa.b2bi.api.util.CommonUtility;

@Path("/transmission")
public class TransmissionReportResourceService {

	@Autowired
	private TranmissionReportSearchService tranmissionReportSearchService;
	
	@POST
    @Path("/list")
	@Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
	public String getTransmissionInformation(@QueryParam("authString") String authString, String jsonString) throws Exception 
	{		
		String credentials[] = CommonUtility.getUserNameAndPassword(authString);
		String userName = credentials[0];
		
		List<TransmissionDTO> transmissionResponse = tranmissionReportSearchService.getTransmissionInformation(userName, jsonString);
		String trnsResonse = CommonUtility.prepareFileData(transmissionResponse);
		return trnsResonse;
	}
}
