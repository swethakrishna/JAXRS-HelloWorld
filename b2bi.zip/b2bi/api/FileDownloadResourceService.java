package com.bofa.b2bi.api;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import com.bofa.b2bi.api.impl.FTPException;
import com.bofa.b2bi.api.service.FileDownloadService;

@Path("/file")
public class FileDownloadResourceService {
	
	@Autowired
	private FileDownloadService fileDownloadService;
	
	@GET
    @Path("/dirlist")
	@Produces(MediaType.APPLICATION_JSON)
	public String getDirectoryDetails(@QueryParam("authString") String authString) throws FTPException
	{
		return fileDownloadService.getDirectoryDetails(authString, "/");
	}
	
	@POST
    @Path("/list")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
	public String getFileDetails(@QueryParam("authString") String authString, String jsonString) throws FTPException
	{
		JSONObject jsonObj = new JSONObject(jsonString);
		String userDir = jsonObj.getString("dirLoc");
		Map<String,String> filterParams = new HashMap<String,String>();
		filterParams.put("messageName", jsonObj.getString("messageName"));
		filterParams.put("StartDate", jsonObj.getString("StartDate"));
		filterParams.put("EndDate", jsonObj.getString("EndDate"));
		filterParams.put("StartTime", jsonObj.getString("StartTime"));
		filterParams.put("EndTime", jsonObj.getString("EndTime"));
		filterParams.put("StartAMPM", jsonObj.getString("StartAMPM"));
		filterParams.put("EndAMPM", jsonObj.getString("EndAMPM"));
		return fileDownloadService.getFileDetails(authString, userDir, filterParams);		
    }
	
	@GET
    @Path("/download/{fileName:.+}")
	public String downloadFile(@Context HttpServletResponse response, @PathParam("fileName") String fileName, @QueryParam("qParam") String dirPath, @QueryParam("authString") String authString) throws FTPException
	{
		return fileDownloadService.downloadFile(response, authString, fileName, dirPath);
	}
	
	@POST
    @Path("/certslist")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
	public String getListOfCustomerCerts(String jsonString)
	{
		JSONObject jsonObj = new JSONObject(jsonString);
		String keyName = jsonObj.getString("keyName");
		String certsDetails = fileDownloadService.getListOfCertficates(keyName);
		return certsDetails;
	}
	
	@GET
    @Path("/downloadCert/{keyId}")
	public String downloadCertificate(@Context HttpServletResponse response, @PathParam("keyId") String certId) throws FTPException
	{
		return fileDownloadService.downloadCertificate(response, certId);
	}
	
}
