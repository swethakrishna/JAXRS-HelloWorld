package com.bofa.b2bi.api;

import java.io.IOException;
import java.io.InputStream;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.springframework.beans.factory.annotation.Autowired;

import com.bofa.b2bi.api.impl.FTPException;
import com.bofa.b2bi.api.impl.FTPFileupload;
import com.bofa.b2bi.api.service.FileUploadService;


@Path("/file")
public class FileUploadResourceService {

	@Autowired
	private FileUploadService fileUploadService;
	
    public static final String UPLOAD_FAIL = "Service is unavailable. Pleas contact administrator.";
    public static final String UPLOAD_SUCCESS = "File Uploaded Successfully !!";
	
	@POST
    @Path("/upload")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.TEXT_PLAIN)
    public String uploadFile(@FormDataParam("file") InputStream fis, 
    						 @FormDataParam("file") FormDataContentDisposition fdcd, 
    						 @QueryParam("dirName") String dirName,
    						 @QueryParam("fileName") String fileName,
    						 @QueryParam("authString") String authString) throws IOException 
    {  
        if(fileName.isEmpty()){
        	fileName = fdcd.getFileName();
        }
        System.out.println("File Name: " + fdcd.getFileName());
        
        FTPFileupload ftpFileUpload = new FTPFileupload();
        ftpFileUpload.setFTPFile(fis, fileName);
        
        try {
        	fileUploadService.uploadFile(fis, fileName, authString, dirName);
        } catch (FTPException e) {
			e.printStackTrace();
			return UPLOAD_FAIL;
		} 
        return UPLOAD_SUCCESS;
    }
	
	@GET
	@Path("/directories/{dirName}")
	@Produces(MediaType.APPLICATION_JSON)
	public String getDirectoryDetails(@PathParam("dirName") String dirName, @QueryParam("authString") String authString) throws FTPException, IOException 
	{
		return fileUploadService.getDirectoryDetails(authString, dirName);
	}
}