package com.bofa.b2bi.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;

import com.bofa.b2bi.api.model.ChangePasswordRequest;
import com.bofa.b2bi.api.model.UserConfig;
import com.bofa.b2bi.api.model.UserInfo;
import com.bofa.b2bi.api.response.UserDto;
import com.bofa.b2bi.api.service.impl.UserService;

@Path("/users")
public class UserResourceService {

	@Autowired
	private UserService userService;

	@GET
	@Path("/{userName}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public UserDto getUserInformation(@PathParam("userName") String userName) throws Exception {
		return userService.getUser(userName);
	}

	@POST
	@Path("/{userClientId}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public UserInfo updateUserInformation(@PathParam("userClientId") String clientId, UserInfo userInfo)
			throws Exception {

		UserInfo userInfoResponse = userService.updateUserInformation(clientId, userInfo);

		return userInfoResponse;

	}

	@PUT
	@Path("/updatetp")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public UserInfo updateUserInfo(UserInfo userInfo) throws Exception {

		UserInfo userInfoResponse = userService.updateUserInfo(userInfo);

		return userInfoResponse;

	}

	@POST
	@Path("/changepassword")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public void changePwdInformation(ChangePasswordRequest changePwdInfo) {

		userService.changePassword(changePwdInfo);

	}

	@POST
	@Path("/additionaluser")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public void createAdditionalUserInfo(UserInfo userInfo) throws Exception {
		// IebTnQM/l7Qdw5vc7L6vevETFzaMmNZEAE5IrpKnRo4= = swetha_12345

		userService.createAdditionalUserInfo(userInfo);

	}
	
	@GET
	@Path("/config/{userName}")
	@Produces(MediaType.APPLICATION_JSON)
	public UserConfig getUserProfileConfig(@PathParam("userName") String userName) {
		UserConfig userConfig = userService.getUserConfig(userName);
		return userConfig;
	}

}
