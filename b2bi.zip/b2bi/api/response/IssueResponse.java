package com.bofa.b2bi.api.response;

import java.time.LocalDate;

public class IssueResponse {

	private Integer issueId;
	private String subject;
	private String description;
	private LocalDate identifiedDate;
	private String status;
	public Integer getIssueId() {
		return issueId;
	}
	public void setIssueId(Integer issueId) {
		this.issueId = issueId;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public LocalDate getIdentifiedDate() {
		return identifiedDate;
	}
	public void setIdentifiedDate(LocalDate identifiedDate) {
		this.identifiedDate = identifiedDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
