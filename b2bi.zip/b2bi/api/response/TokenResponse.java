package com.bofa.b2bi.api.response;

public class TokenResponse {

	private boolean isSuccess;
	private String otpType;
	
	public TokenResponse(boolean isSuccess, String otpType) {
		this.isSuccess = isSuccess;
		this.otpType = otpType;
	}
	public boolean isSuccess() {
		return isSuccess;
	}
	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}
	public String getOtpType() {
		return otpType;
	}
	public void setOtpType(String otpType) {
		this.otpType = otpType;
	}
}
