package com.bofa.b2bi.api.response;

public class AuthenticationResponse {

	private UserDto userDto;
	private boolean isMFA;

	public AuthenticationResponse(boolean isMFA, UserDto userDto) {
		this.isMFA = isMFA;
		this.userDto = userDto;
	}
	
	public UserDto getUserDto() {
		return userDto;
	}
	public void setUserDto(UserDto userDto) {
		this.userDto = userDto;
	}
	public boolean isMFA() {
		return isMFA;
	}
	public void setMFA(boolean isMFA) {
		this.isMFA = isMFA;
	}
	
}
