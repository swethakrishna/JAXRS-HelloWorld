package com.bofa.b2bi.api.exception.jaxrs.handler;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;

import com.bofa.b2bi.api.error.B2BIError;
import com.bofa.b2bi.api.exception.DataValidationException;
import com.bofa.b2bi.core.error.ErrorDetails;
import com.bofa.b2bi.core.error.ErrorResponse;
import com.bofa.b2bi.core.error.ErrorType;

@Provider
public class DataValidationExceptionHandler extends BaseExceptionHandler implements ExceptionMapper<DataValidationException> {

    @Override
    protected int getHttpStatusCode() {
        return Response.Status.BAD_REQUEST.getStatusCode();
    }

    @Override
    public Response toResponse(DataValidationException exception) {
        return getResponseBuilder(exception)
                .type(MediaType.APPLICATION_JSON_TYPE)
                .entity(getErrorResponse(exception.getValidationErrors()))
                .build();
    }

    public ErrorResponse getErrorResponse(Errors errors) {
        ErrorResponse response = new ErrorResponse();
        response.setErrorDetails(getErrorDetailsList(errors));
        response.setErrorType(getErrorType());
        return response;
    }

    public List<ErrorDetails> getErrorDetailsList(Errors errors) {
        List<ErrorDetails> errorDetails = new ArrayList<>();

        if (errors != null) {
            for (FieldError error : errors.getFieldErrors()) {
                errorDetails.add(getErrorDetails(error));
            }
        }
        return errorDetails;
    }

    public ErrorDetails getErrorDetails(FieldError error) {
        ErrorDetails errorDetail = new ErrorDetails();

        if (error != null) {
            errorDetail = new ErrorDetails();
            errorDetail.setCode(error.getCode());
            errorDetail.setField(error.getField());

            if (error.getDefaultMessage() != null) {
                errorDetail.setDescription(error.getDefaultMessage());
            } else {
                B2BIError dbgError = B2BIError.getFromCode(Integer.parseInt(error.getCode()));
                errorDetail.setDescription(dbgError.getDescription());
            }
        }
        return errorDetail;
    }

    @Override
    protected ErrorType getErrorType() {
        return ErrorType.VALIDATION;
    }
}
