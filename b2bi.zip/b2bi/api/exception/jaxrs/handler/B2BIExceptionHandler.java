package com.bofa.b2bi.api.exception.jaxrs.handler;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import com.bofa.b2bi.api.exception.B2BIException;
import com.bofa.b2bi.core.error.ErrorType;

@Provider
public class B2BIExceptionHandler extends BaseExceptionHandler implements ExceptionMapper<B2BIException>  {

    @Override
    protected int getHttpStatusCode() {
        return Response.Status.INTERNAL_SERVER_ERROR.getStatusCode();
    }

    @Override
    protected ErrorType getErrorType() {
        return ErrorType.INTERNAL;
    }

    @Override
    public Response toResponse(B2BIException exception) {
        return getResponseBuilder(exception)
                .type(MediaType.APPLICATION_JSON_TYPE)
                .build();
    }
}
