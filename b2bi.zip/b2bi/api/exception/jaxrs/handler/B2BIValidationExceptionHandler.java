package com.bofa.b2bi.api.exception.jaxrs.handler;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import com.bofa.b2bi.api.error.B2BIError;
import com.bofa.b2bi.core.error.ErrorDetails;
import com.bofa.b2bi.core.error.ErrorResponse;
import com.bofa.b2bi.core.error.ErrorType;
import com.bofa.b2bi.core.exception.ValidationException;

@Provider
public class B2BIValidationExceptionHandler extends BaseExceptionHandler implements ExceptionMapper<ValidationException> {

    @Override
    protected int getHttpStatusCode() {
        return Response.Status.BAD_REQUEST.getStatusCode();
    }


    @Override
    public Response toResponse(ValidationException exception) {
        return getResponseBuilder(exception)
                .type(MediaType.APPLICATION_JSON_TYPE)
                .entity(getErrorResponse(exception.getValidationErrors()))
                .build();
    }

    public ErrorResponse getErrorResponse(List<B2BIError> errors) {
        ErrorResponse response = new ErrorResponse();
        response.setErrorDetails(getErrorDetailsList(errors));
        response.setErrorType(getErrorType());
        return response;
    }


    private List<ErrorDetails> getErrorDetailsList(List<B2BIError> validationErrors) {
        List<ErrorDetails> errorDetails = new ArrayList<>();
        for (B2BIError validationError : validationErrors) {
            errorDetails.add(createErrorDetails(validationError));
        }

        return errorDetails;
    }

    private ErrorDetails createErrorDetails(B2BIError validationError) {
        ErrorDetails errorDetails = new ErrorDetails();
        errorDetails.setCode(validationError.getErrorCodeString());
        errorDetails.setDescription(validationError.getDescription());

        return errorDetails;
    }

    @Override
    protected ErrorType getErrorType() {
        return ErrorType.VALIDATION;
    }
}
