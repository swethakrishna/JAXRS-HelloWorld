package com.bofa.b2bi.api.exception.jaxrs.handler;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status.Family;
import javax.ws.rs.core.Response.StatusType;

import com.bofa.b2bi.core.error.ErrorType;

public abstract class BaseExceptionHandler {

    protected ResponseBuilder getResponseBuilder(Exception exception) {
        return Response.status(new StatusType() {

            @Override
            public int getStatusCode() {
                return getHttpStatusCode();
            }

            @Override
            public String getReasonPhrase() {
                return  exception.getMessage();
            }

            @Override
            public Family getFamily() {
                return Family.familyOf(getStatusCode());
            }
        });
    }

    protected abstract int getHttpStatusCode();

    protected abstract ErrorType getErrorType();
}