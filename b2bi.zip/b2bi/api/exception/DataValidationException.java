package com.bofa.b2bi.api.exception;

import org.springframework.validation.MapBindingResult;

import com.bofa.b2bi.core.exception.PlatformException;


public class DataValidationException extends PlatformException {

    private final MapBindingResult validationErrors;

    public DataValidationException(String message, MapBindingResult validationErrors) {
        super(message);
        this.validationErrors = validationErrors;
    }

    public MapBindingResult getValidationErrors() {
        return validationErrors;
    }
}
