package com.bofa.b2bi.api.exception;

import com.bofa.b2bi.core.exception.PlatformException;

/**
 * Exception class represents failure at server level.
 * For example, database connectivity issue.
 *
 * @author Umamahesh
 *
 */
public class B2BIException extends PlatformException {

    public B2BIException(String message, Throwable e) {
        super(message, e);
    }

    public B2BIException(String message) {
        super(message);
    }
}
