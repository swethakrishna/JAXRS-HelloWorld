package com.bofa.b2bi.api.exception;

import java.util.Collections;
import java.util.List;

import com.bofa.b2bi.api.error.B2BIError;
import com.bofa.b2bi.core.exception.PlatformException;


public class BusinessValidationException extends PlatformException {

    private final List<B2BIError> validationErrors;


    public BusinessValidationException(B2BIError validationError, String message, Object... args) {
        this(Collections.singletonList(validationError), message, args);
    }

    public BusinessValidationException(List<B2BIError> validationErrors, String message, Object... args) {
        super(String.format(message, args));
        this.validationErrors = validationErrors;
    }

    public List<B2BIError> getValidationErrors() {
        return validationErrors;
    }
}
