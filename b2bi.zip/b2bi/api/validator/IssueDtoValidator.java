package com.bofa.b2bi.api.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import com.bofa.b2bi.api.dto.IssueDto;
import com.bofa.b2bi.core.validator.SimpleValidator;

@Component
public class IssueDtoValidator extends SimpleValidator {

   
    public IssueDtoValidator() {
        super(IssueDto.class);
    }

    @Override
    public void validate(Object obj, Errors errors) {
        rejectNull(obj, errors);

        if (!errors.hasFieldErrors("own")) {
        	IssueDto dto = (IssueDto) obj;
            rejectNullOrEmptyString(dto.getSubject(), errors, "subject");
            rejectNullOrEmptyString(dto.getIssueType(), errors, "issueType");
            rejectNullOrEmptyString(dto.getDescription(), errors, "description");
            rejectNullOrEmptyString(dto.getUserId(), errors, "userId");
        }
    }

    @Override
    public String getPath() {
        return "issue";
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return IssueDto.class.equals(clazz);
    }

}
