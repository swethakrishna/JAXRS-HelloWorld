package com.bofa.b2bi.api.error;

import java.util.Arrays;
import java.util.Optional;

import com.bofa.b2bi.core.error.BlError;

public enum B2BIError implements BlError {

    /* DATA VALIDATION ERROR CODES*/
	INVALID_LOGIN(101, "Invalid username and password entered."),
    CAN_NOT_BE_EMPTY_STRING(102, "String can not be empty."),
    CAN_NOT_BE_NEGATIVE(103, "Number can not be negative."),
    CAN_NOT_BE_NEGATIVE_OR_ZERO(104, "Number can not be negative or zero."),
    CAN_NOT_BE_NULL(105, "Value can not be null."),
    INVALID_TOKEN(106, "Invalid token entered."),
    INVALID_OTP(107, "Invalid OTP entered."),
    INVALID_USER_STATUS(107, "User status is invalid."),
    
    
    /* BUSINESS LOGIC VALIDATION ERROR CODES*/
    NEW_USER(501, "Password change required as per Policy. Please contact your system administrator."),
    INVALID_PASSWORD(502, "Invalid password entered, Please try again."),

    /* NOT FOUND EXCEPTION ERRORS */
    RESOURCE_NOT_FOUND(404, "Resource not found."),

    //INTERNAL SERVER ERRORS
    DATA_ACCESS_ERROR(2001, "Database access error.");


    private final int code;
    private final String description;

    private B2BIError(int code, String description) {
        this.code = code;
        this.description = description;
    }

    @Override
    public int getErrorCode() {
        return code;
    }

    @Override
    public String getDescription() {
        return description;
    }

    public String getErrorCodeString() {
        return String.valueOf(code);
    }

    public static B2BIError getFromCode(int errorCode) {
        Optional<B2BIError> errorOpt = Arrays.stream(values()).filter(error -> error.getErrorCode() == errorCode).findFirst();
        if (errorOpt.isPresent()) {
            return errorOpt.get();
        }
        return null;
    }
}
