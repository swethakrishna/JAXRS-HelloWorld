package com.bofa.b2bi.api.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.bofa.b2bi.api.response.UserDto;
import com.bofa.soap.client.ApplicationLoginID;
import com.bofa.soap.client.ArrayOfWSComments;
import com.bofa.soap.client.ArrayOfWSNameValue;
import com.bofa.soap.client.ArrayOfWSTokenUser;
import com.bofa.soap.client.ArrayOfWSUser;
import com.bofa.soap.client.ContactInfo;
import com.bofa.soap.client.WSComments;
import com.bofa.soap.client.WSNameValue;
import com.bofa.soap.client.WSSASDate;
import com.bofa.soap.client.WSToken;
import com.bofa.soap.client.WSTokenRequest;
import com.bofa.soap.client.WSTokenRequestDetails;
import com.bofa.soap.client.WSTokenUser;
import com.bofa.soap.client.WSUser;
import com.bofa.soap.client.WebTemplate;

/**
 * 
 * @author Krishna_Prasad
 *
 */
@Service
public class TokenRequestService {	
	
	public WSTokenRequestDetails submitTokenRequest(UserDto userDto) 
	{
		WSTokenRequest wSTokenRequest = createWSTokenRequest(userDto);
		ArrayOfWSNameValue wSNameValues = createWSNameValues();
		WSTokenRequestDetails tokenRequestDetails = WebTemplate.getPort().submitTokenRequest(wSTokenRequest, wSNameValues);
		return tokenRequestDetails;
	}
	
	private WSTokenRequest createWSTokenRequest(UserDto userInfo)
	{
		WSTokenRequest wsTokenRequest =  new WSTokenRequest();
		
		ApplicationLoginID appLoginId = new ApplicationLoginID();
		appLoginId.setSubGroup(userInfo.getType());
		appLoginId.setLogin(userInfo.getUserName());
		
		WSUser wsuser = new WSUser();
		wsuser.setApp("b2biportal");
		wsuser.setApplicationName("B2BI Portal");
		wsuser.setSubGroupName(userInfo.getType());
		wsuser.setTargetUser(appLoginId);
		wsuser.setUserEmail(userInfo.getEmail());
		wsuser.setUserName(userInfo.getFirstName());
		wsuser.setUserPhone(userInfo.getPhoneNumber());
		wsuser.setUserPhoneExt(userInfo.getPhoneNumber());
		
		wsTokenRequest.setActor(wsuser);
		
		wsTokenRequest.setAssignedTo(userInfo.getUserName());
		
		ContactInfo contactInfo = new ContactInfo();
		contactInfo.setAdditionalEmail(userInfo.getEmail());
		contactInfo.setContactEmail(userInfo.getEmail());
		contactInfo.setContactExtn(userInfo.getPhoneNumber());
		contactInfo.setContactName(userInfo.getFirstName());
		contactInfo.setContactPhone(userInfo.getPhoneNumber());
		
		wsTokenRequest.setContactInfo(contactInfo);
		
		WSSASDate wsSASDate = new WSSASDate();
		wsSASDate.setDate(Calendar.getInstance().getTimeInMillis());
		
		wsTokenRequest.setModifiedDate(wsSASDate);
		
		wsTokenRequest.setNumOfTokens(1);
		
		WSComments wsComments= new WSComments();
		wsComments.setApplication(userInfo.getType());//BofaInternal
		wsComments.setAssignedTo(userInfo.getUserName());
		wsComments.setCommentBody("New Token Request");
		wsComments.setCommentTime(wsSASDate);
		wsComments.setUser(appLoginId);
		
		ArrayOfWSComments arrayOfWSComments = new ArrayOfWSComments();
		arrayOfWSComments.getWSComments().add(wsComments);
		
		wsTokenRequest.setOrderComments(arrayOfWSComments);
		
		wsTokenRequest.setOrderReason("New Order");
		
		wsTokenRequest.setPlacedDate(wsSASDate);
		
		wsTokenRequest.setSaveShippingAddrFlag(false);
		
		wsTokenRequest.setTargetUser(wsuser);
		
		ArrayOfWSUser arrayOfWSUser = new ArrayOfWSUser();
		arrayOfWSUser.getWSUser().add(wsuser);
		wsTokenRequest.setWSUser(arrayOfWSUser);
		
		return wsTokenRequest;
	}
	
	private ArrayOfWSNameValue createWSNameValues() 
	{
		List<WSNameValue> wsNameValues = new ArrayList<>();
		wsNameValues.add(createWsNameValue("IS_EMAIL_NOTIFICATION_REQUIRED", "YES"));
		wsNameValues.add(createWsNameValue("NOTIFICATION_FOR", "User"));
		wsNameValues.add(createWsNameValue("REQUESTOR_NOTIFICATION_TEMPLATE_ID", "1"));
		wsNameValues.add(createWsNameValue("USER_NOTIFICATION_TEMPLATE_ID", "1"));
		wsNameValues.add(createWsNameValue("IS_USER_PROVISION_REQUIRED", "YES"));
		wsNameValues.add(createWsNameValue("TOKEN_TYPE", "VirtualToken"));
		wsNameValues.add(createWsNameValue("LOB_SNAME", "General"));
		wsNameValues.add(createWsNameValue("IS_ORDER_INFO_REQUIRED", "false"));
		
		ArrayOfWSNameValue arrayOfWSNameValue = new ArrayOfWSNameValue();
		arrayOfWSNameValue.getWSNameValue().addAll(wsNameValues);
		
		return arrayOfWSNameValue;
	}
	
	private WSNameValue createWsNameValue(String name, String value) 
	{
		WSNameValue wSNameValue = new WSNameValue();
		wSNameValue.setName(name);
		wSNameValue.setValue(value);
		return wSNameValue;
	}
	
	public Map<String,String> processSubmitTokenRequestResponse(WSTokenRequestDetails tokenRequestDetails) 
	{
		Map<String,String> tokenInfoMap = new HashMap<String,String>();		
		if(tokenRequestDetails != null) {
			ArrayOfWSTokenUser arrayOfWSTokenUser = tokenRequestDetails.getTokenUsers();
			if(arrayOfWSTokenUser != null) {
				List<WSTokenUser> wsTokenUsers = arrayOfWSTokenUser.getWSTokenUser();
				if(wsTokenUsers != null && !wsTokenUsers.isEmpty()) {
					for(WSTokenUser wsTokenUser : wsTokenUsers) {
						tokenInfoMap.put("userStateName", wsTokenUser.getUserStateName());
						WSToken wsToken = wsTokenUser.getTokenVO();
						tokenInfoMap.put("tokenSerial", wsToken.getTokenSerial());
						tokenInfoMap.put("tokenStateName", wsToken.getTokenStateName());
					}
				}
			}
		}		
		return tokenInfoMap;
	}
	
}