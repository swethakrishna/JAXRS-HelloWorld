package com.bofa.b2bi.api.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bofa.b2bi.api.dao.AdditionalUserDao;
import com.bofa.b2bi.api.dao.ChangePasswordDao;
import com.bofa.b2bi.api.dao.UpdateTPUserInfoDao;
import com.bofa.b2bi.api.dao.UserInfoDao;
import com.bofa.b2bi.api.error.B2BIError;
import com.bofa.b2bi.api.model.ChangePasswordRequest;
import com.bofa.b2bi.api.model.UserConfig;
import com.bofa.b2bi.api.model.UserInfo;
import com.bofa.b2bi.api.response.UserDto;
import com.bofa.b2bi.core.exception.NotFoundException;

@Service
public class UserService {

	@Autowired
	private UserInfoDao userInfoDao;

	@Autowired
	private UpdateTPUserInfoDao updateTPUserInfoDao;

	@Autowired
	private ChangePasswordDao changePasswordDao;

	@Autowired
	private AdditionalUserDao additionalUserDao;
	
	@Autowired
	private ModelMapper modelMapper;

	public UserDto getUser(String userName) {
		List<String> additionalUserNames = null;
		UserInfo user = userInfoDao.getUser(userName);
		if (user == null) {
			throw new NotFoundException(B2BIError.RESOURCE_NOT_FOUND);
		}
		additionalUserNames = userInfoDao.getAdditionalDropOffUsers(user.getClientId());
		List<UserInfo> additionalUsers = new ArrayList<>();
		for (String additionalUserName: additionalUserNames) {
			UserInfo additionalUser = userInfoDao.getUser(additionalUserName);
			additionalUsers.add(additionalUser);
		}
		user.setDropOffUsersInfo(additionalUsers);
		UserConfig userConfig = userInfoDao.loadUserConfig(userName);
		user.setUserConfig(userConfig);
		UserDto userDto = modelMapper.map(user, UserDto.class);
		return userDto;
	}

	public UserInfo updateUserInformation(String userClientId, UserInfo userInfo) throws Exception {

		System.out.println("updateUserInformation userClientId: " + userClientId);
		if (userClientId != null && userClientId.isEmpty()) {
			throw new Exception("userName is mandatory, please provide it.");
		}

		UserInfo updatedInfo = userInfoDao.updateUserInfo(userClientId, userInfo);

		return updatedInfo;
	}

	public String getUserRoleByUserName(String userName) {
		return userInfoDao.findUserRole(userName);
	}

	public UserConfig getUserConfig(String userName) {
		return userInfoDao.loadUserConfig(userName);
	}

	/*
	 * (non-Javadoc) This method updates given TP user information.
	 */
	public UserInfo updateUserInfo(UserInfo userInfo) throws Exception {

		// Get tokentId by using ClientId or something else and pass that to
		// tokentId.
		// call update method from Dao.
		updateTPUserInfoDao.updateTPUserInfo(userInfo);

		return null;
	}

	public void changePassword(final ChangePasswordRequest changePwdinfo) {

		changePasswordDao.changePassword(changePwdinfo);

	}

	public void createAdditionalUserInfo(final UserInfo userInfo) {

		// TODO Auto-generated method stub
		additionalUserDao.createAdditionalUserInfo(userInfo);

	}
}
