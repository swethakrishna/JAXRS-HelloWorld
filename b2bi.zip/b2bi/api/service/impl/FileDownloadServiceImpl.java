package com.bofa.b2bi.api.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;

import com.bofa.b2bi.api.dao.CertificateDao;
import com.bofa.b2bi.api.impl.FTPException;
import com.bofa.b2bi.api.model.CertificateDetails;
import com.bofa.b2bi.api.service.FileDownloadService;
import com.bofa.b2bi.api.util.CommonUtility;
import com.bofa.b2bi.api.util.FolderScanner;

@Service
public class FileDownloadServiceImpl implements FileDownloadService {
	
	@Autowired 
	private Properties configProps;
	@Autowired
	private CertificateDao certificateDao;
	
	public String getDirectoryDetails(final String authString, final String dirName) throws FTPException 
	{
		String credentials[] = CommonUtility.getUserNameAndPassword(authString);
		
        Map<String,String> connectionParams = new HashMap<String,String>();
        connectionParams.put("hostname", configProps.getProperty("com.baci.ftpsrv.hostname"));
        connectionParams.put("userName", credentials[0]);
        connectionParams.put("password", credentials[1]);
        connectionParams.put("dirName", dirName);
        List<String> directories = FolderScanner.connectFtpSrvAndScanRootDir(connectionParams);
        return getRootDirectories(directories);
	}
	
	public String getFileDetails(final String authString, final String remoteDir, final Map<String,String> filterParams) throws FTPException 
	{
		String credentials[] = CommonUtility.getUserNameAndPassword(authString);
		
        Map<String,String> connectionParams = new HashMap<String,String>();
        connectionParams.put("hostname", configProps.getProperty("com.baci.ftpsrv.hostname"));
        connectionParams.put("userName", credentials[0]);
        connectionParams.put("password", credentials[1]);
        connectionParams.put("dirName", remoteDir);
        return FolderScanner.connectFtpSrvAndScanDir(connectionParams, filterParams);
    }
	
	public String downloadFile(final HttpServletResponse response, final String authString, final String fileName, final String remoteDir) throws FTPException
	{
		String credentials[] = CommonUtility.getUserNameAndPassword(authString);
		
		Map<String,String> connectionParams = new HashMap<String,String>();
        connectionParams.put("hostname", configProps.getProperty("com.baci.ftpsrv.hostname"));
        connectionParams.put("userName", credentials[0]);
        connectionParams.put("password", credentials[1]);
        connectionParams.put("dirName", remoteDir);
        
        return FolderScanner.connectFtpSrvAndDownloadFile(fileName, connectionParams, response);	
        
        //response.setHeader("Content-Disposition", String.format("inline; filename=\"" + file.getName() +"\""));
        //response.setHeader("Content-Disposition", String.format("attachment; filename=\"%s\"", fileName));
        //response.setContentLength((int)file.length());
		//InputStream inputStream = new BufferedInputStream(new FileInputStream(file));
        //FileCopyUtils.copy(inputStream, response.getOutputStream());
	}
	
	private String getRootDirectories(List<String> directories) {
		List<String> rootDirectories = directories.stream().filter(e -> e.startsWith("/outgoing") || e.startsWith("/archives")).collect(Collectors.toList());
        return CommonUtility.prepareFileData(rootDirectories);
	}

	@Override
	public String getListOfCertficates(String typeOfCert) 
	{
		List<CertificateDetails> certDetails = certificateDao.loadUserCertificates(typeOfCert);
		return CommonUtility.prepareFileData(certDetails);
	}

	@Override
	public String downloadCertificate(HttpServletResponse response, String certId) 
	{
		String certificate = certificateDao.loadUserCertificateById(certId);
		response.setHeader("Content-Disposition", String.format("attachment; filename=\"%s\"", "public_key.asc"));
		try {
			FileCopyUtils.copy(IOUtils.toInputStream(certificate, "UTF-8"), response.getOutputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "File download Success!";
	}
	
}
