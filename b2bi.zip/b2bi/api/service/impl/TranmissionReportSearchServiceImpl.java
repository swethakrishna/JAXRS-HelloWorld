package com.bofa.b2bi.api.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bofa.b2bi.api.dao.TransmissionReportDao;
import com.bofa.b2bi.api.model.TransmissionDTO;
import com.bofa.b2bi.api.service.TranmissionReportSearchService;

@Service
public class TranmissionReportSearchServiceImpl implements TranmissionReportSearchService {
	
	@Autowired
	private TransmissionReportDao transmissionReportDao;
	
	public List<TransmissionDTO> getTransmissionInformation(String userName, String jsonString) {		
		return transmissionReportDao.getTrasmissionReport(userName, jsonString);
	}	

}
