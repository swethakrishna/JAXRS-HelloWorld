package com.bofa.b2bi.api.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bofa.b2bi.api.error.B2BIError;
import com.bofa.b2bi.api.exception.B2BIException;
import com.bofa.b2bi.api.response.TokenResponse;
import com.bofa.b2bi.api.response.UserDto;
import com.bofa.b2bi.api.service.impl.TokenRequestService;
import com.bofa.b2bi.core.exception.NotFoundException;
import com.bofa.b2bi.core.exception.ValidationException;
import com.bofa.soap.client.ArrayOfWSNameValue;
import com.bofa.soap.client.ArrayOfWSTokenDetail;
import com.bofa.soap.client.ArrayOfWSTokenUserDetail;
import com.bofa.soap.client.OTPException_Exception;
import com.bofa.soap.client.WSAuthResponse;
import com.bofa.soap.client.WSNameValue;
import com.bofa.soap.client.WSTokenDetail;
import com.bofa.soap.client.WSTokenDetailsResponse;
import com.bofa.soap.client.WSTokenRequestDetails;
import com.bofa.soap.client.WSTokenUserDetail;
import com.bofa.soap.client.WSUser;
import com.bofa.soap.client.WebTemplate;

@Service
public class TokenService {
	
	@Autowired
	private TokenRequestService tokenRequestService;
	
	@Autowired
	private OTPService otpService;
	
	@Autowired
	private WSRequestService wSRequestService;
	
	public ArrayOfWSTokenDetail getTokenDetails(UserDto user) {
		ArrayOfWSTokenDetail tokenDetails = null;
		WSUser wSUser = wSRequestService.createWSUser(user);
		tokenDetails = getTokenInfo(wSUser, wSUser);
		return tokenDetails;
	}
	
	public TokenResponse validateUserToken(UserDto user, String otp) {
		WSUser actor = wSRequestService.createWSUser(user);
		ArrayOfWSTokenDetail tokenInfo = getTokenInfo(actor, actor);
		
		WSTokenDetail tokenDetail = getTokenDetail(tokenInfo.getWSTokenDetail());
		validateTokenDetail(tokenDetail);
		
		WSTokenUserDetail userDetail = getTokenUserDetail(tokenDetail, user);
		if (userDetail.getUserStateName().equals("provisioned")) {
			return activateUserToken(user, actor, tokenDetail.getTokenSerial(), otp);
		} else if (userDetail.getUserStateName().equals("enabled")) {
			return otpService.validateUserOTP(user, otp);
		}
		throw new ValidationException(B2BIError.INVALID_USER_STATUS, "User status is invalid.") ;
	}
	
	public Map<String,String> executeMFAFlow(UserDto userDto) 
    {
		Map<String,String> tokenInfo = null;
    	ArrayOfWSTokenDetail tokenDetails = this.getTokenDetails(userDto);
		if(tokenDetails == null || tokenDetails.getWSTokenDetail() == null) {
			WSTokenRequestDetails tokenRequestDetails = tokenRequestService.submitTokenRequest(userDto);
			if(tokenRequestDetails != null) {
				tokenInfo = tokenRequestService.processSubmitTokenRequestResponse(tokenRequestDetails);
				if(tokenInfo != null && !tokenInfo.isEmpty()) {
					if(tokenInfo.get("tokenStateName") != null && tokenInfo.get("userStateName") != null) {
						if("enabled".equals(tokenInfo.get("tokenStateName")) && "provisioned".equals(tokenInfo.get("userStateName"))) 
						{
							otpService.sendVirtualOTP(userDto);
						}
					}
				}
			}
		} 
		else {
			if(tokenDetails.getWSTokenDetail() != null && !tokenDetails.getWSTokenDetail().isEmpty()) {
				List<WSTokenDetail> wsTokenDetails = tokenDetails.getWSTokenDetail();
				tokenInfo = this.processTokenDetails(wsTokenDetails);
				if(tokenInfo != null && !tokenInfo.isEmpty()) {
					for(WSTokenDetail wsTokenDetail : wsTokenDetails) {
						ArrayOfWSNameValue arrayOfWSNameValue = wsTokenDetail.getTokenAttributes();
						if(arrayOfWSNameValue != null) {
							List<WSNameValue> wsNameValues = arrayOfWSNameValue.getWSNameValue();
							if(wsNameValues != null && !wsNameValues.isEmpty()) {
								for(WSNameValue wsNameValue : wsNameValues) {
									if("TOKEN_TYPE".equals(wsNameValue.getName()) && "VirtualToken".equals(wsNameValue.getValue())) {
										if(tokenInfo.get("tokenStateName") != null && tokenInfo.get("userStateName") != null) {
											if("enabled".equals(tokenInfo.get("tokenStateName")) && ("provisioned".equals(tokenInfo.get("userStateName")) || "enabled".equals(tokenInfo.get("userStateName")))) 
											{
												otpService.sendVirtualOTP(userDto);
											}
										}
									}									
								}
							}
						}
					}
				}
			}
		}
		return tokenInfo;
    }
	
	private Map<String,String> processTokenDetails(List<WSTokenDetail> wsTokenDetails) 
	{
		Map<String,String> tokenInfoMap = new HashMap<String,String>();			
		for(WSTokenDetail wsTokenDetail : wsTokenDetails) {
			tokenInfoMap.put("tokenSerial", wsTokenDetail.getTokenSerial());
			tokenInfoMap.put("tokenStateName", wsTokenDetail.getTokenStateName());
			ArrayOfWSTokenUserDetail arrayOfWSTokenUserDetail = wsTokenDetail.getTokenUsers();
			if(arrayOfWSTokenUserDetail != null) {
				List<WSTokenUserDetail> wsTokenUserDetails = arrayOfWSTokenUserDetail.getWSTokenUserDetail();
				if(wsTokenUserDetails != null && !wsTokenUserDetails.isEmpty()) {
					for(WSTokenUserDetail wsTokenUserDetail : wsTokenUserDetails) {
						tokenInfoMap.put("userStateName", wsTokenUserDetail.getUserStateName());
					}
				}
			}						
		}
		return tokenInfoMap;
	}
	
	private ArrayOfWSTokenDetail getTokenInfo(WSUser actor, WSUser target) {
		WSTokenDetailsResponse wsTokenDetailsResponse = null;
		try {
			wsTokenDetailsResponse = WebTemplate.getPort().getUserTokenDetails(actor, target, null);
		} catch (OTPException_Exception e) {
			throw new B2BIException("Some internal error occured in web service call. Please contact your system administrator.");
		}
		return wsTokenDetailsResponse.getTokens();
	}
	
	private TokenResponse activateUserToken(UserDto user, WSUser targetUser, String token, String otp) {
		WSAuthResponse response = null;
		ArrayOfWSNameValue arrayOfWSNameValue = wSRequestService.createActivateUserTokenRequest(user);
		try {
			response = WebTemplate.getPort().activateUserToken(targetUser, targetUser, token, "", otp, arrayOfWSNameValue);
		} catch(Exception e) {
			throw new B2BIException("Some internal error occured in web service call. Please contact your system administrator.");
		}
		if (!response.isStatus()) {
			throw new B2BIException("Some internal error occured in web service call. Please contact your system administrator.");
		}
		return new TokenResponse(true, "activated");
	}
	
	private WSTokenDetail getTokenDetail(List<WSTokenDetail> tokenDetails) {
		WSTokenDetail wSTokenDetail = null;
		if (tokenDetails != null) {
			wSTokenDetail = tokenDetails.stream().filter(tokenDetail ->tokenDetail.getTokenAttributes().getWSNameValue().stream()
						   .anyMatch(e -> e.getName().equalsIgnoreCase("TOKEN_TYPE") && e.getValue().equalsIgnoreCase("VirtualToken"))).findAny().orElse(null);;
				
		}
		return wSTokenDetail;
	}
	
	private void validateTokenDetail(WSTokenDetail tokenDetail) {
		if (tokenDetail == null) {
			throw new NotFoundException(B2BIError.RESOURCE_NOT_FOUND);
		}
		if (!tokenDetail.getTokenStateName().equals("enabled")) {
			throw new ValidationException(B2BIError.INVALID_TOKEN, "No active token present.");
		}
		
	}
	
	private WSTokenUserDetail getTokenUserDetail(WSTokenDetail tokenDetail, UserDto userDto) {
		WSTokenUserDetail userDetails = tokenDetail.getTokenUsers().getWSTokenUserDetail().stream()
				.filter(e -> e.getUser().getTargetUser().getLogin().equalsIgnoreCase(userDto.getUserName()))
				.findAny()
				.orElse(null);
		return userDetails;
	}
}
