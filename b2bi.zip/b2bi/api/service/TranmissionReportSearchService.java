package com.bofa.b2bi.api.service;

import java.util.List;

import com.bofa.b2bi.api.model.TransmissionDTO;

public interface TranmissionReportSearchService {
	
	List<TransmissionDTO> getTransmissionInformation(String userName, String jsonString);
	
}
