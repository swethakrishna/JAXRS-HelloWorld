package com.bofa.b2bi.api.service;

import com.bofa.b2bi.api.model.ChangePasswordRequest;
import com.bofa.b2bi.api.model.UserConfig;
import com.bofa.b2bi.api.model.UserInfo;
import com.bofa.soap.client.WSUser;

public interface UserInfoService {

	UserInfo getUserInformation(String userName);

	UserInfo updateUserInformation(String userClientId, UserInfo userInfo) throws Exception;

	UserInfo updateUserInfo(UserInfo userInfo) throws Exception;

	String getUserRoleByUserName(String userName);

	UserConfig getUserConfig(String userName);

	void changePassword(ChangePasswordRequest changePwdInfo);

	void createAdditionalUserInfo(UserInfo userinfo);
	
}
