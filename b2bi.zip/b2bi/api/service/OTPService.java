package com.bofa.b2bi.api.service;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bofa.b2bi.api.error.B2BIError;
import com.bofa.b2bi.api.exception.B2BIException;
import com.bofa.b2bi.api.response.TokenResponse;
import com.bofa.b2bi.api.response.UserDto;
import com.bofa.b2bi.core.exception.ValidationException;
import com.bofa.soap.client.ArrayOfWSNameValue;
import com.bofa.soap.client.OTPException_Exception;
import com.bofa.soap.client.WSUser;
import com.bofa.soap.client.WebTemplate;

@Service
public class OTPService {
	
	@Autowired 
	private Properties configProps;
	
	@Autowired
	private WSRequestService wSRequestService;	
	

	public void sendVirtualOTP(UserDto userDto) {
		WSUser wSUser = wSRequestService.createWSUser(userDto);
		String countryCode = configProps.getProperty("com.baci.mfa.countrycode");
		ArrayOfWSNameValue arrayOfWSNameValue = wSRequestService.createSendVitualOTPRequest(userDto, countryCode);
		try {
			WebTemplate.getPort().sendVirtualOTP(wSUser, wSUser, "Mobile", arrayOfWSNameValue);
		} catch (OTPException_Exception e) {
			throw new B2BIException("Some internal error occured in otp web service call. Please contact your system administrator.");
		}
	}
	
	/**
	 * This method verifies given OTP code with userInfo given.
	 * 
	 * @param userId
	 * @param otpCode
	 */
	public TokenResponse validateUserOTP(UserDto user, String otpCode) {
		
		// Generate WSUser.
		WSUser wSUser = wSRequestService.createWSUser(user);

		boolean isOTPVerifiedSuccessfully = false;
		try {
			isOTPVerifiedSuccessfully = WebTemplate.getPort().validateToken(wSUser, wSUser, otpCode);
		} catch (OTPException_Exception e) {
			throw new B2BIException("Some internal error occured in validateToken web service call. Please contact your system administrator.");
		}
		if (!isOTPVerifiedSuccessfully) {
			throw new ValidationException(B2BIError.INVALID_OTP, "Invalid otp entered");
		}
		return new TokenResponse(true, "validated");
	}
}
