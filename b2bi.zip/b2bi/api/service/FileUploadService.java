package com.bofa.b2bi.api.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;

import org.apache.commons.net.ftp.FTPSClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bofa.b2bi.api.impl.FTPException;
import com.bofa.b2bi.api.model.FolderDetails;
import com.bofa.b2bi.api.util.CommonUtility;
import com.bofa.b2bi.api.util.FTPSConnection;

@Service
public class FileUploadService {
	
	@Autowired
	FileService fileService;
	
	@Autowired 
	private Properties configProps;
	
	public String getDirectoryDetails(final String authString, String dirName) throws FTPException, IOException 
	{
		List<FolderDetails> dirList = new ArrayList<>();
		String credentials[] = CommonUtility.getUserNameAndPassword(authString);
		
		String hostname = configProps.getProperty("com.baci.ftpsrv.hostname");
		int portNo = Integer.parseInt(configProps.getProperty("com.baci.ftpsrv.portno"));
		String userName = credentials[0];
        String password = credentials[1];  
        //FTPConnection con = new FTPConnection(hostname, portNo, userName, password, "/");
        //FTPClient ftpClient = con.getConnection();
        FTPSConnection con = new FTPSConnection(hostname, portNo, userName, password, "/");
        FTPSClient ftpClient = con.getConnection();
        fileService.listDirectory(ftpClient, "/", dirName, dirList);
        con.closeConnection(ftpClient);	
        
        if (dirName != null && dirName.equalsIgnoreCase("incoming")) {
        	return getIncomingDirectories(dirList);
        } else {
        	return getOutgoingDirectories(dirList);
        }
	}
	
	private String getIncomingDirectories(List<FolderDetails> directories) {
		List<FolderDetails> incomingDirectories = directories.stream().filter(e -> !e.getFileName().startsWith("/incoming/temp")).collect(Collectors.toList()) ;
        return CommonUtility.prepareFileData(incomingDirectories);
	}
	
	private String getOutgoingDirectories(List<FolderDetails> directories) {
		//List<FolderDetails> incomingDirectories = directories.stream().filter(e -> !e.getFileName().startsWith("incoming")).collect(Collectors.toList()) ;
        return CommonUtility.prepareFileData(directories);
	}
	
	public void uploadFile(InputStream fis, String fileName, String authString, String dirName) throws FTPException, IOException {
		String credentials[] = CommonUtility.getUserNameAndPassword(authString);
		
		String hostname = configProps.getProperty("com.baci.ftpsrv.hostname");
		int portNo = Integer.parseInt(configProps.getProperty("com.baci.ftpsrv.portno"));
		String userName = credentials[0];
        String password = credentials[1]; 
        FTPSConnection con = new FTPSConnection(hostname, portNo, userName, password, "/");
        FTPSClient ftpClient = con.getConnection();
        //FTPConnection con = new FTPConnection(hostname, portNo, userName, password, "/");
        //FTPClient ftpClient = con.getConnection();
        fileService.uploadFile(ftpClient, fis, fileName, dirName);
        con.closeConnection(ftpClient);
        
	}
}
