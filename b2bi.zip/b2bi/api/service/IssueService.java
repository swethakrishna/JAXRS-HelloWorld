package com.bofa.b2bi.api.service;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.MapBindingResult;

import com.bofa.b2bi.api.dao.IssueDao;
import com.bofa.b2bi.api.dto.IssueDto;
import com.bofa.b2bi.api.error.B2BIError;
import com.bofa.b2bi.api.exception.DataValidationException;
import com.bofa.b2bi.api.model.Issue;
import com.bofa.b2bi.api.response.IssueResponseDto;
import com.bofa.b2bi.api.validator.IssueDtoValidator;
import com.bofa.b2bi.core.exception.NotFoundException;

@Service
public class IssueService {
	
	@Autowired
	IssueDao issueDao;
	
	@Autowired
	ModelMapper modelMapper;
	
	@Autowired 
	IssueDtoValidator issueDtoValidator;
	
	public Long createIssue(IssueDto issueDto, InputStream fis){
		MapBindingResult errors = new MapBindingResult(new HashMap<String, String>(), "root");
		if (Objects.isNull(fis)) {
			throw new NotFoundException("Attachment not found", B2BIError.RESOURCE_NOT_FOUND);
		}
		issueDtoValidator.validateFields(issueDto, errors);
        if (errors.hasErrors()) {
            throw new DataValidationException("Issue could not be created.", errors);
        }
		return issueDao.create(issueDto, fis);
	}

	public List<IssueResponseDto> getIssues(String userName) {
		List<Issue> issues = issueDao.getAll(userName);
		List<IssueResponseDto> iResponses = new ArrayList<>();
		for(Issue issue : issues) {
			IssueResponseDto iResponse =  modelMapper.map(issue, IssueResponseDto.class);
			iResponses.add(iResponse);
		}
		return iResponses;
	}
}
