package com.bofa.b2bi.api.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.bofa.b2bi.api.response.UserDto;
import com.bofa.soap.client.ApplicationLoginID;
import com.bofa.soap.client.ArrayOfWSNameValue;
import com.bofa.soap.client.WSNameValue;
import com.bofa.soap.client.WSUser;

@Service
public class WSRequestService {	
	
	public ArrayOfWSNameValue createActivateUserTokenRequest(UserDto userDto) {
		ArrayOfWSNameValue arrayOfWSNameValue = new ArrayOfWSNameValue();
		List<WSNameValue> wSNameValues = new ArrayList<>();
		wSNameValues.add(createWsNameValue("TOKEN_TYPE", "Virtual"));
		wSNameValues.add(createWsNameValue("IS_OTP_PREF_PERSIST_REQUIRED", "true"));
		wSNameValues.add(createWsNameValue("LOB", "GENERAL"));
		wSNameValues.add(createWsNameValue("PREFERRED_DELIVERY", "Mobile"));
		wSNameValues.add(createWsNameValue("EMAIL", userDto.getEmail()));
		wSNameValues.add(createWsNameValue("MOBILE_NUMBER", userDto.getPhoneNumber()));
		wSNameValues.add(createWsNameValue("PHONE_NUMBER", userDto.getPhoneNumber()));
		wSNameValues.add(createWsNameValue("COUNTRY", userDto.getState()));
		wSNameValues.add(createWsNameValue("IS_VIRTUAL_TOKEN", "true"));
		arrayOfWSNameValue.getWSNameValue().addAll(wSNameValues);
		return arrayOfWSNameValue;
	}
	
	public ArrayOfWSNameValue createSendVitualOTPRequest(UserDto userDto, String countryCode) {
		ArrayOfWSNameValue arrayOfWSNameValue = new ArrayOfWSNameValue();
		String mobile = countryCode.concat(userDto.getPhoneNumber());
		arrayOfWSNameValue.getWSNameValue().add(createWsNameValue("MOBILE_NUMBER", mobile));
		return arrayOfWSNameValue;
	}
	
	public WSUser createWSUser(UserDto userDto) {
		ApplicationLoginID appLoginId = new ApplicationLoginID();
		appLoginId.setSubGroup(userDto.getType());
		appLoginId.setLogin(userDto.getUserName()); // BOA employee NBK ID, who has token 
		WSUser wsuser = new WSUser();
		wsuser.setTargetUser(appLoginId);
		wsuser.setApp("b2biportal");
		wsuser.setApplicationName("B2BI Portal");
		wsuser.setSubGroupName(userDto.getType());
		wsuser.setUserEmail(userDto.getEmail());
		wsuser.setUserName(userDto.getFirstName());
		wsuser.setUserPhone(userDto.getPhoneNumber());
		wsuser.setUserPhoneExt(userDto.getPhoneNumber());
		return wsuser;
	}
	
	private WSNameValue createWsNameValue(String name, String value) {
		WSNameValue wSNameValue = new WSNameValue();
		wSNameValue.setName(name);
		wSNameValue.setValue(value);
		return wSNameValue;
	}
	
}