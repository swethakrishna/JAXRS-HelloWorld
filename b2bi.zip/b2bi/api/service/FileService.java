package com.bofa.b2bi.api.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.springframework.stereotype.Service;

import com.bofa.b2bi.api.impl.FTPException;
import com.bofa.b2bi.api.model.FolderDetails;

@Service
public class FileService {

	public void listDirectory(FTPClient ftpClient, String parentDir,
	        String currentDir, List<FolderDetails> folderList) throws IOException {
	    String dirToList = parentDir;
	    if (!currentDir.equals("")) {
	        dirToList += currentDir+"/";
	    }
	    ftpClient.changeWorkingDirectory(dirToList);
	    FTPFile[] subFiles = ftpClient.listFiles(dirToList);
	    if (subFiles != null && subFiles.length > 0) {
	        for (FTPFile aFile : subFiles) {
	            String currentFileName = aFile.getName();
	            if (currentFileName.equals(".")
	                    || currentFileName.equals("..")) {
	                // skip parent directory and directory itself
	                continue;
	            }
	            
	            if (aFile.isDirectory()) {
	            	FolderDetails fd = new FolderDetails();
	            	fd.setFileName(dirToList +currentFileName);
	            	folderList.add(fd);
	                listDirectory(ftpClient, dirToList, currentFileName, folderList);
	            } 
	        }
	    }
	}
	
	public void uploadFile(FTPClient ftpClient, InputStream fis, String fileName, String dirName) throws IOException, FTPException {
		// set the file type for the transfer
        int type = FTP.BINARY_FILE_TYPE;
        ftpClient.setFileType(type);
        // change the working directory
        if ( !ftpClient.changeWorkingDirectory(dirName)) {
            throw new FTPException("Cannot change directory to " + dirName + "." );
        }
		ftpClient.storeFile(fileName, fis);
	}
	
}
