package com.bofa.b2bi.api.service;

import java.util.Objects;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bofa.b2bi.api.error.B2BIError;
import com.bofa.b2bi.api.response.AuthenticationResponse;
import com.bofa.b2bi.api.response.TokenResponse;
import com.bofa.b2bi.api.response.UserDto;
import com.bofa.b2bi.api.service.impl.UserService;
import com.bofa.b2bi.api.util.CommonUtility;
import com.bofa.b2bi.api.util.FTPSConnection;
import com.bofa.b2bi.core.exception.ValidationException;

@Service
public class AuthenticationService {

	@Autowired 
	private Properties configProps;
	
	@Autowired
	private TokenService tokenService;
	
	@Autowired
	private UserService userService;
	
	public AuthenticationResponse authenticate(String authString) 
	{
    	String[] credentials = CommonUtility.getUserNameAndPassword(authString);
    	validateCredentials(credentials);
		String hostname = configProps.getProperty("com.baci.ftpsrv.hostname");
		int portNo = Integer.parseInt(configProps.getProperty("com.baci.ftpsrv.portno"));
		FTPSConnection con = new FTPSConnection(hostname, portNo, credentials[0], credentials[1], "/");
		con.login();
		UserDto userDto = userService.getUser(credentials[0]);
		if(Boolean.parseBoolean(configProps.getProperty("com.baci.mfa.enabled"))) {
			tokenService.executeMFAFlow(userDto);
		}
		return new AuthenticationResponse(false, userDto);
	}
    
    public TokenResponse validateUserToken(String userName, String otp) {
    	UserDto userDto = userService.getUser(userName);
    	return tokenService.validateUserToken(userDto, otp);
    }
    
    private void validateCredentials(String[] credentials) {
    	if (Objects.isNull(credentials[0]) || Objects.isNull(credentials[1])) {
    		throw new ValidationException(B2BIError.CAN_NOT_BE_NULL, "Credentials cannot be null");
    	}
    }
}
