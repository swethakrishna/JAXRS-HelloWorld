package com.bofa.b2bi.api.service;

import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.bofa.b2bi.api.impl.FTPException;

public interface FileDownloadService {	
	
	String getDirectoryDetails(String authString, String dirName) throws FTPException;
	
	String getFileDetails(String authString, String remoteDir, Map<String,String> filterParams) throws FTPException;
	
	String downloadFile(HttpServletResponse response, String authString, String fileName, String remoteDir) throws FTPException;
	
	String getListOfCertficates(String typeOfCert);
	
	String downloadCertificate(HttpServletResponse response, String certId);
	
}
