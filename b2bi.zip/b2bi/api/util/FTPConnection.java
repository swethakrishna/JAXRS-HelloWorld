package com.bofa.b2bi.api.util;

import java.io.IOException;
import java.net.SocketException;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;

import com.bofa.b2bi.api.impl.FTPException;

public class FTPConnection {

	private String hostname;
	private int portNo;
	private String userName;
	private String password;
	private String remoteDir;
	
	public FTPConnection() {
		super();
	}
	public FTPConnection(String hostname, int portNo, String userName, String password, String remoteDir) {
		this.hostname = hostname;
		this.portNo = portNo;
		this.userName = userName;
		this.password = password;
		this.remoteDir = remoteDir;		
	}
	public FTPClient getConnection() throws FTPException
	{
		FTPClient ftp = new FTPClient();
	    System.out.println("Connecting TO FTP server...");
	    try {
	    	
	        ftp.connect(hostname, portNo);
	        //enter passive mode
	        ftp.enterLocalPassiveMode();
	        if(!ftp.login(userName, password)) {
	            ftp.logout();
	            throw new FTPException("Cannot login to FTP server.");
	        }
	        int reply = ftp.getReplyCode();
	        //FTPReply stores a set of constants for FTP reply codes. 
	        if(!FTPReply.isPositiveCompletion(reply)) {
	            ftp.disconnect();
	            throw new FTPException("LogIn Inturrupted!");
	        }
	
	        //change current directory
	       // ftp.changeWorkingDirectory(remoteDir);
	    } 
	    catch(SocketException e) {
	        throw new FTPException("socket Cannot send file to FTP server.", e);
	    } catch(IOException e) {
	        throw new FTPException("Cannot send file to FTP server.", e);
	    } 
	   return ftp;
    }
	
	public boolean login() throws FTPException {
		boolean isLogin = false;
		FTPClient ftp = new FTPClient();
	    System.out.println("Connecting TO FTP server...");
	    try {
	    	
	        ftp.connect(hostname, portNo);
	        ftp.enterLocalPassiveMode();
	        isLogin = ftp.login(userName, password);
	        closeConnection(ftp);
	    } 
	    catch(SocketException e) {
	        throw new FTPException("socket Cannot send file to FTP server.", e);
	    } catch(IOException e) {
	        throw new FTPException("Cannot send file to FTP server.", e);
	    } 
	   return isLogin;
	}
	
	public void closeConnection(FTPClient ftp) {
		if(ftp.isConnected()) {
            try {
            	System.out.println("Disconnecting from FTP server...");
                ftp.logout();
                ftp.disconnect();
                System.out.println("Disconnected from FTP server SUCCESSFULLY.");
            } catch(IOException e1) {
                System.err.println(e1.getMessage());
            }
        }
	}
}
