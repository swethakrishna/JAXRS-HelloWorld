package com.bofa.b2bi.api.util;


import java.io.IOException;
import java.net.SocketException;

import org.apache.commons.net.ftp.FTPReply;
import org.apache.commons.net.ftp.FTPSClient;

import com.bofa.b2bi.api.error.B2BIError;
import com.bofa.b2bi.api.exception.B2BIException;
import com.bofa.b2bi.api.exception.BusinessValidationException;
import com.bofa.b2bi.api.impl.FTPException;
import com.bofa.b2bi.core.exception.ValidationException;

public class FTPSConnection {

	private static final String INVALID_LOGIN ="530 Login incorrect.";
	private static final int REPLY_ERROR_CODE = 530;
	private String hostname;
	private int portNo;
	private String userName;
	private String password;
	private String remoteDir;
	
	public FTPSConnection() {
		super();
	}
	public FTPSConnection(String hostname, int portNo, String userName, String password, String remoteDir) {
		this.hostname = hostname;
		this.portNo = portNo;
		this.userName = userName;
		this.password = password;
		this.remoteDir = remoteDir;		
	}
	public FTPSClient getConnection() throws FTPException
	{
		FTPSClient ftps = new FTPSClient("SSL", false);
		ftps.setAuthValue("SSL");
	    System.out.println("Connecting TO FTP server...");
	    try {
	    	
	    	ftps.connect(hostname, portNo);
	        
	        // Set protection buffer size
	        ftps.execPBSZ(0);
	          // Set data channel protection to private
	        ftps.execPROT("P");
	          // Enter local passive mode
	        ftps.enterLocalPassiveMode();
	        if(!ftps.login(userName, password)) {
	            ftps.logout();
	            throw new FTPException("Cannot login to FTP server.");
	        }
	        int reply = ftps.getReplyCode();
	        //FTPReply stores a set of constants for FTP reply codes. 
	        if(!FTPReply.isPositiveCompletion(reply)) {
	            ftps.disconnect();
	            throw new FTPException("LogIn Inturrupted!");
	        }
	
	        //change current directory
	       // ftp.changeWorkingDirectory(remoteDir);
	    } 
	    catch(SocketException e) {
	        throw new FTPException("socket Cannot send file to FTP server.", e);
	    } catch(IOException e) {
	        throw new FTPException("Cannot send file to FTP server.", e);
	    } 
	   return ftps;
    }
	
	public void login() {
		FTPSClient ftps = new FTPSClient("SSL", false);
		ftps.setAuthValue("SSL");
	    System.out.println("Connecting TO FTP server...");
	    try {
	    	
	        ftps.connect(hostname, portNo);
	        ftps.enterLocalPassiveMode();
	        ftps.login(userName, password);
	        validateConnection(ftps.getReplyCode(), ftps.getReplyString());
	        
	    } 
	    catch(SocketException e) {
	        throw new B2BIException("socket Cannot send file to FTP server.");
	    } catch(IOException e) {
	        throw new B2BIException("Cannot send file to FTP server.");
	    } 
	    finally {
	    	closeConnection(ftps);
	    }
	}
	
	private void validateConnection(int replyCode, String replayMessage) {
		if (replyCode == REPLY_ERROR_CODE && replayMessage.contains(INVALID_LOGIN)) {
        	throw new ValidationException(B2BIError.INVALID_LOGIN, replayMessage);
        } else if (replyCode == REPLY_ERROR_CODE ) {
        	throw new BusinessValidationException(B2BIError.NEW_USER, replayMessage);
        }
	}
	
	public void closeConnection(FTPSClient ftp) {
		if(ftp.isConnected()) {
            try {
            	System.out.println("Disconnecting from FTP server...");
                ftp.logout();
                ftp.disconnect();
                System.out.println("Disconnected from FTP server SUCCESSFULLY.");
            } catch(IOException e1) {
                System.err.println(e1.getMessage());
            }
        }
	}
}

