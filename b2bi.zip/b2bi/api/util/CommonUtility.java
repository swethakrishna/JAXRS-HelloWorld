package com.bofa.b2bi.api.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.net.SocketException;
import java.nio.charset.Charset;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.PropertyResourceBundle;

import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.commons.net.ftp.FTPSClient;

import com.bofa.b2bi.api.impl.App;
import com.bofa.b2bi.api.impl.FTPException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CommonUtility {	
	
	public static String prepareFileData(final List<?> folderList) 
	{		
		ObjectMapper mapper = new ObjectMapper();
	    String jsonInString = "";
	    try {
			jsonInString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(folderList);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		} 
	    return jsonInString;
	}
	
	public static String calculateFileSize(final long fileSize) 
	{
		double bytes = fileSize;
		double kilobytes = 0;
		if(bytes >= 1024) {
			kilobytes = (bytes / 1024);
		} else {
			return round(bytes, 2) + " Bytes";
		}
		double megabytes = 0;
		if(kilobytes >= 1024) {
			megabytes = (kilobytes / 1024);
		} else {
			return round(kilobytes, 2) + " KB";
		}
		double gigabytes = 0;
		if(megabytes >= 1024) {
			gigabytes = (megabytes / 1024);
		} else {
			return round(megabytes, 2) + " MB";
		}		 
		return round(gigabytes, 2) + " GB";
	}
	
	private static double round(double value, int numberOfDigitsAfterDecimalPoint) {
        BigDecimal bigDecimal = new BigDecimal(value);
        bigDecimal = bigDecimal.setScale(numberOfDigitsAfterDecimalPoint, BigDecimal.ROUND_HALF_UP);
        return bigDecimal.doubleValue();
	}
	
	public static PropertyResourceBundle getPropertiesInstance() {
		App app = new App();
		PropertyResourceBundle prb = null;
		try{
			prb = app.parsePropertiesFile();
		}catch(FTPException e) {
			e.printStackTrace();
		}
		return prb;
	}
	
	public static String[] getUserNameAndPassword(String authString) {
    	String[] values = null;
    	String credentials = "";
        if (authString != null) {
        	if(authString.startsWith("Basic")) {
        		String base64Credentials = authString.substring("Basic".length()).trim();
        		credentials = new String(Base64.getDecoder().decode(base64Credentials), Charset.forName("UTF-8"));
        	} else {
        		credentials = new String(Base64.getDecoder().decode(authString.trim()), Charset.forName("UTF-8"));
        	}
            values = credentials.split(":",2);
        }
        return values;
    }
	
	public static void recursiveScanner(FTPSClient ftpsClient, final String parentDir, final String currentDir, final List<String> dirNameList)
	{
		String dirToList = parentDir;
		if (!currentDir.equals("")) {
			dirToList = dirToList + currentDir + "/";
		}
		
		FTPFile subFiles[] = null;
		try {
			ftpsClient.changeWorkingDirectory(dirToList);
			subFiles = ftpsClient.listFiles(dirToList);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		if (subFiles != null && subFiles.length > 0) 
		{
			for (FTPFile ftpFile : subFiles) 
			{
				String fileName = ftpFile.getName();
				if (ftpFile.getType() == FTPFile.DIRECTORY_TYPE && !"incoming".equals(fileName)) {
					dirNameList.add(dirToList + fileName);
					recursiveScanner(ftpsClient, dirToList, fileName, dirNameList);
				}
			}
		}
	}
	
	public static FTPSClient connectFTPServer(final Map<String,String> connParams) throws FTPException 
	{
		FTPSClient ftps = new FTPSClient("SSL", false);
		ftps.setAuthValue("SSL");
		//ftp.setTrustManager(TrustManagerUtils.getAcceptAllTrustManager());
		//ftp.setTrustManager(TrustManagerUtils.getValidateServerCertificateTrustManager());
		//ftp.setTrustManager(null);
		try {
			System.out.println("Connecting TO FTP server...");
			//ftp.addProtocolCommandListener(new PrintCommandListener(new PrintWriter(System.out)));
	        ftps.connect(connParams.get("hostname"), 57033);	        
	        ftps.execPBSZ(0);
	        ftps.execPROT("P");

	        //enter passive mode
	        ftps.enterLocalPassiveMode();
	        
	        if(!ftps.login(connParams.get("userName"), connParams.get("password"))) {
	            ftps.logout();
	            throw new FTPException("Cannot login to FTP server!");
	        }
	        int reply = ftps.getReplyCode();
	        //FTPReply stores a set of constants for FTP reply codes. 
	        if(!FTPReply.isPositiveCompletion(reply)) {
	            ftps.disconnect();
	            throw new FTPException("LogIn Inturrupted!");
	        }
	        System.out.println("Connected TO FTP server.");
	    } 
	    catch(SocketException e) {
	        throw new FTPException("Connection to FTP server failed!", e);
	    } catch(IOException e) {
	        throw new FTPException("Connection to FTP server failed!", e);
	    }
		return ftps;
	}
	
	public static void disconnectFTPServer(FTPSClient ftps)
	{
		if(ftps.isConnected()) {
            try {
            	System.out.println("Disconnecting from FTP server...");
                ftps.logout();
                ftps.disconnect();
                System.out.println("Disconnected from FTP server.");
            } catch(IOException e1) {
                System.err.println(e1.getMessage());
            }
        }
	}
	
	public static byte[] getBytes(InputStream is) throws IOException {

	    int len;
	    int size = 1024;
	    byte[] buf;

	    if (is instanceof ByteArrayInputStream) {
	      size = is.available();
	      buf = new byte[size];
	      len = is.read(buf, 0, size);
	    } else {
	      ByteArrayOutputStream bos = new ByteArrayOutputStream();
	      buf = new byte[size];
	      while ((len = is.read(buf, 0, size)) != -1)
	        bos.write(buf, 0, len);
	      buf = bos.toByteArray();
	    }
	    return buf;
	  }
}
