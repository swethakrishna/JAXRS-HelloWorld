/**
 * 
 */
package com.bofa.b2bi.api.util;

/**
 * @author ZKF2BEY
 *
 */
public class Constants {

	public static String LAST_LOGIN_TIME_SQL_QUERY_OLD = "SELECT LOGIN_TIME AS LOGINTIME FROM (SELECT LOGIN_TIME, DENSE_RANK() OVER(ORDER BY LOGIN_TIME DESC) RNUM FROM YFS_USER_ACT_AUDIT WHERE TRIM(USER_ID) = ?) USERACT WHERE RNUM=2";

	public static String LAST_LOGIN_TIME_SQL_QUERY = "SELECT * FROM YFS_USER_ACT_AUDIT WHERE USER_ID = ?";
	
	public static String LAST_LOGIN_TIME_FIELD = "LAST_ACTIVE_TIME";
	
	public static String LAST_LOGIN_TIME_FORMAT = "MM/dd/yyyy hh:mm:ss a";
}
