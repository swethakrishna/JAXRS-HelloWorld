package com.bofa.b2bi.api.util;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.bofa.b2bi.api.common.OracleReplicatingConnection;
import com.bofa.b2bi.api.exception.B2BIException;

//import com.sterlingcommerce.woodstock.util.frame.jdbc.JDBCConnectionException;
//import com.sterlingcommerce.woodstock.util.frame.jdbc.JDBCService;

public class DBUtil {

    /** ORACLE Database.  One of the supported db types for ML application */
    public static final int DB_TYPE_ORACLE = 0;

    /** MySQL Database.  One of the supported db types for ML application */
    public static final int DB_TYPE_MYSQL = 1;

    /** Error codes returned for violating unique constraint in ORACLE **/
    public static final int ERROR_CODE_ORACLE_UNIQUE = 1;

    /** Error codes returned for violating unique constraint in MySQL **/
    public static final int ERROR_CODE_MYSQL_UNIQUE = 1062;

    /**
     * Obtains connection from the Merrill_Lynch_Pool GIS managed JDBC pool
     *
     * @param sessionUser String indicating UI user requesting connection
     *        object.  Used for replication operation tracking
     *
     * @return database connection
     *
     * @throws B2BIException
     */
    public static Connection getNonReplicatingConnection(String sessionUser)
        throws B2BIException {
        Connection con = null;
      //com.baci.db.driver=oracle.jdbc.driver.OracleDriver
      //com.baci.db.connection=jdbc:oracle:thin:@//lcdra0fzc01-scan:49125/B2BI1S
      //com.baci.db.user=CLEAR_ADMIN_TEST
      //com.baci.db.password=B2BI_SIT_ADMIN
        String driver = "oracle.jdbc.driver.OracleDriver";
        String url = "jdbc:oracle:thin:@//lcdra0fzc01-scan:49125/B2BI1S";
        String username = "CLEAR_ADMIN_TEST";
        String password = "B2BI_SIT_ADMIN";

        System.out.println( "Database URL: " + url );

        try {
            Class.forName(driver);
            con = DriverManager.getConnection(url, username, password);
        } catch (SQLException se) {
            throw new B2BIException("Cannot get connection to the database.",
                se);
        } catch (ClassNotFoundException e) {
            throw new B2BIException("Cannot get connection to the database.",
                e);
        }
        

        if (con == null) {
            throw new B2BIException("Cannot get connection to the database.");
        }

        return con;
    }

    /**
     * Obtains connection from the Merrill_Lynch_Pool GIS managed JDBC pool.
     * The connection object returned is actually a concrete instance of
     * ReplicatingConnection class.  This connection class puts copies of the
     * actual SQL into the ML_REPORT_REPLICATION_QUEUE table so the SQL can
     * be executed in remote nodes as well - effectively replicating any
     * database changes.
     *
     * @param sessionUser String indicating UI user requesting connection
     *        object.  Used for replication operation tracking
     *
     * @return database connection (com.ml.jdbc.ReplicatingConnection)
     *
     * @throws B2BIException
     * @see com.ml.jdbc.ReplicatingConnection
     */
    public static Connection getConnection(String sessionUser)
        throws B2BIException {
        Connection con = getNonReplicatingConnection( sessionUser );
        return new OracleReplicatingConnection(con, sessionUser);
    }

    /**
     * Tries to determine the database type using the <code>DatabaseMetaData</code>
     * from the <code>Connection</code> object.  This function should work
     * well as long as the driver providers follow JDBC specifications for
     * providing meta data about the database the driver supports.
     *
     * @return int indicating RDBMS system being used, defaults to DB_TYPE_ORACLE
     *
     */
    public static int getDBType(Connection conn) {
        DatabaseMetaData dbMetaData = null;
        String dbProductName = null;
        try {
            dbMetaData = conn.getMetaData();
            dbProductName = dbMetaData.getDatabaseProductName();
            //System.out.print( "==  DB TYPE for PRODUCT: " + dbProductName  + "..." );
            if (dbProductName.toLowerCase().indexOf("mysql") >= 0) {
                //System.out.print( "DB_TYPE_MYSQL" );
                return DB_TYPE_MYSQL;   // mysql database
            } else {
                //System.out.print( "DB_TYPE_ORACLE" );
                return DB_TYPE_ORACLE;  // default
            }
        } catch (SQLException e) {
            return DB_TYPE_ORACLE; //default if we cannot dynamically determine db type
        }
    }

    

   

    /**
     * Converts SQL wildcard character '%' to 'typical' wildcard character '*' before displaying in UI
     *
     * @param fileNameQualifier String containing '%' characters
     *
     * @return String with all '%' characters replaced with '*'
     * 
     * Following changes are make as a part production issue to fix the '_' a literal instead of wild card
     * Treat %, _, as literal
     * Treat *, ? as wild card
     * 
     */
    public static String formatFileNameQualifierGet(String fileNameQualifier) {
    	//System.out.println("Enterling formatFileNameQualifierGet-->" + fileNameQualifier);
        if (fileNameQualifier != null) {
            return fileNameQualifier
            		.replace((CharSequence)"!!", (CharSequence)"!")
            		.replace((CharSequence)"!%", (CharSequence)"\u001d")
            		.replace((CharSequence)"!_", (CharSequence)"\u001e")
            		.replace('_', '?')
    				.replace('\u001e', '_')
            		.replace('%', '*')
            		.replace('\u001d', '%');
        } else {
            return null;
        }
    }

    /**
     * Replaces all '*' characters with '%'; converts values entered into UI into values appropriate for DB
     *
     * @param fileNameQualifier String containing '%' characters
     *
     * @return String fileNameQualifier with all '*' characters replaced with '%'
     * 
     * Following changes are make as a part production issue to fix the '_' a literal instead of wild card
     * Treat %, _, as literal
     * Treat *, ? as wild card
     */
    public static String formatFileNameQualifierSave(String fileNameQualifier) {
    	//System.out.println("Enterling formatFileNameQualifierSave-->" + fileNameQualifier);
        if (fileNameQualifier != null) {
            return fileNameQualifier
            		.replace((CharSequence)"!", (CharSequence)"!!")
            		.replace('%', '\u001d')
            		.replace('*', '%')
            		.replace('?', '\u001e')
            		.replace((CharSequence)"_", (CharSequence)"!_")
            		.replace('\u001e', '_')
            		.replace((CharSequence)"\u001d", (CharSequence)"!%");
        } else {
            return null;
        }
    }

    /**
     * Replaces all '*' characters with '%'; converts values entered into UI into values appropriate for DB
     *
     * @param searchString String containing '%' characters
     *
     * @return String fileNameQualifier with all '*' characters replaced with '%'
     */
    public static String formatSearchString(String searchString) {
        if (searchString != null) {
            return searchString.replace('*', '%');
        } else {
            return null;
        }
    }
	private static String digit(int len){
		double rangeD = Math.pow(10D, (double)len);
		long rangeL = (long)rangeD;
		long ceil = rangeL - 1;
		long floor = rangeL / 10L;
		long digit = Math.round(Math.random() * rangeD);;
		digit = Math.min(digit, ceil);
		digit = Math.max(digit, floor);
		return Long.toString(digit);
	}
    

    /**
     * Convenience function to set the autocommit for a
     * database connection.  Checks for null connections and
     * doesn't throw exceptions.
     *
     * @param conn database connection
     * @return true autocommit set successfully
     */
    public static boolean setAutoCommit(Connection conn, boolean autoCommit) {
        try {
            if (conn != null) {
                conn.setAutoCommit(autoCommit);
            }
        } catch (SQLException e) {
            return false;
        }
        return true;
    }

    /**
     * Convenience function to roll back a transaction without
     * throwing any exceptions.  Checks for null connections.
     *
     * @param conn database connection
     * @return true if rollback successful, false otherwise
     */
    public static boolean rollback(Connection conn) {
        try {
            if (conn != null) {
                conn.rollback();
            }
        } catch (SQLException e) {
            return false;
        }
        return true;
    }

    /**
     * Closes a ResultSet object
     *
     * @param result ResultSet to be closed
     */
    public static void close(ResultSet result) {
        try {
            if (result != null) {
                result.close();
            }
        } catch (SQLException sqle) {
            System.err.println("Failed to close resultSet");
        }
    }

    /**
     * Closes a Statement object
     *
     * @param stmt Statement to be closed
     */
    public static void close(Statement stmt) {
        try {
            if (stmt != null) {
                stmt.close();
            }
        } catch (SQLException sqle) {
            System.err.println("Failed to close (prepared)Statement");
        }
    }

}
