package com.bofa.b2bi.api.util;

public class BrowserUtil {
	public static enum BrowserType {
		INTERNET_EXPLORER, MOZILA_FIREFOX, SAFARI, NETSCAPE, GOOGLE_CHROME, FLOCK, UNKNOWN
	}

	/**
	 * Each browser sends a the user-agent field with different content
	 * 
	 * 
	 * @param userAgent
	 * @return
	 */
	public static BrowserType getBrowserType(String userAgent) {

		if (userAgent != null) {
			if (userAgent.indexOf("MSIE") != -1 || userAgent.indexOf("rv") != -1)
				return BrowserType.INTERNET_EXPLORER;
			else if (userAgent.indexOf("Netscape") != -1)
				return BrowserType.NETSCAPE;
			else if (userAgent.indexOf("Chrome") != -1)
				return BrowserType.GOOGLE_CHROME;
			else if (userAgent.indexOf("Flock") != -1)
				return BrowserType.FLOCK;
			else if (userAgent.indexOf("Safari") != -1)
				return BrowserType.SAFARI;
			else if (userAgent.indexOf("Firefox") != -1)
				return BrowserType.MOZILA_FIREFOX;

		}
		return BrowserType.UNKNOWN;
	}
}
