package com.bofa.b2bi.api.util;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.activation.MimetypesFileTypeMap;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPSClient;
import org.apache.commons.net.ftp.FTPFile;

import com.bofa.b2bi.api.impl.FTPException;
import com.bofa.b2bi.api.model.FileDetails;


public class FolderScanner {
	
	public static List<String> connectFtpSrvAndScanRootDir(final Map<String,String> connParams) throws FTPException
	{
		//Connect to FTP Server
		FTPSClient ftps = CommonUtility.connectFTPServer(connParams);
		
		final String remoteDir = connParams.get("dirName");
		final List<String> dirNameList = new ArrayList<String>();
		dirNameList.add("/");
		//Prepare list of Directory Names
        CommonUtility.recursiveScanner(ftps, remoteDir, "", dirNameList); 
        //DisConnect from FTP Server
        CommonUtility.disconnectFTPServer(ftps);
        
        return dirNameList;
    }
	
	public static String connectFtpSrvAndScanDir(final Map<String,String> connParams, final Map<String,String> filterParams) throws FTPException 
	{
		//Connect to FTP Server
		FTPSClient ftps = CommonUtility.connectFTPServer(connParams);
		
		List<FileDetails> fileDetailsList = new ArrayList<FileDetails>();
		try {
			
			final String remoteDir = connParams.get("dirName");		
            //change current directory
            ftps.changeWorkingDirectory(remoteDir);

            //get list of filenames
            FTPFile ftpFiles[] = ftps.listFiles(); 
            
            if (ftpFiles != null && ftpFiles.length > 0) 
            {
            	SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
                for (FTPFile file : ftpFiles) 
                {
                    if (file.getType() == FTPFile.FILE_TYPE) 
                    {
                    	FileDetails fd = new FileDetails();
            			fd.setFileName(file.getName());
            			fd.setFileSize(CommonUtility.calculateFileSize(file.getSize()));
            			fd.setFileDate(dateFormat.format(file.getTimestamp().getTime()));
            			fileDetailsList.add(fd);
                    }
                }
            } 
            //DisConnect from FTP Server
            CommonUtility.disconnectFTPServer(ftps);
        }
		catch (IOException excep) {
            excep.printStackTrace();
            return "Encountered exception while listing files!";
        }	
		
		if(fileDetailsList.size() != 0) {
			fileDetailsList = filterFileResults(fileDetailsList, filterParams);
		}		
		return CommonUtility.prepareFileData(fileDetailsList);
	}
	
	public static String connectFtpSrvAndDownloadFile(final String fileName, final Map<String,String> connParams, HttpServletResponse response) throws FTPException 
	{
		//Connect to FTP Server
		FTPSClient ftps = CommonUtility.connectFTPServer(connParams);
		try 
		{                        
            ftps.setFileType(FTP.BINARY_FILE_TYPE);

            final String remoteDir = connParams.get("dirName");
            //change current directory
            ftps.changeWorkingDirectory(remoteDir);
            //get list of filenames
            FTPFile ftpFiles[] = ftps.listFiles();
            
            if (ftpFiles != null && ftpFiles.length > 0) 
            {
                for (FTPFile file : ftpFiles) 
                {
                    if (file.getType() == FTPFile.FILE_TYPE) 
                    {
                    	if(file.getName().equals(fileName)) 
                        {
                        	MimetypesFileTypeMap fileTypeMap = new MimetypesFileTypeMap();
                    		String mimeType = fileTypeMap.getContentType(file.getName());			
                            response.setContentType(mimeType);
                        	response.setContentLength((int)file.getSize());
                        	response.setHeader("Content-Disposition", String.format("attachment; filename=\"%s\"", fileName));
                        	ftps.retrieveFile(file.getName(), response.getOutputStream());
                        	break;
                        }
                    }
                }
            }
            //DisConnect from FTP Server
            CommonUtility.disconnectFTPServer(ftps);
        }
		catch (IOException excep) {
            excep.printStackTrace();
            return "Encountered exception while retrieving file!";
        }
		return "File download Success!";
	}
	
	private static List<FileDetails> filterFileResults(final List<FileDetails> fileDetailsList, final Map<String,String> filterParams) 
	{
		List<FileDetails> filesList = new ArrayList<FileDetails>();
		try 
		{			
			String startDate = filterParams.get("StartDate").trim();
			String endDate = filterParams.get("EndDate").trim();
			String startTime = filterParams.get("StartTime").trim();
			String endTime = filterParams.get("EndTime").trim();
			String startAMPM = filterParams.get("StartAMPM").trim();
			String endAMPM = filterParams.get("EndAMPM").trim();
			
			SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(dateFormat1.parse(startDate));
			int fromYear = calendar.get(Calendar.YEAR);
			int fromMonth = calendar.get(Calendar.MONTH) + 1;
			int fromDay = calendar.get(Calendar.DATE);
			calendar.setTime(dateFormat1.parse(endDate));
			int toYear = calendar.get(Calendar.YEAR);
			int toMonth = calendar.get(Calendar.MONTH) + 1;
			int toDay = calendar.get(Calendar.DATE);
			
			SimpleDateFormat dateFormat2 = new SimpleDateFormat("hh:mm");
			calendar.setTime(dateFormat2.parse(startTime));
			int fromHour = calendar.get(Calendar.HOUR);
			if(startAMPM.equals("PM")) {
				fromHour = fromHour + 12;
			}
			int fromMinute = calendar.get(Calendar.MINUTE);
			calendar.setTime(dateFormat2.parse(endTime));
			int toHour = calendar.get(Calendar.HOUR);
			if(endAMPM.equals("PM")) {
				toHour = toHour + 12;
			}
			int toMinute = calendar.get(Calendar.MINUTE);
			
			int createdYear;
			int createdMonth;
			int createdDay;
			int createdHour;
			int createdMinute;
			int createdAMPM;
			
			String fileName = filterParams.get("messageName").trim();
			SimpleDateFormat dateFormat4 = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
			
			for(FileDetails fd : fileDetailsList) 
			{
				String createdDate = fd.getFileDate();
				calendar.setTime(dateFormat4.parse(createdDate));
				createdYear = calendar.get(Calendar.YEAR);
				createdMonth = calendar.get(Calendar.MONTH) + 1;
				createdDay = calendar.get(Calendar.DATE);
				createdHour = calendar.get(Calendar.HOUR);
				createdMinute = calendar.get(Calendar.MINUTE);
				createdAMPM = calendar.get(Calendar.AM_PM);
				if(createdAMPM == 1) {
					createdHour = createdHour + 12;
				}			
				
				if(fromYear == toYear && fromYear == createdYear) 
				{
					if(fromMonth == toMonth && fromMonth == createdMonth)
					{
						if(fromDay == toDay && fromDay == createdDay) 
						{
							if(fromHour == toHour && fromHour == createdHour) 
							{
								if(fromMinute == toMinute && fromMinute == createdMinute) 
								{
									addFileToResultList(fileName, fd, filesList);
								}
							}
							else if(fromHour < createdHour && toHour > createdHour)
							{
								addFileToResultList(fileName, fd, filesList);
							}
							else if(fromHour < createdHour && toHour == createdHour)
							{
								if(toMinute >= createdMinute) 
								{
									addFileToResultList(fileName, fd, filesList);
								}
							}
							else if(fromHour == createdHour && toHour > createdHour)
							{
								if(fromMinute <= createdMinute) 
								{
									addFileToResultList(fileName, fd, filesList);
								}
							}
						}
						else if(fromDay < createdDay && toDay > createdDay) 
						{
							addFileToResultList(fileName, fd, filesList);
						}
						else if(fromDay < createdDay && toDay == createdDay) 
						{
							if(toHour > createdHour) 
							{
								addFileToResultList(fileName, fd, filesList);
							}
							else if(toHour == createdHour)
							{
								if(toMinute >= createdMinute) 
								{
									addFileToResultList(fileName, fd, filesList);
								}
							}
						}
						else if(fromDay == createdDay && toDay > createdDay) 
						{
							if(fromHour < createdHour) 
							{
								addFileToResultList(fileName, fd, filesList);
							}
							else if(fromHour == createdHour)
							{
								if(fromMinute <= createdMinute) 
								{
									addFileToResultList(fileName, fd, filesList);
								}
							}						
						}
					}
					else if(fromMonth < createdMonth && toMonth > createdMonth) 
					{
						addFileToResultList(fileName, fd, filesList);
					}
					else if(fromMonth < createdMonth && toMonth == createdMonth)
					{
						if(toDay > createdDay) 
						{
							addFileToResultList(fileName, fd, filesList);
						}
						else if(toDay == createdDay)
						{
							if(toHour > createdHour) 
							{
								addFileToResultList(fileName, fd, filesList);
							}
							else if(toHour == createdHour)
							{
								if(toMinute >= createdMinute) 
								{
									addFileToResultList(fileName, fd, filesList);
								}
							}
						}
					}
					else if(fromMonth == createdMonth && toMonth > createdMonth)
					{
						if(fromDay < createdDay) 
						{
							addFileToResultList(fileName, fd, filesList);
						}
						else if(fromDay == createdDay) 
						{
							if(fromHour < createdHour) 
							{
								addFileToResultList(fileName, fd, filesList);
							}
							else if(fromHour == createdHour)
							{
								if(fromMinute <= createdMinute) 
								{
									addFileToResultList(fileName, fd, filesList);
								}
							}
						}
					}
				}	
				else if(fromYear < createdYear && toYear > createdYear) 
				{
					addFileToResultList(fileName, fd, filesList);
				}
				else if(fromYear < createdYear && toYear == createdYear) 
				{
					if(toMonth > createdMonth)
					{
						addFileToResultList(fileName, fd, filesList);
					}
					else if(toMonth == createdMonth)
					{
						if(toDay > createdDay) 
						{
							addFileToResultList(fileName, fd, filesList);
						}
						else if(toDay == createdDay)
						{
							if(toHour > createdHour) 
							{
								addFileToResultList(fileName, fd, filesList);
							}
							else if(toHour == createdHour)
							{
								if(toMinute >= createdMinute) 
								{
									addFileToResultList(fileName, fd, filesList);
								}
							}
						}
					}
				}
				else if(fromYear == createdYear && toYear > createdYear) 
				{
					if(fromMonth < createdMonth)
					{
						addFileToResultList(fileName, fd, filesList);
					}
					else if(fromMonth == createdMonth) 
					{
						if(fromDay < createdDay) 
						{
							addFileToResultList(fileName, fd, filesList);
						}
						else if(fromDay == createdDay) 
						{
							if(fromHour < createdHour) 
							{
								addFileToResultList(fileName, fd, filesList);
							}
							else if(fromHour == createdHour)
							{
								if(fromMinute <= createdMinute) 
								{
									addFileToResultList(fileName, fd, filesList);
								}
							}
						}
					}
				}			
			}		
		}
		catch (ParseException e1) {
			e1.printStackTrace();
		}
		
		return filesList;
	}
	
	private static void addFileToResultList(String fileName, FileDetails fileDetails, List<FileDetails> filesList) 
	{
		if(!fileName.isEmpty()) 
		{
			Pattern pattern = Pattern.compile(fileName.toLowerCase());		      
			Matcher matcher = pattern.matcher(fileDetails.getFileName().toLowerCase()); 
			if(matcher.lookingAt()) {
				filesList.add(fileDetails);
			}
		} else {
			filesList.add(fileDetails);
		}
	}
	
}
