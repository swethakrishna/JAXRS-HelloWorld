package com.bofa.b2bi.api.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DaoUtility {
	
	/*private static final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
	private static final String DB_CONNECTION = "jdbc:oracle:thin:@//TXB2BIDDB01-scan:49125/B2BI1D";
	private static final String DB_USER = "MLCLEAR_ADMIN_WRITE";
	private static final String DB_PASSWORD = "SI_ADM1N";*/
	
	private static final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
	private static final String DB_CONNECTION = "jdbc:oracle:thin:@//lcdra0fzc01-scan:49125/B2BI1S";
	private static final String DB_USER = "CLEAR_ADMIN_TEST";
	private static final String DB_PASSWORD = "B2BI_SIT_ADMIN";
	

	/**
	 * Get DB connetion.
	 *
	 */
	public static Connection getDBConnection() {

		Connection dbConnection = null;

		try {
			Class.forName(DB_DRIVER);
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}

		try {
			dbConnection = DriverManager.getConnection(DB_CONNECTION, DB_USER, DB_PASSWORD);
			return dbConnection;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		return dbConnection;
	}
	
	/**
	 * Closes a ResultSet object
	 *
	 * @param result
	 *            ResultSet to be closed
	 */
	public static void resultSetClose(ResultSet result) {
		try {
			if (result != null) {
				result.close();
			}
		} catch (SQLException sqle) {
			System.err.println("Failed to close resultSet");
		}
	}

	/**
	 * Closes a Statement object
	 *
	 * @param stmt
	 *            Statement to be closed
	 */
	public static void statementClose(Statement stmt) {
		try {
			if (stmt != null) {
				stmt.close();
			}
		} catch (SQLException sqle) {
			System.err.println("Failed to close (prepared)Statement");
		}
	}

}
