package com.bofa.b2bi.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;

import com.bofa.b2bi.api.response.AuthenticationResponse;
import com.bofa.b2bi.api.response.TokenResponse;
import com.bofa.b2bi.api.service.AuthenticationService;
import com.bofa.b2bi.core.exception.PlatformException;

@Path("/")
public class AuthenticatioResourceService {

	@Autowired
	AuthenticationService authenticationService;

	@GET
	@Path("/authenticate")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public AuthenticationResponse authenticate(@HeaderParam("authorization") String authString) throws PlatformException {
		return authenticationService.authenticate(authString);
	}

	@GET
    @Path("/validateusertoken")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public TokenResponse validateUserToken(@QueryParam("userName") String userName, @QueryParam("otp") String otp) throws PlatformException {
		return authenticationService.validateUserToken(userName, otp);
	}
}
