package com.bofa.b2bi.api.impl;

import java.io.IOException;
import java.io.InputStream;
import java.net.SocketException;
import java.util.MissingResourceException;
import java.util.PropertyResourceBundle;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.commons.net.ftp.FTPSClient;

import com.bofa.b2bi.api.util.CommonUtility;

public class FTPFileupload {

    /**
     * Set the ftp mode to be ASCII or binary.
     * Set parameter to 'true' if ASCII.
     *
     * @param ftpModeAscii The ftpModeAscii to set.
     */
    public void setFtpModeAscii(boolean ftpModeAscii) {
        this.ftpModeAscii = ftpModeAscii;
    }

    /**
     * Returns 'true' if mode is ASCII.
     *
     * @return Returns the ftpModeAscii.
     */
    public boolean isFtpModeAscii() {
        return ftpModeAscii;
    }

    /**
     * Set the password used for the FTP server.
     *
     * @param ftpPassword The ftpPassword to set.
     */
    public void setFtpPassword(String ftpPassword) {
        this.ftpPassword = ftpPassword;
    }

    /**
     * Get the password used for the FTP server.
     *
     * @return Returns the ftpPassword.
     */
    public String getFtpPassword() {
        return ftpPassword;
    }

    /**
     * DOCUMENT ME!
     *
     * @param ftpPort The ftpPort to set.
     */
    public void setFtpPort(int ftpPort) {
        this.ftpPort = ftpPort;
    }

    /**
     * DOCUMENT ME!
     *
     * @return Returns the ftpPort.
     */
    public int getFtpPort() {
        return ftpPort;
    }

    /**
     * DOCUMENT ME!
     *
     * @param ftpRemoteDirectory The ftpRemoteDirectory to set.
     */
    public void setFtpRemoteDirectory(String ftpRemoteDirectory) {
        this.ftpRemoteDirectory = ftpRemoteDirectory;
    }

    /**
     * DOCUMENT ME!
     *
     * @return Returns the ftpRemoteDirectory.
     */
    public String getFtpRemoteDirectory() {
        return ftpRemoteDirectory;
    }

    /**
     * DOCUMENT ME!
     *
     * @param ftpServer The ftpServer to set.
     */
    public void setFtpServer(String ftpServer) {
        this.ftpServer = ftpServer;
    }

    /**
     * DOCUMENT ME!
     *
     * @return Returns the ftpServer.
     */
    public String getFtpServer() {
        return ftpServer;
    }

    /**
     * DOCUMENT ME!
     *
     * @param ftpUser The ftpUser to set.
     */
    public void setFtpUser(String ftpUser) {
        this.ftpUser = ftpUser;
    }

    /**
     * DOCUMENT ME!
     *
     * @return Returns the ftpUser.
     */
    public String getFtpUser() {
        return ftpUser;
    }
    
    public String getFtpFileName() {
		return ftpFileName;
	}
	public void setFtpFileName(String ftpFileName) {
		this.ftpFileName = ftpFileName;
	}
	public void setFtpLocalFile(InputStream ftpLocalFile) {
		this.ftpLocalFile = ftpLocalFile;
	}

    /**
     * Returns true if all the required information have been provided.
     *
     * @return
     */
    public boolean isReady() {
        boolean ready = true;

        if(this.ftpServer == null) {
        	System.out.println("FTP SERVER needs to be provided.");
            ready = false;
        }

        if(this.ftpPort == -1) {
        	System.out.println("FTP PORT needs to be provided.");
            ready = false;
        }

        if(this.ftpUser == null) {
        	System.out.println("FTP USER needs to be provided.");
            ready = false;
        }

        if(this.ftpPassword == null) {
        	System.out.println("FTP PASSWORD needs to be provided.");
            ready = false;
        }

        if(this.ftpLocalFile == null) {
        	System.out.println("REPLAY FILE TO SEND needs to be provided.");
            ready = false;
        }

        if(this.ftpRemoteDirectory == null) {
        	System.out.println("REPLAY REMOTE MAILBOX needs to be provided.");
            ready = false;
        }

        return ready;
    }
    

    /**
     * Perform all the necessary actions:<br/
     * > - update the ML database - send the file to GIS over FTP
     *
     * @throws FTPException error encountered
     */
    public boolean run(String authString, String dirName) throws FTPException {
    	parsePropertiesFile(authString, dirName);
    	if(isReady()) {
            System.out.println("Updating CLEAR database...");
            System.out.println("CLEAR database updated SUCCESSFULLY.");

            try {
            	System.out.println("Sending file to GIS FTP server...");
                sendFile();
                System.out.println("File sent SUCCESSFULLY.");
            } catch(Exception e) {
            	System.out.println("ERROR Encountered, rolling back CLEAR database...");
                System.out.println("Rollback SUCCESSFUL.");
                if ( e instanceof FTPException ) {
                	throw (FTPException) e;
                } else {
                	throw new FTPException( "Replay operation failed.", e );
                }
            }
            return true;
        } else {
        	return false;
        }
    }

    /**
     * Checks to see if a particular property is defined
     *
     * @param app DOCUMENT ME!
     * @param key
     *
     * @return
     */
    private String getProperty(PropertyResourceBundle app, String key) {
        if(app == null) {
            return null;
        } else {
            try {
                final String value = app.getString(key);

                System.out.println(key + "=" + value);

                return ((value != null) && (value.trim().length() > 0)) ? value
                                                                        : null;
            } catch(MissingResourceException e) {
                return null; // property is not defined
            }
        }
    }


    /**
     * Parses properties file for application settings.  The properties file
     * loads default settings so the user doesn't have to manually enter and
     * change values each time the replay tool is run.
     *
     * @param propFilePath
     *
     * @throws FTPException
     */
    public void parsePropertiesFile(String authString, String dirName) throws FTPException {
    	String credentials[] = CommonUtility.getUserNameAndPassword(authString);
    	String temp = null;
    	App app = new App();
    	PropertyResourceBundle prb = app.parsePropertiesFile();
    	
        this.ftpServer = getProperty(prb, "com.baci.ftpsrv.hostname");
        temp = getProperty(prb, "com.baci.ftpsrv.portno");
        if(temp != null) {
            this.ftpPort = Integer.parseInt(temp);
        } else {
        	this.ftpPort = -1;
        }

        this.ftpUser     = credentials[0];
        this.ftpPassword = credentials[1];
        this.ftpRemoteDirectory = dirName;	
        temp = getProperty(prb, "ftp.mode");
        this.ftpModeAscii = ((temp != null) &&
                                temp.equalsIgnoreCase("ascii"));

    }

    /**
     * Send the file to GIS over FTP.
     *
     * @throws FTPException
     */
    private void sendFile() throws FTPException {
        FTPClient ftp = new FTPClient();
        System.out.println( "Connecting TO FTP server..." );
        try {
            //  connect to the server
            ftp.connect(this.ftpServer, this.ftpPort);
            System.out.println(ftp.getReplyString());
            System.out.println( "Connected SUCCESSFULY." );

            if(!FTPReply.isPositiveCompletion(ftp.getReplyCode())) {
                throw new FTPException("Cannot connect to FTP server.");
            }

            // login to server
            if(!ftp.login(this.ftpUser, this.ftpPassword)) {
                throw new FTPException("Cannot login to FTP server.");
            }
            ftp.enterLocalPassiveMode();
            System.out.println(ftp.getReplyString());

            // set the file type for the transfer
            int type = this.ftpModeAscii ? FTP.ASCII_FILE_TYPE
                                         : FTP.BINARY_FILE_TYPE;

            if(!ftp.setFileType(type)) {
                throw new FTPException("Cannot set the to FTP file type.");
            }
            System.out.println(ftp.getReplyString());

            // change the working directory
            if ( !ftp.changeWorkingDirectory(this.ftpRemoteDirectory)) {
                throw new FTPException("Cannot change directory to " + this.ftpRemoteDirectory + "." );
            }
            System.out.println(ftp.getReplyString());

            // send the file over
            System.out.println("SENDING FILE...");


            if(!ftp.storeFile(this.ftpFileName, this.ftpLocalFile)) {
                throw new FTPException("Cannot send the file to the FTP server.");
            }
            System.out.println(ftp.getReplyString());
            System.out.println("DONE");
            
        } catch(SocketException e) {
            throw new FTPException("socket Cannot send file to FTP server.", e);
        } catch(IOException e) {
            throw new FTPException("Cannot send file to FTP server.", e);
        } finally {
            if((ftp != null) && ftp.isConnected()) {
                try {
                	System.out.println("Disconnecting from FTP server...");
                    ftp.logout();
                    ftp.disconnect();
                    System.out.println("Disconnected from FTP server SUCCESSFULLY.");
                } catch(IOException e1) {
                    System.err.println(e1.getMessage());
                }
            }
        }
    }
    
    private void sendFile1() throws FTPException {
        FTPSClient ftps = new FTPSClient(true);
        System.out.println( "Connecting TO FTP server..." );
        try {
            //  connect to the server
        	ftps.connect(this.ftpServer);
            System.out.println(ftps.getReplyString());
            System.out.println( "Connected SUCCESSFULY." );

            if(!FTPReply.isPositiveCompletion(ftps.getReplyCode())) {
                throw new FTPException("Cannot connect to FTP server.");
            }

            // login to server
            if(!ftps.login(this.ftpUser, this.ftpPassword)) {
                throw new FTPException("Cannot login to FTP server.");
            }

            System.out.println(ftps.getReplyString());

            // set the file type for the transfer
            int type = this.ftpModeAscii ? FTP.ASCII_FILE_TYPE
                                         : FTP.BINARY_FILE_TYPE;

            if(!ftps.setFileType(type)) {
                throw new FTPException("Cannot set the to FTP file type.");
            }
            System.out.println(ftps.getReplyString());

            // change the working directory
            if ( !ftps.changeWorkingDirectory(this.ftpRemoteDirectory)) {
                throw new FTPException("Cannot change directory to " + this.ftpRemoteDirectory + "." );
            }
            System.out.println(ftps.getReplyString());

            // send the file over
            System.out.println("SENDING FILE...");


            if(!ftps.storeFile(this.ftpFileName, this.ftpLocalFile)) {
                throw new FTPException("Cannot send the file to the FTP server.");
            }
            System.out.println(ftps.getReplyString());
            System.out.println("DONE");
            
        } catch(SocketException e) {
            throw new FTPException("Cannot send file to FTP server.", e);
        } catch(IOException e) {
            throw new FTPException("Cannot send file to FTP server.", e);
        } finally {
            if((ftps != null) && ftps.isConnected()) {
                try {
                	System.out.println("Disconnecting from FTP server...");
                	ftps.logout();
                	ftps.disconnect();
                    System.out.println("Disconnected from FTP server SUCCESSFULLY.");
                } catch(IOException e1) {
                    System.err.println(e1.getMessage());
                }
            }
        }
    }
    
    public void setFTPFile(InputStream is, String fileName) {
    	this.ftpLocalFile = is;
    	this.ftpFileName = fileName;
    	
    }

  //~ Instance fields --------------------------------------------------------

    /** FTP server */
    private String ftpServer;

    /** FTP port */

    private int ftpPort;
    /** FTP user */
    private String ftpUser;

    /** FTP password */
    private String ftpPassword;

    /** Local file to send to FTP server */
    private InputStream ftpLocalFile;

   

    /** true if ftp mode should be ascii */
    private boolean ftpModeAscii;

    /** ftp remote directory */
    private String ftpRemoteDirectory;
    
    /** ftp remote directory */
    private String ftpFileName;

	
   

    
}
