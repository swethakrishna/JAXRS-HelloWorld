package com.bofa.b2bi.api.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.PropertyResourceBundle;

public class App {

	 /**
     * Parses properties file for application settings.  The properties file
     * loads default settings so the user doesn't have to manually enter and
     * change values each time the replay tool is run.
     *
     * @param propFilePath
     *
     * @throws FTPException
     */
    public PropertyResourceBundle parsePropertiesFile()
                              throws FTPException {
        PropertyResourceBundle app  = null;

        try {
            app = new PropertyResourceBundle(getClass().getResourceAsStream("/conf/config.properties"));
            return app;
        } catch(NullPointerException e) {
            throw new FTPException("Missing value expected in properties file.",
                                      e);
        } catch(NumberFormatException e) {
            throw new FTPException("Number value expected in properties file.",
                                      e);
        } catch(FileNotFoundException e) {
            throw new FTPException("Properties file not found.", e);
        } catch(IOException e) {
            throw new FTPException("Properties file not found.", e);
        }

    }
    
}