
package com.bofa.b2bi.api.impl;


public class FTPException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Default constructor
	 *
	 */
	public FTPException() {
		super();
	}

	/**
	 * 
	 * @param msg error message
	 */
	public FTPException( String msg ) {
		super( msg );
	}

	/**
	 * 
	 * @param msg Error message
	 */
	public FTPException( String msg, Throwable t ) {
		super( msg, t );// No good for JDK1.3
		
	}

	/**
	 * 
	 * No good with JDK1.3
	 * @param t cause
	 */
	public FTPException( Throwable t ) {
		super( t );
	}
}
