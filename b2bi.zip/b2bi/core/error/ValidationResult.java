package com.bofa.b2bi.core.error;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

public class ValidationResult {

    private final List<ValidationError> errorList = new ArrayList<>();

    public ValidationResult(ValidationError error) {
        addError(error);
    }

    public ValidationResult() {

    }

    public ValidationResult(ValidationResult validationResult) {
        merge(validationResult);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ValidationResult that = (ValidationResult) o;
        return errorList.equals(that.errorList);
    }

    @Override
    public int hashCode() {
        return errorList.hashCode();
    }

    public boolean isSuccess() {
        return errorList.isEmpty();
    }

    public int errorCount() {
        return errorList.size();
    }

    public int errorCount(final String fieldName) {
        return getValidationErrorsForField(fieldName).size();
    }

    public int globalErrorCount() {
        return getGlobalValidationErrors().size();
    }

    public List<ValidationError> getErrorList() {
        return new ArrayList<>(errorList);
    }

    public ValidationError getFirstError() {
        return errorList.get(0);
    }

    public void addError(ValidationError validationError) {
        if (validationError != null) {
            errorList.add(validationError);
        }
    }

    public void addGlobalError(final BlError blError) {
        Objects.requireNonNull(blError);

        if (!hasErrorCode(blError.getErrorCode())) {
            errorList.add(new ValidationError(blError));
        }

    }

    public void addError(String fieldName, BlError errorCode) {
        if (hasErrorCode(fieldName, errorCode)) {
            return;
        }

        addError(new ValidationError(errorCode, fieldName));
    }

    private boolean hasErrorCode(String fieldName, BlError errorCode) {
        return extractUniqueBlErrors(fieldName).contains(errorCode);
    }

    public void merge(ValidationResult validationResult) {
        if (validationResult != null) {
            errorList.addAll(validationResult.getErrorList());
        }
    }

    public void addError(ValidationResult validationResult) {
        Objects.requireNonNull(validationResult, "Validation result must not be null");
        errorList.addAll(validationResult.getErrorList());
    }

    public boolean hasErrorCode(int errorCode) {
        for (ValidationError error : errorList) {
            if (error.getErrorCode().getErrorCode() == errorCode) {
                return true;
            }
        }
        return false;
    }

    public boolean hasOnlyErrorCodes(String expectedFieldName, BlError... expectedErrorCodes) {

        final List<ValidationError> validationErrorsForField = getValidationErrorsForField(expectedFieldName);
        if (validationErrorsForField.size() != expectedErrorCodes.length) {
            return false;
        }

        final List<BlError> expectedErrorCodesAsList = Arrays.asList(expectedErrorCodes);
        for (final ValidationError validationError : validationErrorsForField) {
            if (!expectedErrorCodesAsList.contains(validationError.getErrorCode())) {
                return false;
            }
        }

        return true;
    }

    public boolean hasOnlyGlobalErrorCodes(BlError... expectedErrorCodes) {

        final List<ValidationError> validationErrorsForField = getGlobalValidationErrors();
        if (validationErrorsForField.size() != expectedErrorCodes.length) {
            return false;
        }

        final List<BlError> expectedErrorCodesAsList = Arrays.asList(expectedErrorCodes);
        for (final ValidationError validationError : validationErrorsForField) {
            if (!expectedErrorCodesAsList.contains(validationError.getErrorCode())) {
                return false;
            }
        }

        return true;
    }

    public boolean hasErrorCodeName(String errorCodeName) {
        for (ValidationError error : errorList) {
            if (error.getErrorCode().name().equals(errorCodeName)) {
                return true;
            }
        }
        return false;
    }

    public static ValidationResult success() {
        return new ValidationResult();
    }

    @Override
    public String toString() {
        return "ValidationResult{" + "errorList=" + errorList + '}';
    }

    public boolean containsError(String fieldName, BlError error) {
        return getValidationError(fieldName, error) != null;
    }

    public void removeError(String fieldName, BlError error) {

        final ValidationError matchingValidationError = getValidationError(fieldName, error);
        if (matchingValidationError == null) {
            return;
        }

        errorList.remove(matchingValidationError);

    }

    public Set<BlError> extractUniqueBlErrors(final String fieldName) {

        final Set<BlError> uniqueBlErrors = new HashSet<>();

        for (final ValidationError validationError : getValidationErrorsForField(fieldName)) {
            uniqueBlErrors.add(validationError.getErrorCode());
        }

        return uniqueBlErrors;
    }

    public Set<BlError> extractUniqueGlobalBlErrors() {

        final Set<BlError> uniqueBlErrors = new HashSet<>();

        for (final ValidationError validationError : getGlobalValidationErrors()) {
            uniqueBlErrors.add(validationError.getErrorCode());
        }

        return uniqueBlErrors;
    }

    private List<ValidationError> getValidationErrorsForField(final String fieldName) {

        Objects.requireNonNull(fieldName, "Tried to get validation errors for a null field.");

        final List<ValidationError> validationErrorsForField = new ArrayList<>();
        for (final ValidationError validationError : getErrorList()) {
            if (!fieldName.equals(validationError.getFieldName())) {
                continue;
            }
            validationErrorsForField.add(validationError);
        }

        return validationErrorsForField;
    }

    private List<ValidationError> getGlobalValidationErrors() {

        final List<ValidationError> validationErrorsForField = new ArrayList<>();
        for (final ValidationError validationError : getErrorList()) {
            if (validationError.getFieldName() != null) {
                continue;
            }
            validationErrorsForField.add(validationError);
        }

        return validationErrorsForField;
    }

    private ValidationError getValidationError(String fieldName, BlError error) {

        for (final ValidationError validationError : getValidationErrorsForField(fieldName)) {
            if (validationError.getErrorCode().equals(error)) {
                return validationError;
            }
        }

        return null;
    }

}
