package com.bofa.b2bi.core.error;
/**
 * General business agnostic errors of the BL.
 *
 * @author Umamahesh
 */
public enum GeneralError implements BlError {
    CLIENT_MALFORMED_REQUEST_NO_BODY(1, "Malformed request, unable to marshal JSON."),
    CLIENT_MALFORMED_PARAMETER_TYPE(2, "Malformed parameter type, the client has tried to supply a parameter in the wrong form."),
    SYSTEM_ERROR(1000, "System error"),
    SYSTEM_ERROR_EMAIL_NOT_SENT(1001, "Email could not be sent"),
    SYSTEM_ERROR_TRY_LATER(1002, "Please try later"),
    SYSTEM_ERROR_IN_IL(1003, "Error in Integration Layer"),
    LOGIN_TOO_OLD(2002, "Login Too Old"),
    FIELD_REQUIRED(1505, "required field is missing"),
    FIELD_NOT_ALLOWED(1510, "field is not allowed"),
    NUMBER_TOO_LOW(1502, "Number too low"),
    NUMBER_TOO_HIGH(1501, "Number too high"),
    STRING_TOO_LONG(1503, "String too long"),
    STRING_TOO_SHORT(1504, "String too short"),
    MISSING_FIELD(1595, "Missing field"),
    INVALID_FIELD(1506, "Invalid field format"),
    DATE_IN_PAST(1507, "Date in past"),
    DATE_IN_FUTURE(1508, "Date in future"),
    DATE_TOO_OLD(1509, "Date too old"),
    INVALID_ATTRIBUTES_SUPPLIED(3200, "Invalid attribute"),
    NO_ATTRIBUTES_SUPPLIED(3201, "No attributes were supplied."),
    TOO_MANY_RESULTS(9016, "The operation returned too many results."),
    CONTACT_NOT_FOUND(9050, "Contact could not be found."),
    SYSTEM_ERROR_INTEGRATION(667, "System Error - Integration"),
    RESOURCE_NOT_FOUND(669, "Resource Not Found"),
    STRING_MUST_MATCH_PATTERN(1515, "String must match pattern"),
    MISSING_CDC(9051, "CDC does not exist");

    private final int code;
    private final String description;

    private GeneralError(int code, String description) {
        this.code = code;
        this.description = description;
    }

    @Override
    public int getErrorCode() {
        return code;
    }

    @Override
    public String getDescription() {
        return description;
    }

}
