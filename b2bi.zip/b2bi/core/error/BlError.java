package com.bofa.b2bi.core.error;


public interface BlError {
    /**
     * The error code which uniquely identifies the error.
     * @return the unique error code
     */
    int getErrorCode();

    /**
     * Get the character identifier for the error code, this might or might not be a unique string, used as a shorthand identifier for an error.
     * @return the character identifier for the error code, this might or might not be a unique string, used as a shorthand identifier for an error
     */
    String name();

    /**
     * The textual description of the error, intended for a technical audience.
     * @return the textual description of the error, never null
     */
    String getDescription();

}
