package com.bofa.b2bi.core.error;

import java.util.List;

public class ErrorResponse {
 
	private ErrorType errorType;
	private List<ErrorDetails> errorDetails;
	
	public List<ErrorDetails> getErrorDetails() {
		return errorDetails;
	}
	public void setErrorDetails(List<ErrorDetails> errorDetails) {
		this.errorDetails = errorDetails;
	}
	public ErrorType getErrorType() {
		return errorType;
	}
	public void setErrorType(ErrorType errorType) {
		this.errorType = errorType;
	}
	
}
