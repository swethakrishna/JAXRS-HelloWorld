package com.bofa.b2bi.core.error;

public enum ErrorType {
	VALIDATION(400),
	NOT_FOUND(404),
	INTERNAL(500);
	
	private final int statusCode;
	ErrorType(int statusCode) {
		this.statusCode = statusCode;
	}
	
	public int status(){
		return this.statusCode;
	}
}
