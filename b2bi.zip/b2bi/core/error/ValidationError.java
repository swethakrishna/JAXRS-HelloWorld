package com.bofa.b2bi.core.error;

import java.util.Collections;
import java.util.Map;

public class ValidationError {

    private final BlError errorCode;
    private final String fieldName;
    private final Map<String, String> context;


    public ValidationError(BlError errorCode, String fieldName, Map<String, String> context) {
        this.errorCode = errorCode;
        this.fieldName = fieldName;
        this.context = context != null ? Collections.unmodifiableMap(context) : null;
    }

    public ValidationError(BlError errorCode, String fieldName) {
        this.errorCode = errorCode;
        this.fieldName = fieldName;
        context = null;
    }

    public ValidationError(BlError errorCode) {
        this.errorCode = errorCode;
        fieldName = null;
        context = null;
    }

    public BlError getErrorCode() {
        return errorCode;
    }

    public String getFieldName() {
        return fieldName;
    }

    public Map<String, String> getContext() {
        return context;
    }

    @Override
    public int hashCode() {
        int result = errorCode != null ? errorCode.hashCode() : 0;
        result = 31 * result + (fieldName != null ? fieldName.hashCode() : 0);
        result = 31 * result + (context != null ? context.hashCode() : 0);
        return result;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ValidationError that = (ValidationError) o;

        if (context != null ? !context.equals(that.context) : that.context != null) {
            return false;
        }
        if (errorCode != null ? !errorCode.equals(that.errorCode) : that.errorCode != null) {
            return false;
        }
        if (fieldName != null ? !fieldName.equals(that.fieldName) : that.fieldName != null) {
            return false;
        }

        return true;
    }

    @Override
    public String toString() {
        return "ValidationError{" + "errorCode=" + errorCode + ", fieldName='" + fieldName + '\'' + ", context=" + context + '}';
    }
}
