package com.bofa.b2bi.core.aop;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.stereotype.Component;

import com.bofa.b2bi.api.dao.UserAuditDao;
import com.bofa.b2bi.api.model.UserAudit;
import com.bofa.b2bi.api.util.BrowserUtil;
import com.bofa.b2bi.api.util.BrowserUtil.BrowserType;
import com.bofa.b2bi.api.util.CommonUtility;

@Configurable
@Component
public class UserAuditBean {

	@Autowired
	private UserAuditDao userAuditDao;
	@Autowired
	private HttpServletRequest request;

	public UserAudit createUserAudit(UserAudit userAudit) {

		userAuditDao.createUserAudit(userAudit);
		return userAudit;
	}

	public void updateUserAudit(UserAudit userAudit) {

		userAuditDao.updateUserAudit(userAudit);
	}

	public UserAudit setUserAuditDetails(ProceedingJoinPoint proceedingJoinPoint) {
		UserAudit userAudit = new UserAudit();
		Object[] methodValues = proceedingJoinPoint.getArgs();
		String authString = (String) methodValues[0];
		String[] credentials = CommonUtility.getUserNameAndPassword(authString);
		userAudit.setUserName(credentials[0]);
		if (request.getRequestedSessionId() != null) {
			userAudit.setSessionId(request.getRequestedSessionId());
		} else {
			userAudit.setSessionId(request.getSession().getId());
		}
		// For accessing client browser
		BrowserType bType = BrowserUtil.getBrowserType(request.getHeader("user-agent"));
		userAudit.setBrowserType(bType);
		//// For accessing IP Address
		String ipAddress = request.getHeader("X-FORWARDED-FOR");
		if (ipAddress == null) {
			ipAddress = request.getRemoteAddr();
		}
		userAudit.setClientIPAddress(ipAddress);

		return userAudit;

	}

}
