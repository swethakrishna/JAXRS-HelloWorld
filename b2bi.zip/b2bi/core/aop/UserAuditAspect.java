package com.bofa.b2bi.core.aop;

import org.apache.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;

import com.bofa.b2bi.api.model.UserAudit;
import com.bofa.b2bi.core.exception.PlatformException;

@Aspect
public class UserAuditAspect {

	@Autowired
	private UserAuditBean userAuditBean;

	private static final Logger logger = Logger.getLogger(UserAuditAspect.class);

	@Around("execution(* com.bofa.b2bi.api.service.AuthenticationService.authenticate(..))")
	public void authenticateAroundAdvice(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
		logger.info("Before invoking authenticate() method from AuthenticationService");
		UserAudit userAudit = userAuditBean.setUserAuditDetails(proceedingJoinPoint);
		UserAudit userAuditObj = userAuditBean.createUserAudit(userAudit);
		try {
			proceedingJoinPoint.proceed();
		} catch (PlatformException ex) {
			userAudit.setErrorMessage(ex.getMessage());
			userAuditBean.updateUserAudit(userAuditObj);
			logger.error("Error in authenticate() method :: " + ex.getMessage());
			throw ex;
		}
		logger.info("After invoking authenticate() method from AuthenticationService.");

	}
}
