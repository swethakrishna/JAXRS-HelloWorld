package com.bofa.b2bi.core.validator;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.validation.Errors;
import org.springframework.validation.MapBindingResult;
import org.springframework.validation.ValidationUtils;

import com.bofa.b2bi.api.error.B2BIError;

/**
 * Base class for validators from CTP.
 * Provides basic functionality like rejecting of null value
 * and invoking spring validator mechanism.
 * @author Umamahesh
 *
 */
public abstract class BaseValidator implements B2BIValidator {

    private static final String DEFAULT_FIELD_NAME = "own";
    private static final Logger LOG = LoggerFactory.getLogger(BaseValidator.class);

    public BaseValidator(Class<?> clazz) {
        ValidatorFactory.register(clazz.getName(), this);
    }

    /**
     * Method rejects null value.
     * @param value Value to be rejected if it is null.
     * @param errors Error holder for adding error in case value to rejected.
     * @param fieldName Field name to be used for registering error.
     */
    public final void rejectNull(Object value, Errors errors, String fieldName) {
        if (Objects.isNull(value)) {
            errors.rejectValue(fieldName, B2BIError.CAN_NOT_BE_NULL.getErrorCodeString(), B2BIError.CAN_NOT_BE_NULL.getDescription());
        }
    }

    /**
     * Method rejects null value. Uses default fieldname as 'own'
     * @param value Value to be rejected if it is null
     * @param errors Error holder for adding error in case value to rejected.
     */
    public final void rejectNull(Object value, Errors errors) {
        rejectNull(value, errors, DEFAULT_FIELD_NAME);
    }

    /**
     * Method causes spring validation to be invoked.
     * @param value Object to be validated.
     * @param errors Error holder for adding errors in case object or its fields to rejected.
     *
     * @see #validate(Object, Errors)
     * @see #supports(Class)
     */
    @Override
    public void validateFields(Object value, Errors errors) {
        validateFields(value, errors, getPath());
    }

    /**
     * Method causes spring validation to be invoked.
     * @param value Object to be validated.
     * @param errors Error holder for adding errors in case object or its fields to rejected.
     * @param path Path where errors will be added
     *
     * @see #validate(Object, Errors)
     * @see #supports(Class)
     */
    public void validateFields(Object value, Errors errors, String path) {
        LOG.debug("Started Validating for {}", path);
        ((MapBindingResult) errors).pushNestedPath(path);

        ValidationUtils.invokeValidator(this, value, errors);

        ((MapBindingResult) errors).popNestedPath();
        LOG.debug("Finished Validating for {}", path);
    }
}
