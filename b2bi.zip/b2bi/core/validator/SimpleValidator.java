package com.bofa.b2bi.core.validator;

import java.math.BigDecimal;
import java.util.Objects;

import org.springframework.validation.Errors;

import com.bofa.b2bi.api.error.B2BIError;

/**
 * Abstract class implements basic validation functionality
 * by making use of spring ValidationUtils class. Refer {@link SimpleValidator#validateFields}.
 * Serves as a base class for all validators of CTP.
 * Provides simple methods for rejecting
 * <li> empty string {@link #rejectEmptyString(String, Errors, String)}
 * <li> null or empty string {@link #rejectNullOrEmptyString(String, Errors, String)}</li>
 * <li> negative integer {@link #rejectNegativeInteger(Integer, Errors, String)}</li>
 * <li> null or negative integer {@link #rejectNullOrNegativeInteger(Integer, Errors, String)}</li>
 *
 *
 * @author Umamahesh
 *
 */
public abstract class SimpleValidator extends BaseValidator {

    public SimpleValidator(Class<?> clazz) {
        super(clazz);
    }

    /**
     * Rejects empty string
     * @param value Value to be rejected if it is empty string.
     * @param errors Error holder for adding error in case value to rejected.
     * @param fieldName Field name to be used for registering error.
    */
    public final void rejectEmptyString(String value, Errors errors, String fieldName) {
        if (Objects.nonNull(value) && value.trim().isEmpty()) {
            errors.rejectValue(fieldName, B2BIError.CAN_NOT_BE_EMPTY_STRING.getErrorCodeString(), B2BIError.CAN_NOT_BE_EMPTY_STRING.getDescription());
        }
    }

    /**
     * Rejects null or empty string
     * @param value Value to be rejected if it is null or empty string.
     * @param errors Error holder for adding error in case value to rejected.
     * @param fieldName Field name to be used for registering error.
     */
    public final void rejectNullOrEmptyString(String value, Errors errors, String fieldName) {
        rejectNull(value, errors, fieldName);
        rejectEmptyString(value, errors, fieldName);
    }

    /**
     * Rejects negative or zero integer
     * @param value Value to be rejected if it is negative or zero integer
     * @param errors Error holder for adding error in case value to rejected.
     * @param fieldName Field name to be used for registering error.
     */
    public final void rejectNegativeOrZeroInteger(Integer value, Errors errors, String fieldName) {
        if (Objects.nonNull(value) && value <= 0) {
            errors.rejectValue(fieldName, B2BIError.CAN_NOT_BE_NEGATIVE_OR_ZERO.getErrorCodeString(), B2BIError.CAN_NOT_BE_NEGATIVE_OR_ZERO.getDescription());
        }
    }

    /**
     * Rejects null or negative integer
     * @param value Value to be rejected if it is null or negative integer
     * @param errors Error holder for adding error in case value to rejected.
     * @param fieldName Field name to be used for registering error.
     */
    public final void rejectNullOrNegativeInteger(Integer value, Errors errors, String fieldName) {
        rejectNull(value, errors, fieldName);
        rejectNegativeOrZeroInteger(value, errors, fieldName);
    }

    /**
     * Rejects negative integer
     * @param value Value to be rejected if it is negative integer
     * @param errors Error holder for adding error in case value to rejected.
     * @param fieldName Field name to be used for registering error.
     */
    public final void rejectNegativeInteger(Integer value, Errors errors, String fieldName) {
        if (Objects.nonNull(value) && value < 0) {
            errors.rejectValue(fieldName, B2BIError.CAN_NOT_BE_NEGATIVE.getErrorCodeString(), B2BIError.CAN_NOT_BE_NEGATIVE.getDescription());
        }
    }

    /**
     * Rejects null or negative big decimal number
     * @param value Value to be rejected if it is null or negative big decimal
     * @param errors Error holder for adding error in case value to rejected.
     * @param fieldName Field name to be used for registering error.
     */
    public final void rejectNullOrNegativeBigDecimal(BigDecimal value, Errors errors, String fieldName) {
        rejectNull(value, errors, fieldName);
        if (Objects.nonNull(value) && value.signum() == -1) {
            errors.rejectValue(fieldName, B2BIError.CAN_NOT_BE_NEGATIVE.getErrorCodeString(), B2BIError.CAN_NOT_BE_NEGATIVE.getDescription());
        }
    }

    /**
     * Rejects negative big decimal number
     * @param value Value to be rejected if it is negative big decimal
     * @param errors Error holder for adding error in case value to rejected.
     * @param fieldName Field name to be used for registering error.
     */
    public final void rejectNegativeBigDecimal(BigDecimal value, Errors errors, String fieldName) {
        if (Objects.nonNull(value) && value.signum() == -1) {
            errors.rejectValue(fieldName, B2BIError.CAN_NOT_BE_NEGATIVE.getErrorCodeString(), B2BIError.CAN_NOT_BE_NEGATIVE.getDescription());
        }
    }
}
