package com.bofa.b2bi.core.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

/**
 * All validators directly or indirectly implements this interface
 * Known implementing classes are SimpleValidator
 * @see SimpleValidator
 * @author Umamahesh
 */
public interface B2BIValidator extends Validator {

    /**
     * Method to supply validation logic for supplied object.
     * @param obj Object to be validated.
     * @param errors Error holder for populating error messages.
     */
    void validateFields(Object obj, Errors errors);

    /**
     *
     * @return path to be used for adding errors into
     */
    String getPath();
}
