package com.bofa.b2bi.core.validator;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Factory class for registering validators
 * @author Umamahesh	
 *
 */
public final class ValidatorFactory {

    private static Map<String, B2BIValidator> validators;

    private ValidatorFactory() {
        //Preventing instantiation
    }

    static {
        validators = new HashMap<>();
    }

    public static void register(String className, B2BIValidator validator) {
        Objects.requireNonNull(className, "Class name can not be null");
        Objects.requireNonNull(validator, "Validator name can not be null");
        validators.put(className, validator);
    }

    public static B2BIValidator get(String className) {
        return validators.get(className);
    }
}
