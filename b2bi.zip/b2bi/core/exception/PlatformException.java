package com.bofa.b2bi.core.exception;

public abstract class PlatformException extends RuntimeException {
    public PlatformException() {
    }

    public PlatformException(String message, Throwable cause) {
        super(message, cause);
    }

    public PlatformException(String message) {
        super(message);
    }

    public PlatformException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getMessage() {
        return super.getMessage() != null ? super.getMessage() : "";
    }
}
