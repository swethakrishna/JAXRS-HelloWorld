package com.bofa.b2bi.core.exception;

import java.util.Collections;
import java.util.Map;

import com.bofa.b2bi.core.error.BlError;

public class ApplicationException extends PlatformException {

    private final BlError error;
    private final Map<String, String> context;

    public ApplicationException(String message, BlError error) {
        this(message, error, null, null);
    }

    public ApplicationException(BlError error) {
        this(null, error, null, null);
    }

    public ApplicationException(BlError error, Map<String, String> context) {
        this(error, context, null);
    }

    public ApplicationException(String message, BlError error, Map<String, String> context) {
        this(message, error, context, null);
    }

    public ApplicationException(BlError error, Map<String, String> context, Throwable cause) {
        super(cause);
        this.error = error;
        this.context = (context != null) ? Collections.unmodifiableMap(context) : Collections.<String, String>emptyMap();
    }

    public ApplicationException(String message, BlError error, Map<String, String> context, Throwable cause) {
        super(message, cause);
        this.error = error;
        this.context = (context != null) ? Collections.unmodifiableMap(context) : Collections.<String, String>emptyMap();
    }

    public ApplicationException(BlError error, Throwable cause) {
        this(error, null, cause);
    }

    public BlError getError() {
        return error;
    }

    public Map<String, String> getContext() {
        return context;
    }

    @Override
    public String getMessage() {
        String message = super.getMessage();
        if (!message.isEmpty()) {
            message += " ";
        }
        return message + "error=" + getErrorRepresentation() + getContextRepresentation();
    }

    private String getErrorRepresentation() {
        return error != null ? error.toString() : "";
    }

    public String getContextRepresentation() {
        if (context == null || context.isEmpty()) {
            return "";
        }
        return " context=" + context.toString();
    }

}
