package com.bofa.b2bi.core.exception;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.bofa.b2bi.core.error.BlError;
import com.bofa.b2bi.core.error.GeneralError;

public class NotFoundException extends ApplicationException {

    public NotFoundException(BlError error) {
        super(error);
    }

    public NotFoundException(String errorMessage, BlError error) {
        super(errorMessage, error);
    }

    public NotFoundException(Class<?> clazz, Long id) {
        this(GeneralError.RESOURCE_NOT_FOUND, createContext(clazz, String.valueOf(id)));
    }

    public NotFoundException(Class<?> clazz, String id) {
        this(GeneralError.RESOURCE_NOT_FOUND, createContext(clazz, id));
    }

    public NotFoundException(BlError error, Map<String, String> context) {
        super(error, context);
    }

    private static Map<String, String> createContext(Class<?> clazz, String id) {
        Map<String, String> context = new HashMap<>();
        context.put("resourceClass", clazz.getName());
        context.put("resourceId", String.valueOf(id));
        return Collections.unmodifiableMap(context);
    }
}
